------------------------------------------------------------------------------
-- Badapples
-- 
-- Stores the name (and optional description) about players you've encountered
-- or been told about that you want to make sure to remember so as to avoid
-- ever grouping with them (or otherwise).
-- 
-- For control, the AddOn registers a /badapples slash command (aliased as
-- /badapple and /bad) with the following options:
--     /badapples help (default command, describes available options)
--     /badapples list (lists all badapples currently known to chat window)
--     /badapples show (shows all badapples in social window)
--     /badapples add <playername> [comment] (adds a player to the list)
--     /badapples remove <playername> (removes a player from the list)
--     /badapples check <playername> (shows player status in badapples list)
--     /badapples removeall (removes all players in the badapples list)
--     /badapples color (allows the player to set the color for badapples)
--     /badapples toggletab (allows player to change position of social tab)
--     /badapples notab (allows player to disable social tab)
--     /badapples debugon (turns on Badapples debug)
--     /badapples debugoff (turns off Badapples debug)
-- 
-- Written by Cirk of DoomHammer, April 2005
------------------------------------------------------------------------------

------------------------------------------------------------------------------
-- AddOn version
------------------------------------------------------------------------------
BADAPPLES_NAME = "Cirk's Badapples"
BADAPPLES_VERSION = "1.12.0"

BADAPPLES_FRAME_SCROLL_HEIGHT = 16;
BADAPPLES_DISPLAY_COUNT = 17;


------------------------------------------------------------------------------
-- Globals
------------------------------------------------------------------------------
BadapplesState = {};				-- Will be overridden when loaded


------------------------------------------------------------------------------
-- Text strings
------------------------------------------------------------------------------
local EM_ON = "|cffffff00"
local EM_OFF = "|r"
local RED_ON = "|cffff0000"
local RED_OFF = "|r"
local BAD_ON = "|cffff991a"			-- Will be overridden on load
local BAD_OFF = "|r"

BADAPPLES_TEXT = {
	COMMAND_HELP = "help",
	COMMAND_LIST = "list",
	COMMAND_SHOW = "show",
	COMMAND_CHECK = "check",
	COMMAND_STATUS = "status",
	COMMAND_ADD = "add",
	COMMAND_REMOVE = "remove",
	COMMAND_REMOVEALL = "removeall",
	COMMAND_COLOR = "color",
	COMMAND_SETCOLOR = "setcolor",
	COMMAND_REMOVEALL_CONFIRM = "confirm",
	COMMAND_NOTAB = "notab",
	COMMAND_TOGGLETAB = "toggletab",
	COMMAND_DEBUGON = "debugon",
	COMMAND_DEBUGOFF = "debugoff",

	MONTHNAME_01 = "Jan",
	MONTHNAME_02 = "Feb",
	MONTHNAME_03 = "Mar",
	MONTHNAME_04 = "Apr",
	MONTHNAME_05 = "May",
	MONTHNAME_06 = "Jun",
	MONTHNAME_07 = "Jul",
	MONTHNAME_08 = "Aug",
	MONTHNAME_09 = "Sep",
	MONTHNAME_10 = "Oct",
	MONTHNAME_11 = "Nov",
	MONTHNAME_12 = "Dec",

	ADD_CONFIRM = EM_ON.."Player "..EM_OFF..BAD_ON.."%s"..BAD_OFF..EM_ON.." added to Badapples list (%s)"..EM_OFF,
	UPDATE_CONFIRM = EM_ON.."Player "..EM_OFF..BAD_ON.."%s"..BAD_OFF..EM_ON.." reason updated (%s)"..EM_OFF,
	REMOVE_CONFIRM = EM_ON.."Player "..EM_OFF.."%s"..EM_ON.." removed from Badapples list"..EM_OFF,
	REMOVE_NOTFOUND = EM_ON.."Player "..EM_OFF.."%s"..EM_ON.." not in Badapples list"..EM_OFF,
	PLAYERNAME_FAILED = EM_ON.."You must provide a valid player name"..EM_OFF,
	PLAYERNAME_ISSELF = EM_ON.."You can't add yourself to the Badapples list!"..EM_OFF,
	LIST_FORMAT = "   "..BAD_ON.."%s"..BAD_OFF..EM_ON.." - %s"..EM_OFF,
	STATUS_GOOD = EM_ON.."Player "..EM_OFF.."%s"..EM_ON.." is NOT on your Badapples list",
	STATUS_BAD = EM_ON.."Player "..EM_OFF..BAD_ON.."%s"..BAD_OFF..EM_ON.." is on your Badapples list (%s)"..EM_OFF,
	STATUS_IGNORE = EM_ON.."Player %s is on your Ignore list"..EM_OFF,

	REMOVEALL_CONFIRM = EM_ON.."All players removed from Badapples list"..EM_OFF,
	PARTY_WARNING = RED_ON.."WARNING: "..RED_OFF..EM_ON.." Party member "..BAD_ON.."%s"..BAD_OFF..EM_ON.." is on your Badapples list (%s)"..EM_OFF,
	RAID_WARNING = RED_ON.."WARNING: "..RED_OFF..EM_ON.." Raid member "..BAD_ON.."%s"..BAD_OFF..EM_ON.." is on your Badapples list (%s)"..EM_OFF,
	PARTY_IGNORE_WARNING = RED_ON.."WARNING: "..RED_OFF..EM_ON.." Party member %s is on your Ignore list!"..EM_OFF,
	RAID_IGNORE_WARNING = RED_ON.."WARNING: "..RED_OFF..EM_ON.." Raid member %s is on your Ignore list!"..EM_OFF,

	NO_REASON = "no reason",
	PARTY_INVITE_TEXT = "Badapple player %s invites you to a group.",
	PARTY_IGNORE_INVITE_TEXT = "Ignored player %s invites you to a group.",
	PARTY_INVITE_BUTTON = "Accept anyway",
	INVITE_TEXT = "%s is on your Badapples list, invite anyway?",
	INVITE_IGNORE_TEXT = "%s is on your Ignore list, invite anyway?",
	PLAYER_ADD_TEXT = "Enter name of player to add to your list:",
	PLAYER_ADD_CONFIRM_TEXT = "Add %s to your Badapples list?",
	PLAYER_REMOVE_CONFIRM_TEXT = "Remove %s from your Badapples list?",
	REMOVEALL_CONFIRM_TEXT = "This will remove all entries from your Badapples list, are you sure you want to proceed?",
	DISABLE_TAB = "Disabled",
	ENABLE_FRIENDS_TAB = "FriendsEnabled",
	ENABLE_BOTTOM_TAB = "BottomEnabled",
	ENABLE_SIDE_TAB = "SideEnabled",
	TOGGLE_TAB = "Toggle",
	TAB_CONFIRM = EM_ON.."Badapples social tab is now %s"..EM_OFF,

	SORTBY_NAME = "Name",
	SORTBY_REASON = "Reason",
	SORTBY_NAME_REVERSE = "Eman",
	SORTBY_REASON_REVERSE = "Nosaer",

	TAB_NEWBIE_TOOLTIP = "Allows you to view your Badapples list",

	DEBUGON_CONFIRM = "Badapples debug is enabled",
	DEBUGOFF_CONFIRM = "Badapples debug is disabled",
};

BADAPPLES_TEXT.REMOVEALL_WARNING = RED_ON.."WARNING: This will remove all entries from Badapples"..RED_OFF.."\n"..EM_ON.."Use "..EM_OFF.."/badapples "..BADAPPLES_TEXT.COMMAND_REMOVEALL.." "..BADAPPLES_TEXT.COMMAND_REMOVEALL_CONFIRM..EM_ON.." to proceed"..EM_OFF;

BADAPPLES_HELP = {
	EM_ON.."Allows you to add player names (and a reason) to a list of \"badapples\", or players whom you want to be reminded of to avoid grouping with them."..EM_OFF;
	"   /badapples "..BADAPPLES_TEXT.COMMAND_HELP..EM_ON.." shows this help message"..EM_OFF;
	"   /badapples "..BADAPPLES_TEXT.COMMAND_LIST..EM_ON.." shows the current list"..EM_OFF;
	"   /badapples "..BADAPPLES_TEXT.COMMAND_SHOW..EM_ON.." shows the Badapples social window"..EM_OFF;
	"   /badapples "..BADAPPLES_TEXT.COMMAND_ADD.." <playername>"..EM_ON.." adds a player"..EM_OFF;
	"   /badapples "..BADAPPLES_TEXT.COMMAND_REMOVE.." <playername>"..EM_ON.." removes a player"..EM_OFF;
	"   /badapples "..BADAPPLES_TEXT.COMMAND_CHECK.." <playername>"..EM_ON.." checks player status"..EM_OFF;
	"   /badapples "..BADAPPLES_TEXT.COMMAND_REMOVEALL..EM_ON.." removes all players"..EM_OFF;
	"   /badapples "..BADAPPLES_TEXT.COMMAND_COLOR..EM_ON.." allows you to set the Badapples highlight color"..EM_OFF;
	"   /badapples "..BADAPPLES_TEXT.COMMAND_TOGGLETAB..EM_ON.." toggles the Badapples social tab position"..EM_OFF;
	"   /badapples "..BADAPPLES_TEXT.COMMAND_NOTAB..EM_ON.." disables the Badapples social tab"..EM_OFF;
	EM_ON.."You can also use "..EM_OFF.."/bad"..EM_ON.." for the above slash commands"..EM_OFF;
};


------------------------------------------------------------------------------
-- Local constants
------------------------------------------------------------------------------
local BADAPPLES_MAXIMUM_REASON_LENGTH = 192;
local BADAPPLES_PARTY_CLEANUP_DELAY = 1;
local BADAPPLES_RAID_CLEANUP_DELAY = 1;
local BADAPPLES_DEFAULT_HIGHLIGHT_R = 1.0;
local BADAPPLES_DEFAULT_HIGHLIGHT_G = 0.65;
local BADAPPLES_DEFAULT_HIGHLIGHT_B = 0.3;
local BADAPPLES_TAB_ID = 17;


------------------------------------------------------------------------------
-- Local variables
------------------------------------------------------------------------------
local _originalChatFrame_OnEvent;			-- Original chat frame event handler
local _originalSetItemRef;					-- Original SetItemRef function
local _originalStaticPopup_Show;			-- Original StaticPopup_Show function
local _originalInviteByName;				-- Original InviteByName function
local _originalTargetFrame_CheckFaction;	-- Original TargetFrame_CheckFaction function
local _originalGameTooltip_UnitColor;		-- Original GameTooltip_UnitColor function
local _originalChatEdit_UpdateHeader;		-- Original ChatEdit_UpdateHeader
local _originalFriendsFrame_Update;			-- Original FriendsFrame_Update function
local _originalPanelTemplates_UpdateTabs;	-- Original PanelTemplates_UpdateTabs

local _thisFrame = nil;				-- The frame pointer
local _verbose = nil;				-- turn on debug
local _serverName = nil;			-- set to current realm when loaded
local _playerName = nil;			-- set to name of player when known
local _tabNoBottomTab = nil;		-- if bottom tab cannot be enabled due to another mod
local _tabEnabled = nil;			-- tab disabled or enabled status
local _listCount = 0;				-- current number of entries in list
local _chatEventList = {};			-- events to watch and their handler functions
local _highlightColors = {};		-- RGB colors to use for highlighting Badapples
local _partyMembers = {};			-- List of party members;
local _partyMembersTimeout = nil;	-- For when to purge old members
local _raidMembers = {};			-- List of raid members;
local _raidMembersTimeout = nil;	-- For when to purge old members
local _listSortOrder = nil;			-- Set to the current sort order
local _listSorted = {};				-- Table of sorted indices by sort order
local _ignoreList = {};				-- Populated with players on your ignore list


------------------------------------------------------------------------------
-- StaticPopup definitions
------------------------------------------------------------------------------
local _badapplesInvitePopup = {
	text = BADAPPLES_TEXT.INVITE_TEXT,
	button1 = TEXT(YES),
	button2 = TEXT(NO),
	sound = "igPlayerInvite",
	timeout = 20,
	whileDead = 1
};
local _badapplesAddPlayerPopup = {
	text = BADAPPLES_TEXT.PLAYER_ADD_TEXT,
	button1 = TEXT(ACCEPT),
	button2 = TEXT(CANCEL),
	hasEditBox = 1,
	maxLetters = 12,
	OnShow = function()
		getglobal(this:GetName().."EditBox"):SetFocus();
	end,
	OnHide = function()
		if (ChatFrameEditBox:IsVisible()) then
			ChatFrameEditBox:SetFocus();
		end
		getglobal(this:GetName().."EditBox"):SetText("");
	end,
	EditBoxOnEscapePressed = function()
		this:GetParent():Hide();
	end,
	timeout = 60,
	exclusive = 1,
	whileDead = 1
};
local _badapplesConfirmAddPopup = {
	text = BADAPPLES_TEXT.PLAYER_ADD_CONFIRM_TEXT,
	button1 = TEXT(YES),
	button2 = TEXT(NO),
	sound = "igCharacterInfoOpen",
	timeout = 60,
	exclusive = 1,
	whileDead = 1
};
local _badapplesConfirmRemovePopup = {
	text = BADAPPLES_TEXT.PLAYER_REMOVE_CONFIRM_TEXT,
	button1 = TEXT(YES),
	button2 = TEXT(NO),
	sound = "igCharacterInfoOpen",
	timeout = 60,
	exclusive = 1,
	whileDead = 1
};
local _badapplesConfirmRemoveAllPopup = {
	text = BADAPPLES_TEXT.REMOVEALL_CONFIRM_TEXT,
	button1 = TEXT(YES),
	button2 = TEXT(NO),
	sound = "igCharacterInfoOpen",
	timeout = 60,
	exclusive = 1,
	whileDead = 1
};
local _badapplesPartyInvitePopup = {
	text = BADAPPLES_TEXT.PARTY_INVITE_TEXT,
	button1 = BADAPPLES_TEXT.PARTY_INVITE_BUTTON,
	button2 = TEXT(DECLINE),
	OnCancel = function()
		DeclineGroup();
	end,
	sound = "igPlayerInvite",
	timeout = 60,
	whileDead = 1
};


------------------------------------------------------------------------------
-- Local functions
------------------------------------------------------------------------------
local function Badapples_GetNextParam(text)
	-- Extracts the next parameter out of the passed text, and returns it and
	-- the rest of the string
	for param, remain in string.gfind(text, "(%w+) +(.*)") do
		return param, remain;
	end
	return text;
end


local function Badapples_FormatName(text)
	-- Formats the indicated name as a player name (only first letter can be
	-- uppercase)
	return string.upper(string.sub(text, 1, 1))..string.lower(string.sub(text, 2));
end


local function Badapples_NameToLink(name)
	-- Converts the passed name to a player name link (that can be clicked on)
	-- but without showing the usual [..] around the name
	return "|Hplayer:"..name.."|h"..name.."|h";
end


local function Badapples_UpdateHighlightText()
	local r = floor((255 * _highlightColors.r) + 0.5);
	local g = floor((255 * _highlightColors.g) + 0.5);
	local b = floor((255 * _highlightColors.b) + 0.5);
	BAD_ON = format("|cff%02x%02x%02x", r, g, b);
end


local function Badapples_SetHighLightColor(values)
	if (values) then
		_highlightColors.r = values.r;
		_highlightColors.g = values.g;
		_highlightColors.b = values.b;
	else
		_highlightColors.r, _highlightColors.g, _highlightColors.b = ColorPickerFrame:GetColorRGB();
	end
	Badapples_UpdateHighlightText();
	Badapples_TargetFrameCheckFaction();
	if (_verbose) then
		DEFAULT_CHAT_FRAME:AddMessage(format("Highlight color is red %.3f, green %.3f, blue %.3f", _highlightColors.r, _highlightColors.g, _highlightColors.b));
	end
--  -- Update the color of the player names in the social screen
--	if (BadapplesFrame:IsVisible()) then
--		BadapplesFrame_ListUpdate();
--	end
end


local function Badapples_WarnPlayer(text, name, reason)
	-- Warn the player about a badapple by sending a formatted text message
	-- in the current chat frame and in the default chat frame (if these
	-- aren't the same).
	if (not reason) then
		reason = BADAPPLES_TEXT.NO_REASON;
	end
	for i = 2, NUM_CHAT_WINDOWS do
		local chatFrame = getglobal("ChatFrame"..i);
		if (chatFrame:IsVisible()) then
			chatFrame:AddMessage(string.format(text, name, reason));
			break;
		end
	end
	DEFAULT_CHAT_FRAME:AddMessage(string.format(text, name, reason));
end


local function Badapples_RegisterEvents(register)
	-- If register is set, then register for events, otherwise unregister
	if (register == 1) then
		_thisFrame:RegisterEvent("PARTY_MEMBERS_CHANGED");
		_thisFrame:RegisterEvent("PARTY_MEMBER_ENABLED");
		_thisFrame:RegisterEvent("PARTY_MEMBER_DISABLED");
		_thisFrame:RegisterEvent("RAID_ROSTER_UPDATE");
		_thisFrame:RegisterEvent("PLAYER_TARGET_CHANGED");
		_thisFrame:RegisterEvent("IGNORELIST_UPDATE");
	else
		_thisFrame:UnregisterEvent("PARTY_MEMBERS_CHANGED");
		_thisFrame:UnregisterEvent("PARTY_MEMBER_ENABLED");
		_thisFrame:UnregisterEvent("PARTY_MEMBER_DISABLED");
		_thisFrame:UnregisterEvent("RAID_ROSTER_UPDATE");
		_thisFrame:UnregisterEvent("PLAYER_TARGET_CHANGED");
		_thisFrame:UnregisterEvent("IGNORELIST_UPDATE");
	end
end


local function Badapples_HookNeededFunctions()
	-- Only once we have been loaded do we hook Badapples into the various UI
	-- functions...

	-- Replace ChatFrame_OnEvent so we can process chat events to highlight
	-- Badapple player names
	_originalChatFrame_OnEvent = ChatFrame_OnEvent;
	ChatFrame_OnEvent = Badapples_ChatFrameOnEvent;

	-- Replace ChatEdit_UpdateHeader so we can highlight Badapple player names
	-- if we send them a tell
	_originalChatEdit_UpdateHeader = ChatEdit_UpdateHeader;
	ChatEdit_UpdateHeader = Badapples_ChatEditUpdateHeader;

	-- Replace SetItemRef so we can check player links for Badapples
	_originalSetItemRef = SetItemRef;
	SetItemRef = Badapples_SetItemRef;

	-- Replace StaticPopup_Show so we can check for party invites from
	-- Badapples so as to use the "BADAPPLE_PARTY_INVITE" popup
	_originalStaticPopup_Show = StaticPopup_Show;
	StaticPopup_Show = Badapples_StaticPopupShow;

	-- Replace InviteByName so we can check for invitations to Badapples and
	-- Use the "BADAPPLE_INVITE" confirmation popup
	_originalInviteByName = InviteByName;
	InviteByName = Badapples_InviteByName;

	-- Replace TargetFrame_CheckFaction and GameTooltip_UnitColor so we can
	-- introduce our own "faction style" highlighting for Badapples
	_originalTargetFrame_CheckFaction = TargetFrame_CheckFaction;
	TargetFrame_CheckFaction = Badapples_TargetFrameCheckFaction;
	_originalGameTooltip_UnitColor = GameTooltip_UnitColor;
	GameTooltip_UnitColor = Badapples_GameTooltipUnitColor;

	-- Replace the original PanelTemplates_UpdateTabs and FriendsFrame_Update
	-- functions so we can handle selection of our tabs.
	_originalPanelTemplates_UpdateTabs = PanelTemplates_UpdateTabs;
	PanelTemplates_UpdateTabs = Badapples_PanelTemplatesUpdateTabs;
	_originalFriendsFrame_Update = FriendsFrame_Update;
	FriendsFrame_Update = Badapples_FriendsFrameUpdate;
end


local function Badapples_UpdateIgnoreList()
	-- Copies the currently ignored player names into the local _ignoreList
	_ignoreList = {};
	for index = 1, GetNumIgnores() do
		local name = GetIgnoreName(index);
		if (name and (name ~= "")) then
			name = Badapples_FormatName(name);
			_ignoreList[name] = 1;
		end
	end
end


local function Badapples_CompareOnNameAtoZ(name1, name2)
	return name1 < name2;
end


local function Badapples_CompareOnNameZtoA(name1, name2)
	return name2 < name1;
end


local function Badapples_CompareOnReasonAtoZ(name1, name2)
	local reason1 = BadapplesState.Servers[_serverName].List[name1].Reason;
	local reason2 = BadapplesState.Servers[_serverName].List[name2].Reason;
	if (not reason1) then
		return false;
	end
	if (not reason2) then
		return true;
	end
	return reason1 < reason2;
end


local function Badapples_CompareOnReasonZtoA(name1, name2)
	local reason1 = BadapplesState.Servers[_serverName].List[name1].Reason;
	local reason2 = BadapplesState.Servers[_serverName].List[name2].Reason;
	if (not reason2) then
		return false;
	end
	if (not reason1) then
		return true;
	end
	return reason2 < reason1;
end


local function Badapples_SortList(sortBy)
	-- Creates the _listSorted list that can be used to return the values of
	-- the Badapples list in the appropriate sorted order
	_listSorted = {};
	for name in pairs(BadapplesState.Servers[_serverName].List) do
		table.insert(_listSorted, name);
	end
	if (sortBy == BADAPPLES_TEXT.SORTBY_NAME) then
		table.sort(_listSorted, Badapples_CompareOnNameAtoZ);
		_listSortOrder = BADAPPLES_TEXT.SORTBY_NAME;
	elseif (sortBy == BADAPPLES_TEXT.SORTBY_NAME_REVERSE) then
		table.sort(_listSorted, Badapples_CompareOnNameZtoA);
		_listSortOrder = BADAPPLES_TEXT.SORTBY_NAME_REVERSE;
	elseif (sortBy == BADAPPLES_TEXT.SORTBY_REASON) then
		table.sort(_listSorted, Badapples_CompareOnReasonAtoZ);
		_listSortOrder = BADAPPLES_TEXT.SORTBY_REASON;
	elseif (sortBy == BADAPPLES_TEXT.SORTBY_REASON_REVERSE) then
		table.sort(_listSorted, Badapples_CompareOnReasonZtoA);
		_listSortOrder = BADAPPLES_TEXT.SORTBY_REASON_REVERSE;
	else
		_listSortOrder = nil;
	end
end


local function Badapples_CheckForOtherModTab()
	-- Returns 1 if there is another mod already using a 5th social tab, or
	-- nil otherwise
	if (FriendsFrameTab5 or (FriendsFrame.numTabs == 5)) then
		return 1;
	end
	return nil;
end


local function Badapples_GetTodaysDate()
	-- Gets the current date (from the client machine) and converts it to the
	-- preferred Badapples storage format.
	return date("%m/%d/%y");
end


local function Badapples_List()
	-- Lists the current players on the Badapples list and the reasons they
	-- are there.  This call always resorts the list into by name order.
	if (_listSortOrder ~= BADAPPLES_TEXT.SORTBY_NAME) then
		Badapples_SortList(BADAPPLES_TEXT.SORTBY_NAME);
	end
	if (_listCount > 0) then
		if (_listCount == 1) then
			DEFAULT_CHAT_FRAME:AddMessage(EM_ON.."There is 1 player on the Badapples list"..EM_OFF);
		else
			DEFAULT_CHAT_FRAME:AddMessage(EM_ON.."There are ".._listCount.." players on the Badapples list"..EM_OFF);
		end
	else
		DEFAULT_CHAT_FRAME:AddMessage(EM_ON.."There are no players on the Badapples list"..EM_OFF);
		return;
	end
	for index, name in ipairs(_listSorted) do
		local reason = BadapplesState.Servers[_serverName].List[name].Reason;
		if (not reason) then
			reason = BADAPPLES_TEXT.NO_REASON;
		end
		DEFAULT_CHAT_FRAME:AddMessage(format(BADAPPLES_TEXT.LIST_FORMAT, name, reason));
	end
end


local function Badapples_Status(name, silent)
	-- Queries and displays the status of the indicated player, returning 1 if
	-- the player is in the Badapples list or nil otherwise.  If the silent
	-- parameter is not nil then no output is generated.
	if (not name or (name == "")) then
		if (not silent) then
			DEFAULT_CHAT_FRAME:AddMessage(BADAPPLES_TEXT.PLAYERNAME_FAILED);
		end
		return nil;
	end
	local player = Badapples_FormatName(name);
	if (BadapplesState.Servers[_serverName].List[player]) then
		if (not silent) then
			local reason = BadapplesState.Servers[_serverName].List[player].Reason;
			if (not reason) then
				reason = BADAPPLES_TEXT.NO_REASON;
			end
			DEFAULT_CHAT_FRAME:AddMessage(format(BADAPPLES_TEXT.STATUS_BAD, player, reason));
		end
		return 1;
	else
		if (not silent) then
			DEFAULT_CHAT_FRAME:AddMessage(format(BADAPPLES_TEXT.STATUS_GOOD, player));
		end
	end
	return nil;
end


local function Badapples_Add(name_and_reason)
	-- Adds the indicated player (with reason if provided) to the Badapples
	-- list, returning 1 if the player was added successfully (or is already
	-- present) or nil otherwise.
	if (not name_and_reason or (name_and_reason == "")) then
		DEFAULT_CHAT_FRAME:AddMessage(BADAPPLES_TEXT.PLAYERNAME_FAILED);
		return nil;
	end
	local name, reason = Badapples_GetNextParam(name_and_reason);
	local player = Badapples_FormatName(name);
	if (player == _playerName) then
		DEFAULT_CHAT_FRAME:AddMessage(BADAPPLES_TEXT.PLAYERNAME_ISSELF);
		return nil;
	end
	if (reason and (string.len(reason) > BADAPPLES_MAXIMUM_REASON_LENGTH)) then
		reason = string.sub(reason, 1, BADAPPLES_MAXIMUM_REASON_LENGTH);
	end
	if (BadapplesState.Servers[_serverName].List[player]) then
		BadapplesState.Servers[_serverName].List[player].Reason = reason;
		BadapplesState.Servers[_serverName].List[player].Date = Badapples_GetTodaysDate();
		if (not reason) then
			reason = BADAPPLES_TEXT.NO_REASON;
		end
		DEFAULT_CHAT_FRAME:AddMessage(format(BADAPPLES_TEXT.UPDATE_CONFIRM, player, reason));
	else
		BadapplesState.Servers[_serverName].List[player] = {};
		BadapplesState.Servers[_serverName].List[player].Reason = reason;
		BadapplesState.Servers[_serverName].List[player].Date = Badapples_GetTodaysDate();
		if (_listCount == 0) then
			-- First player added to list, so register events as well
			_listCount = 1;
		else
			_listCount = _listCount + 1;
		end
		Badapples_SortList(_listSortOrder);
		if (not reason) then
			reason = BADAPPLES_TEXT.NO_REASON;
		end
		DEFAULT_CHAT_FRAME:AddMessage(format(BADAPPLES_TEXT.ADD_CONFIRM, player, reason));
	end
	-- Update the Badapples frame and target display
	if (BadapplesFrame:IsVisible()) then
		BadapplesFrame.SelectedName = player;
		BadapplesFrame_ListUpdate();
	end
	Badapples_TargetFrameCheckFaction();
	return 1;
end


local function Badapples_Remove(name)
	if (not name or (name == "")) then
		DEFAULT_CHAT_FRAME:AddMessage(BADAPPLES_TEXT.PLAYERNAME_FAILED);
		return;
	end
	local player = Badapples_FormatName(name);
	if (BadapplesState.Servers[_serverName].List[player]) then
		BadapplesState.Servers[_serverName].List[player] = nil;
		if (_listCount == 1) then
			-- Last player removed, so unregister events as well
			_listCount = 0;
		else
			_listCount = _listCount - 1;
		end
		Badapples_SortList(_listSortOrder);
		DEFAULT_CHAT_FRAME:AddMessage(format(BADAPPLES_TEXT.REMOVE_CONFIRM, player));
		-- Update the Badapples frame and target display
		if (BadapplesFrame:IsVisible()) then
			BadapplesFrame_ListUpdate();
		end
		Badapples_TargetFrameCheckFaction();
	else
		DEFAULT_CHAT_FRAME:AddMessage(format(BADAPPLES_TEXT.REMOVE_NOTFOUND, player));
	end
end


local function Badapples_RemoveAll(confirm)
	-- Removes all the player entries in the list
	if (_listCount > 0) then
		if (not confirm or (confirm ~= BADAPPLES_TEXT.COMMAND_REMOVEALL_CONFIRM)) then
			_originalStaticPopup_Show("BADAPPLE_REMOVEALL");
			return;
		end
		BadapplesState.Servers[_serverName].List = {};
		_listCount = 0;
		-- Update the sorted list to be empty to
		Badapples_SortList(_listSortOrder);
		-- Update the Badapples frame and target display
		if (BadapplesFrame:IsVisible()) then
			BadapplesFrame_ListUpdate();
		end
		Badapples_TargetFrameCheckFaction();
	end
	DEFAULT_CHAT_FRAME:AddMessage(BADAPPLES_TEXT.REMOVEALL_CONFIRM);
end


local function Badapples_CheckParty()
	-- Checks all party members as to whether or not they are Badapples,
	-- keeping track of which ones we have already warned the player about.
	-- Note that because the PARTY_MEMBERS_CHANGED event may signal first that
	-- there are no other players (even if there are) and then that there are
	-- other players (if there are) we do not want to remove players from the
	-- _partyMembers list immediately, but set a flag and delete them at a
	-- later time (via Badapples_OnUpdate).  So first we start by setting all
	-- the current members as pending deletion...
	for name in pairs(_partyMembers) do
		_partyMembers[name] = -1;
	end
	-- Now process all currently known members
	for i = 1, 4 do
		local name = UnitName("party"..i);
		if (name and (name ~= "")) then
			name = Badapples_FormatName(name);
			if (not _partyMembers[name]) then
				if (BadapplesState.Servers[_serverName].List[name]) then
					-- Uh oh, new party member is on the Badapples list!
					Badapples_WarnPlayer(BADAPPLES_TEXT.PARTY_WARNING, name, BadapplesState.Servers[_serverName].List[name].Reason);
				elseif (_ignoreList[name]) then
					-- New party member is on the ignore list!
					Badapples_WarnPlayer(BADAPPLES_TEXT.PARTY_IGNORE_WARNING, name);
				end
			end
			_partyMembers[name] = 1;
		end
	end
	-- Set the pending delete time and enable the OnUpdate hook
	_partyMembersTimeout = GetTime() + BADAPPLES_PARTY_CLEANUP_DELAY;
	Badapples:SetScript("OnUpdate", Badapples_OnUpdate);
end


local function Badapples_CheckRaid()
	-- Checks all raid members as to whether or not they are Badapples using
	-- the same algorithm for cleanup as for party members (although probably
	-- not required in this case)
	for name in pairs(_raidMembers) do
		_raidMembers[name] = -1;
	end
	-- Now process all currently known members
	for i = 1, 40 do
		local name = GetRaidRosterInfo(i);
		if (name and (name ~= "")) then
			name = Badapples_FormatName(name);
			if (not _raidMembers[name]) then
				if (BadapplesState.Servers[_serverName].List[name]) then
					-- Uh oh, new raid member is on the Badapples list!
					Badapples_WarnPlayer(BADAPPLES_TEXT.RAID_WARNING, name, BadapplesState.Servers[_serverName].List[name].Reason);
				elseif (_ignoreList[name]) then
					-- New raid member is on the ignore list!
					Badapples_WarnPlayer(BADAPPLES_TEXT.RAID_IGNORE_WARNING, name);
				end
			end
			_raidMembers[name] = 1;
		end
	end
	-- Set the pending delete time and enable the OnUpdate hook
	_raidMembersTimeout = GetTime() + BADAPPLES_RAID_CLEANUP_DELAY;
	Badapples:SetScript("OnUpdate", Badapples_OnUpdate);
end


local function Badapples_GetDateAdded(name)
	-- Returns the date when the entry was added for the given player name,
	-- converting it to a format for display to the user.
	if (not name or (name == "")) then
		return nil;
	end
	local player = Badapples_FormatName(name);
	if (BadapplesState.Servers[_serverName].List[player]) then
		if (BadapplesState.Servers[_serverName].List[player].Date) then
			for mm, dd, yy in string.gfind(BadapplesState.Servers[_serverName].List[player].Date, "(%w+)/(%w+)/(%w+)") do
				local month = BADAPPLES_TEXT["MONTHNAME_"..mm];
				if (string.sub(dd, 1, 1) == "0") then
					dd = string.sub(dd, 2);
				end
				return dd.." "..month.." "..yy;
			end
		end
	end
	return nil;
end


------------------------------------------------------------------------------
-- Loadtime functions
------------------------------------------------------------------------------
local function Badapples_VariablesLoaded()
	-- Called for the VARIABLES_LOADED event, this function retrieves the
	-- current settings and sets the realm name.  Version specific processing
	-- is also done here.
	_serverName = GetRealmName();
	if (not BadapplesState) then
		BadapplesState = {};
	end
	if (not BadapplesState.Version) then
		BadapplesState.Version = BADAPPLES_VERSION;
	end
	if (not BadapplesState.Colors) then
		BadapplesState.Colors = {};
		BadapplesState.Colors.r = BADAPPLES_DEFAULT_HIGHLIGHT_R;
		BadapplesState.Colors.g = BADAPPLES_DEFAULT_HIGHLIGHT_G;
		BadapplesState.Colors.b = BADAPPLES_DEFAULT_HIGHLIGHT_B;
	end
	_highlightColors = BadapplesState.Colors;
	Badapples_UpdateHighlightText();
	if (not BadapplesState.Servers) then
		BadapplesState.Servers = {};
	end
	if (not BadapplesState.Servers[_serverName]) then
		BadapplesState.Servers[_serverName] = {};
	end
	if (not BadapplesState.Servers[_serverName].List) then
		BadapplesState.Servers[_serverName].List = {};
	end

	-- Hook all various functions we need
	Badapples_HookNeededFunctions();

	-- Update _listCount
	_listCount = 0;
	for name in pairs(BadapplesState.Servers[_serverName].List) do
		_listCount = _listCount + 1;
	end
	if ((_listCount > 0) and _verbose) then
		DEFAULT_CHAT_FRAME:AddMessage("Badapples loaded ".._listCount.." entries");
	end

	-- Process any version changes
	if (BadapplesState.Version ~= BADAPPLES_VERSION) then
		if (_verbose) then
			DEFAULT_CHAT_FRAME:AddMessage("Upgrading from Badapples version "..BadapplesState.Version);
		end
		if (BadapplesState.Version < "1.02") then
			-- Reset default tab selection for each player
			for server in pairs(BadapplesState.Servers) do
				if (BadapplesState.Servers[server].Characters) then
					for player in pairs(BadapplesState.Servers[server].Characters) do
						if (BadapplesState.Servers[server].Characters[player].Tab ~= BADAPPLES_TEXT.DISABLE_TAB) then
							BadapplesState.Servers[server].Characters[player].Tab = BADAPPLES_TEXT.ENABLE_FRIENDS_TAB;
						end
					end
				end
			end
		end
		BadapplesState.Version = BADAPPLES_VERSION;
	end
end


local function Badapples_PlayerLoaded()
	-- This function is called for the PLAYER_LOGIN event and checks to see if
	-- the playername is known so the player's per character settings can be
	-- retrieved.
	_playerName = UnitName("player");
	-- Get the user's setting for the social tab
	if (not BadapplesState.Servers[_serverName].Characters) then
		BadapplesState.Servers[_serverName].Characters = {};
	end
	if (not BadapplesState.Servers[_serverName].Characters[_playerName]) then
		BadapplesState.Servers[_serverName].Characters[_playerName] = {};
	end
	if (not BadapplesState.Servers[_serverName].Characters[_playerName].Tab) then
		BadapplesState.Servers[_serverName].Characters[_playerName].Tab = BADAPPLES_TEXT.ENABLE_FRIENDS_TAB;
	end
	-- Get the value of _tabNoBottomTab and then set the tab status
	-- according to the player's setting.  Note that if user selection is
	-- the bottom tab and it cannot be used then the side tab will
	-- automatically be selected instead but this is not updated in the
	-- player's setup (unless they change it).
	_tabNoBottomTab = Badapples_CheckForOtherModTab();
	BadapplesFrame_SetTab(BadapplesState.Servers[_serverName].Characters[_playerName].Tab, 1);
end


------------------------------------------------------------------------------
-- Hook functions for ChatFrame
------------------------------------------------------------------------------
local function Badapples_ChatMsgSay(event)
	local originalchatstring = CHAT_SAY_GET;
	CHAT_SAY_GET = string.gsub(originalchatstring, "%%s", BAD_ON.."%%s"..BAD_OFF);
	_originalChatFrame_OnEvent(event);
	CHAT_SAY_GET = originalchatstring;
end


local function Badapples_ChatMsgWhisper(event)
	local originalchatstring = CHAT_WHISPER_GET;
	CHAT_WHISPER_GET = string.gsub(originalchatstring, "%%s", BAD_ON.."%%s"..BAD_OFF);
	_originalChatFrame_OnEvent(event);
	CHAT_WHISPER_GET = originalchatstring;
end


local function Badapples_ChatMsgWhisperInform(event)
	local originalchatstring = CHAT_WHISPER_INFORM_GET;
	CHAT_WHISPER_INFORM_GET = string.gsub(originalchatstring, "%%s", BAD_ON.."%%s"..BAD_OFF);
	_originalChatFrame_OnEvent(event);
	CHAT_WHISPER_INFORM_GET = originalchatstring;
end


local function Badapples_ChatMsgYell(event)
	local originalchatstring = CHAT_YELL_GET;
	CHAT_YELL_GET = string.gsub(originalchatstring, "%%s", BAD_ON.."%%s"..BAD_OFF);
	_originalChatFrame_OnEvent(event);
	CHAT_YELL_GET = originalchatstring;
end


local function Badapples_ChatMsgParty(event)
	local originalchatstring = CHAT_PARTY_GET;
	CHAT_PARTY_GET = string.gsub(originalchatstring, "%%s", BAD_ON.."%%s"..BAD_OFF);
	_originalChatFrame_OnEvent(event);
	CHAT_PARTY_GET = originalchatstring;
end


local function Badapples_ChatMsgRaid(event)
	local originalchatstring = CHAT_RAID_GET;
	CHAT_RAID_GET = string.gsub(originalchatstring, "%%s", BAD_ON.."%%s"..BAD_OFF);
	_originalChatFrame_OnEvent(event);
	CHAT_RAID_GET = originalchatstring;
end


local function Badapples_ChatMsgGuild(event)
	local originalchatstring = CHAT_GUILD_GET;
	CHAT_GUILD_GET = string.gsub(originalchatstring, "%%s", BAD_ON.."%%s"..BAD_OFF);
	_originalChatFrame_OnEvent(event);
	CHAT_GUILD_GET = originalchatstring;
end


local function Badapples_ChatMsgChannel(event)
	local originalchatstring = CHAT_CHANNEL_GET;
	CHAT_CHANNEL_GET = string.gsub(originalchatstring, "%%s", BAD_ON.."%%s"..BAD_OFF);
	_originalChatFrame_OnEvent(event);
	CHAT_CHANNEL_GET = originalchatstring;
end


local function Badapples_ChatMsgAfk(event)
	local originalchatstring = CHAT_AFK_GET;
	CHAT_AFK_GET = string.gsub(originalchatstring, "%%s", BAD_ON.."%%s"..BAD_OFF);
	_originalChatFrame_OnEvent(event);
	CHAT_AFK_GET = originalchatstring;
end


local function Badapples_ChatMsgDnd(event)
	local originalchatstring = CHAT_DND_GET;
	CHAT_DND_GET = string.gsub(originalchatstring, "%%s", BAD_ON.."%%s"..BAD_OFF);
	_originalChatFrame_OnEvent(event);
	CHAT_DND_GET = originalchatstring;
end


function Badapples_ChatFrameOnEvent(event)
	if (_chatEventList[event]) then
		-- All these events have the player name in arg2
		if (BadapplesState.Servers[_serverName].List[arg2]) then
			_chatEventList[event](event);
		else
			_originalChatFrame_OnEvent(event);
		end
	else
		_originalChatFrame_OnEvent(event);
	end
end


------------------------------------------------------------------------------
-- Hook function for SetItemRef
------------------------------------------------------------------------------
function Badapples_SetItemRef(link, text, button)
	-- Code based on orginal SetItemRef code (see ItemRef.lua).  Note that we
	-- won't try and prevent the user from whispering or inviting anyone who
	-- is a badapple, just warn them.
	if (string.sub(link, 1, 6) == "player" ) then
		local name = string.sub(link, 8);
		if (name and (name ~= "")) then
			-- Apply same substitution rule that Blizzard's SetItemRef code
			-- does to extract names out of their hyperlinks.
			name = gsub(name, "([^%s]*)%s+([^%s]*)%s+([^%s]*)", "%3");
			name = gsub(name, "([^%s]*)%s+([^%s]*)", "%2");
			name = Badapples_FormatName(name);
			if (BadapplesState.Servers[_serverName].List[name]) then
				-- Warn user about this badapple
				Badapples_WarnPlayer(BADAPPLES_TEXT.STATUS_BAD, name, BadapplesState.Servers[_serverName].List[name].Reason);
			elseif (_ignoreList[name]) then
				-- Warn user about this ignored player
				Badapples_WarnPlayer(BADAPPLES_TEXT.STATUS_IGNORE, name);
			elseif (IsShiftKeyDown()) then
				local staticPopup = StaticPopup_Visible("BADAPPLE_ADD");
				if (staticPopup) then
					getglobal(staticPopup.."EditBox"):SetText(name);
					return;
				end
			end
		end
	end
	_originalSetItemRef(link, text, button);
end


------------------------------------------------------------------------------
-- Hook function for StaticPopup_Show
------------------------------------------------------------------------------
function Badapples_StaticPopupShow(popupName, text_arg1, text_arg2)
	if ((popupName == "PARTY_INVITE") and text_arg1) then
		local name = Badapples_FormatName(text_arg1);
		if (name and (name ~= "")) then
			if (BadapplesState.Servers[_serverName].List[name]) then
				-- Warn user about this badapple
				Badapples_WarnPlayer(BADAPPLES_TEXT.STATUS_BAD, name, BadapplesState.Servers[_serverName].List[name].Reason);
				-- Use our replacement PARTY_INVITE dialog in badapple mode
				_badapplesPartyInvitePopup.text = BADAPPLES_TEXT.PARTY_INVITE_TEXT;
				return _originalStaticPopup_Show("BADAPPLE_PARTY_INVITE", text_arg1, text_arg2);
			elseif (_ignoreList[name]) then
				-- Warn user about this ignored player
				Badapples_WarnPlayer(BADAPPLES_TEXT.STATUS_IGNORE, name);
				-- Use our replacement PARTY_INVITE dialog in ignore mode
				_badapplesPartyInvitePopup.text = BADAPPLES_TEXT.PARTY_IGNORE_INVITE_TEXT;
				return _originalStaticPopup_Show("BADAPPLE_PARTY_INVITE", text_arg1, text_arg2);
			end
		end
	end
	return _originalStaticPopup_Show(popupName, text_arg1, text_arg2);
end


------------------------------------------------------------------------------
-- Hook function for InviteByName
------------------------------------------------------------------------------
function Badapples_InviteByName(name)
	if (not name or (name == "")) then
		-- Bad request
		return;
	end
	local playerName = Badapples_FormatName(name);
	if (BadapplesState.Servers[_serverName].List[playerName]) then
		-- Warn user about this badapple in Chat
		Badapples_WarnPlayer(BADAPPLES_TEXT.STATUS_BAD, playerName, BadapplesState.Servers[_serverName].List[playerName].Reason);
		-- Warn user about inviting player by dialog box in badapple mode
		_badapplesInvitePopup.text = BADAPPLES_TEXT.INVITE_TEXT;
		local dialogFrame = _originalStaticPopup_Show("BADAPPLE_INVITE", playerName);
		if (dialogFrame) then
			dialogFrame.data = playerName;
		end
	elseif (_ignoreList[playerName]) then
		-- Warn user about this ignored player in Chat
		Badapples_WarnPlayer(BADAPPLES_TEXT.STATUS_IGNORE, playerName);
		-- Warn user about inviting player by dialog box in ignore mode
		_badapplesInvitePopup.text = BADAPPLES_TEXT.INVITE_IGNORE_TEXT;
		local dialogFrame = _originalStaticPopup_Show("BADAPPLE_INVITE", playerName);
		if (dialogFrame) then
			dialogFrame.data = playerName;
		end
	else
		return _originalInviteByName(name);
	end
end


------------------------------------------------------------------------------
-- Hook function for TargetFrame_CheckFaction
------------------------------------------------------------------------------
function Badapples_TargetFrameCheckFaction()
	-- Sets the color of the target's name background if the target is a
	-- player on the Badapples list.  We start by calling the original
	-- function to set the various parameters, and then we check to see if we
	-- need to then change the color.
	_originalTargetFrame_CheckFaction();
	if (UnitIsPlayer("target")) then
		local name = UnitName("target");
		if (name and (name ~= "")) then
			name = Badapples_FormatName(name);
			if (BadapplesState.Servers[_serverName].List[name]) then
				-- We have a Badapple in the target, so we change the color
				-- only if the player is not attackable by us (i.e., they are
				-- not yet flagged) so as to leave the normal color clues for
				-- PvP combat.
				if (not UnitCanAttack("player", "target")) then
					TargetFrameNameBackground:SetVertexColor(0.9*_highlightColors.r, 0.9*_highlightColors.g, 0.9*_highlightColors.b);
				end
			end
		end
	end
end


------------------------------------------------------------------------------
-- Hook function for GameTooltip_UnitColor
------------------------------------------------------------------------------
function Badapples_GameTooltipUnitColor(unit)
	-- Determines the color to set the player's name in the Game tooltip
	-- display.  In this case if we don't set the color ourselves we drop
	-- through and call the original function.
	if (UnitIsPlayer(unit)) then
		local name = UnitName(unit);
		if (name and (name ~= "")) then
			name = Badapples_FormatName(name);
			if (BadapplesState.Servers[_serverName].List[name]) then
				-- We have a Badapple in the target, so we change the color
				-- only if the player is not attackable by us (i.e., they are
				-- not yet flagged) so as to leave the normal color clues for
				-- PvP combat.
				if (not UnitCanAttack("player", unit)) then
					return _highlightColors.r, _highlightColors.g, _highlightColors.b;
				end
			end
		end
	end
	return _originalGameTooltip_UnitColor(unit);
end


------------------------------------------------------------------------------
-- Hook function for ChatEdit_UpdateHeader
------------------------------------------------------------------------------
function Badapples_ChatEditUpdateHeader(editBox)
	-- Checks to see if the editbox header is being updated for a new tell
	-- target and if this target is a player in our Badapples list then modify
	-- the format string before calling the original update function.
	local type = editBox.chatType;
	local name = editBox.tellTarget;
	if (type and (type == "WHISPER") and name and (name ~= "")) then
		name = Badapples_FormatName(name);
		if (BadapplesState.Servers[_serverName].List[name]) then
			local originalchatstring = CHAT_WHISPER_SEND;
			CHAT_WHISPER_SEND = string.gsub(originalchatstring, "%%s", BAD_ON.."%%s"..BAD_OFF);
			_originalChatEdit_UpdateHeader(editBox);
			CHAT_WHISPER_SEND = originalchatstring;
			return;
		end
	end
	_originalChatEdit_UpdateHeader(editBox);
end


------------------------------------------------------------------------------
-- Frame and Button management functions
------------------------------------------------------------------------------
function BadapplesFrame_ListUpdate()
	-- Start with inits
	if (not BadapplesFrame.SortBy) then
		BadapplesFrame.SortBy = BADAPPLES_TEXT.SORTBY_NAME;
	end
	if (BadapplesFrame.SelectedName) then
		if (not BadapplesState.Servers[_serverName].List[BadapplesFrame.SelectedName]) then
			BadapplesFrame.SelectedName = nil;
		end
	end
	if (BadapplesFrame.SortBy ~= _listSortOrder) then
		Badapples_SortList(BadapplesFrame.SortBy);
	end

	-- Format string for the total players text
	if (_listCount > 0) then
		if (_listCount == 1) then
			BadapplesFrameTotals:SetText("1 Badapple");
		else
			BadapplesFrameTotals:SetText(_listCount.." Badapples");
		end
	else
		BadapplesFrameTotals:SetText("Badapples list is empty!");
	end

	-- Now get parameters for what to display
	local offset = FauxScrollFrame_GetOffset(BadapplesListScrollFrame);
	local showScrollBar = nil;
	local name, reason;
	local nameText, reasonText;
	if (_listCount > BADAPPLES_DISPLAY_COUNT) then
		showScrollBar = 1;
	end
	for i = 1, BADAPPLES_DISPLAY_COUNT do
		button = getglobal("BadapplesFrameButton"..i);
		nameText = getglobal("BadapplesFrameButton"..i.."Name");
		reasonText = getglobal("BadapplesFrameButton"..i.."Reason");
		index = i + offset;
		if (index <= _listCount) then
			name = _listSorted[index];
			button.Name = name;
			nameText:SetText(name);
--			nameText:SetTextColor(_highlightColors.r, _highlightColors.g, _highlightColors.b);
			reason = BadapplesState.Servers[_serverName].List[name].Reason;
			if (reason) then
				reasonText:SetText(reason);
			else
				reasonText:SetText("");
			end
			if (showScrollBar) then
				reasonText:SetWidth(205);
				WhoFrameColumn_SetWidth(220, BadapplesFrameReasonColumnHeader);
			else
				reasonText:SetWidth(225);
				WhoFrameColumn_SetWidth(240, BadapplesFrameReasonColumnHeader);
			end
			if (button.hasCursor) then
				button:OnEnterFunction();
			end
			if (BadapplesFrame.SelectedName == name) then
				button:LockHighlight();
			else
				button:UnlockHighlight();
			end
			button:Show();
		else
			nameText:SetText("");
			reasonText:SetText("");
			button:Hide();
		end
	end

	-- Update buttons and edit box for selected player
	if (BadapplesFrame.SelectedName) then
		BadapplesFrameRemoveButton:Enable();
		BadapplesFrameEditBox:SetMaxLetters(BADAPPLES_MAXIMUM_REASON_LENGTH);
		BadapplesFrameEditBox:ClearFocus();
		BadapplesFrameEditBox:Show();
		-- Use the backspace character (as a non-input character) to force a
		-- text update of the editbox, and store the actual text we want
		-- displayed in the object to be handled when the OnTextChanged event
		-- fires.  This is simply to force the editbox to show all the text
		-- when a new text string is shorter than the previous one (see
		-- corresponding code in Badapples.xml).
		BadapplesFrameEditBox:SetText("\b");
		reason = BadapplesState.Servers[_serverName].List[BadapplesFrame.SelectedName].Reason;
		if (reason) then
			BadapplesFrameEditBox.newText = reason;
		else
			BadapplesFrameEditBox.newText = "";
		end
	else
		BadapplesFrameRemoveButton:Disable();
		BadapplesFrameEditBox:SetText("");
		BadapplesFrameEditBox:Hide();
	end

	-- Control state of Add button based on what is targetted
	if (UnitIsPlayer("target")) then
		local name = UnitName("target");
		if (name and (name ~= "")) then
			name = Badapples_FormatName(name);
			if (BadapplesState.Servers[_serverName].List[name]) then
				BadapplesFrameAddButton:Disable();
			else
				BadapplesFrameAddButton:Enable();
			end
		else
			BadapplesFrameAddButton:Enable();
		end
	else
		BadapplesFrameAddButton:Enable();
	end

	-- Update scrollbar
	FauxScrollFrame_Update(BadapplesListScrollFrame, _listCount, BADAPPLES_DISPLAY_COUNT, BADAPPLES_FRAME_SCROLL_HEIGHT);
end


function BadapplesFrame_DropDownOnClick()
	-- Called when a dropdown item is selected
	if (this.value == "WHO") then
		SendWho("n-"..BadapplesDropDown.name);
	elseif (this.value == "EDIT") then
		BadapplesFrameEditBox:SetFocus();
	elseif (this.value == "REMOVE") then
		-- We don't confirm removes done via right-click
		Badapples_Remove(BadapplesDropDown.name);
	end
end


function BadapplesFrame_DropdownInitialize()
	local info;
	local date = Badapples_GetDateAdded(BadapplesDropDown.name);
	-- First do title using Player name and entry date (if known)
	info = {};
	if (date) then
		info.text = BadapplesDropDown.name.."  ("..date..")";
	else
		info.text = BadapplesDropDown.name
	end
	info.isTitle = 1;
	info.notCheckable = 1;
	UIDropDownMenu_AddButton(info);

	-- Add button for Who command
	info = {};
	info.text = "Who";
	info.notCheckable = 1;
	info.value = "WHO";
	info.owner = this;
	info.func = BadapplesFrame_DropDownOnClick;
	UIDropDownMenu_AddButton(info);

	-- Add button for Editing reason
	info = {};
	info.text = "Edit";
	info.notCheckable = 1;
	info.value = "EDIT";
	info.owner = this;
	info.func = BadapplesFrame_DropDownOnClick;
	UIDropDownMenu_AddButton(info);

	-- Add button for removing Player
	info = {};
	info.text = "Remove";
	info.notCheckable = 1;
	info.value = "REMOVE";
	info.func = BadapplesFrame_DropDownOnClick;
	UIDropDownMenu_AddButton(info);

	-- Finally add button for Cancel
	info = {};
	info.text = "Cancel";
	info.notCheckable = 1;
	info.func = BadapplesFrame_DropDownOnClick;
	UIDropDownMenu_AddButton(info);
end


function BadapplesFrame_ToggleSortBy(sortBy)
	if (sortBy == BADAPPLES_TEXT.SORTBY_NAME) then
		if (_listSortOrder == BADAPPLES_TEXT.SORTBY_NAME) then
			BadapplesFrame.SortBy = BADAPPLES_TEXT.SORTBY_NAME_REVERSE;
		else
			BadapplesFrame.SortBy = BADAPPLES_TEXT.SORTBY_NAME;
		end
	elseif (sortBy == BADAPPLES_TEXT.SORTBY_REASON) then
		if (_listSortOrder == BADAPPLES_TEXT.SORTBY_REASON) then
			BadapplesFrame.SortBy = BADAPPLES_TEXT.SORTBY_REASON_REVERSE;
		else
			BadapplesFrame.SortBy = BADAPPLES_TEXT.SORTBY_REASON;
		end
	end
	BadapplesFrame_ListUpdate();
end


function BadapplesFrameButton_OnClick(button)
	if ( button == "LeftButton" ) then
		HideDropDownMenu(1);
		BadapplesFrame.SelectedName = getglobal("BadapplesFrameButton"..this:GetID()).Name;
		BadapplesFrame_ListUpdate();
	else
		HideDropDownMenu(1);
		BadapplesFrame.SelectedName = getglobal("BadapplesFrameButton"..this:GetID()).Name;
		BadapplesFrame_ListUpdate();
		BadapplesDropDown.name = BadapplesFrame.SelectedName;
		BadapplesDropDown.initialize = BadapplesFrame_DropdownInitialize;
		BadapplesDropDown.displayMode = "MENU";
		ToggleDropDownMenu(1, nil, BadapplesDropDown, "cursor");
	end
end


function Badapples_ShowColorPicker()
	-- Open the ColorPickerFrame, making sure to close all other menus first
	CloseMenus();
	ColorPickerFrame.func = Badapples_SetHighLightColor;
	ColorPickerFrame.hasOpacity = nil;
	ColorPickerFrame.opacityFunc = nil;
	ColorPickerFrame.opacity = 0;
	ColorPickerFrame:SetColorRGB(_highlightColors.r, _highlightColors.g, _highlightColors.b);
	ColorPickerFrame.previousValues = {r = _highlightColors.r, g = _highlightColors.g, b = _highlightColors.b};
	ColorPickerFrame.cancelFunc = Badapples_SetHighLightColor;
	ShowUIPanel(ColorPickerFrame);
end


function BadapplesFrame_Add()
	-- If the current target is a suitable candidate, then prompt for
	-- confirmation, otherwise prompt for a player name.
	if (UnitIsPlayer("target")) then
		local name = UnitName("target");
		if (name and (name ~= "")) then
			name = Badapples_FormatName(name);
			if (not BadapplesState.Servers[_serverName].List[name]) then
				-- Request confirmation before we add the targetted player
				local dialogFrame = _originalStaticPopup_Show("BADAPPLE_ADD_CONFIRM", name);
				if (dialogFrame) then
					dialogFrame.data = name;
				end
				return;
			end
		end
	end
	_originalStaticPopup_Show("BADAPPLE_ADD");
end


function BadapplesFrame_Remove()
	if (BadapplesFrame.SelectedName) then
		local dialogFrame = StaticPopup_Show("BADAPPLE_REMOVE_CONFIRM", BadapplesFrame.SelectedName);
		if (dialogFrame) then
			dialogFrame.data = BadapplesFrame.SelectedName;
		end
	end
end


function BadapplesFrame_EditReason()
	if (BadapplesFrame.SelectedName and BadapplesState.Servers[_serverName].List[BadapplesFrame.SelectedName]) then
		local reason = BadapplesState.Servers[_serverName].List[BadapplesFrame.SelectedName].Reason;
		if (reason ~= BadapplesFrameEditBox:GetText()) then
			Badapples_Add(BadapplesFrame.SelectedName.." "..BadapplesFrameEditBox:GetText());
		end
	end
	BadapplesFrameEditBox:ClearFocus();
end


local function BadapplesFrame_EditBoxAddName()
	-- Called by the static popup dialog on accept or enter
	local name = getglobal(this:GetParent():GetName().."EditBox"):GetText();
	if (name and (name ~= "")) then
		if (Badapples_Status(name, 1)) then
			BadapplesFrame.SelectedName = Badapples_FormatName(name);
			Badapples_Status(name);
		else
			Badapples_Add(name);
		end
	end
end


function BadapplesFrame_SetTab(action, silent)
	-- Enables, disables, or toggles the Badapples social (FriendsFrame) tabs
	if (action == BADAPPLES_TEXT.TOGGLE_TAB) then
		-- Cycle through the tab states (friends, bottom, side)
		if (_tabEnabled == BADAPPLES_TEXT.ENABLE_FRIENDS_TAB) then
			action = BADAPPLES_TEXT.ENABLE_BOTTOM_TAB;
		elseif (_tabEnabled == BADAPPLES_TEXT.ENABLE_BOTTOM_TAB) then
			action = BADAPPLES_TEXT.ENABLE_SIDE_TAB;
		else
			action = BADAPPLES_TEXT.ENABLE_FRIENDS_TAB;
		end
	end
	if ((action == BADAPPLES_TEXT.ENABLE_BOTTOM_TAB) and _tabNoBottomTab) then
		action = BADAPPLES_TEXT.ENABLE_SIDE_TAB;
	end
	if (action == BADAPPLES_TEXT.ENABLE_FRIENDS_TAB) then
		if (_tabEnabled ~= action) then
			_tabEnabled = action;
			BadapplesFriendsFrameSideTab1:Hide();
			BadapplesFriendsFrameTab5:Hide();
			BadapplesFriendsFrameToggleTab3:Show();
			BadapplesIgnoreFrameToggleTab3:Show();
			BadapplesFrameToggleTab1:Show();
			BadapplesFrameToggleTab2:Show();
			BadapplesFrameToggleTab3:Show();
			if (FriendsFrame:IsVisible()) then
				if (BadapplesFrame:IsVisible()) then
					FriendsFrame.selectedTab = 1;
					FriendsFrame.showFriendsList = nil;
					FriendsFrame.showBadapplesList = 1;
				end
				PanelTemplates_UpdateTabs(FriendsFrame);
				FriendsFrame_Update();
			end
			BadapplesState.Servers[_serverName].Characters[_playerName].Tab = action;
		end
	elseif (action == BADAPPLES_TEXT.ENABLE_BOTTOM_TAB) then
		if (_tabEnabled ~= action) then
			_tabEnabled = action;
			BadapplesFriendsFrameSideTab1:Hide();
			BadapplesFriendsFrameTab5:Show();
			BadapplesFriendsFrameToggleTab3:Hide();
			BadapplesIgnoreFrameToggleTab3:Hide();
			BadapplesFrameToggleTab1:Hide();
			BadapplesFrameToggleTab2:Hide();
			BadapplesFrameToggleTab3:Hide();
			if (FriendsFrame:IsVisible()) then
				if (BadapplesFrame:IsVisible()) then
					FriendsFrame.selectedTab = BADAPPLES_TAB_ID;
				end
				PanelTemplates_UpdateTabs(FriendsFrame);
				FriendsFrame_Update();
			end
			BadapplesState.Servers[_serverName].Characters[_playerName].Tab = action;
		end
	elseif (action == BADAPPLES_TEXT.ENABLE_SIDE_TAB) then
		if (_tabEnabled ~= action) then
			_tabEnabled = action;
			BadapplesFriendsFrameTab5:Hide();
			BadapplesFriendsFrameSideTab1:Show();
			BadapplesFriendsFrameToggleTab3:Hide();
			BadapplesIgnoreFrameToggleTab3:Hide();
			BadapplesFrameToggleTab1:Hide();
			BadapplesFrameToggleTab2:Hide();
			BadapplesFrameToggleTab3:Hide();
			if (FriendsFrame:IsVisible()) then
				if (BadapplesFrame:IsVisible()) then
					FriendsFrame.selectedTab = BADAPPLES_TAB_ID;
				end
				PanelTemplates_UpdateTabs(FriendsFrame);
				FriendsFrame_Update();
			end
			BadapplesState.Servers[_serverName].Characters[_playerName].Tab = action;
		end
	elseif (action == BADAPPLES_TEXT.DISABLE_TAB) then
		if (_tabEnabled ~= action) then
			_tabEnabled = action;
			BadapplesFriendsFrameTab5:Hide();
			BadapplesFriendsFrameSideTab1:Hide();
			BadapplesFriendsFrameToggleTab3:Hide();
			BadapplesIgnoreFrameToggleTab3:Hide();
			BadapplesFrameToggleTab1:Hide();
			BadapplesFrameToggleTab2:Hide();
			BadapplesFrameToggleTab3:Hide();
			if (FriendsFrame:IsVisible()) then
				if (BadapplesFrame:IsVisible()) then
					FriendsFrame.selectedTab = BADAPPLES_TAB_ID;
				end
				PanelTemplates_UpdateTabs(FriendsFrame);
				FriendsFrame_Update();
			end
			BadapplesState.Servers[_serverName].Characters[_playerName].Tab = action;
		end
	else
		if (_verbose) then
			if (not action) then
				action = "(nil)";
			end
			DEFAULT_CHAT_FRAME:AddMessage("Unexpected action "..action.." for BadapplesFrame_SetTab");
		end
		return;
	end
	if (not silent) then
		DEFAULT_CHAT_FRAME:AddMessage(format(BADAPPLES_TEXT.TAB_CONFIRM, action));
	end
end


local function Badapples_Show()
	-- Forces the social window to show the Badapples list (if it isn't
	-- already visible)
	if (not BadapplesFrame:IsVisible()) then
		if (_tabEnabled == BADAPPLES_TEXT.ENABLE_FRIENDS_TAB) then
			FriendsFrame.selectedTab = 1;
			FriendsFrame.showFriendsList = nil;
			FriendsFrame.showBadapplesList = 1;
		else
			FriendsFrame.selectedTab = BADAPPLES_TAB_ID;
		end
		if (FriendsFrame:IsVisible()) then
			PanelTemplates_UpdateTabs(FriendsFrame);
			FriendsFrame_Update();
		else
			ShowUIPanel(FriendsFrame);
		end
	end
end


------------------------------------------------------------------------------
-- Frame management hook functions
------------------------------------------------------------------------------
function Badapples_PanelTemplatesUpdateTabs(frame)
	_originalPanelTemplates_UpdateTabs(frame);
	if (frame == FriendsFrame) then
		if (frame.selectedTab == BADAPPLES_TAB_ID) then
			PanelTemplates_SelectTab(BadapplesFriendsFrameTab5);
			BadapplesFriendsFrameSideTab1:Disable();
			if (GameTooltip:IsOwned(BadapplesFriendsFrameSideTab1)) then
				GameTooltip:Hide();
			end
		else
			PanelTemplates_DeselectTab(BadapplesFriendsFrameTab5);
			BadapplesFriendsFrameSideTab1:Enable();
		end
	end
end


function Badapples_FriendsFrameUpdate()
	-- This function checks for the currently selected FriendsFrame tab being
	-- the Badapples one, and handles that case, otherwise it call the
	-- original FriendsFrame_Update function.  Note that as of patch 1.8 the
	-- RaidFrame_ShowSubFrame name changed to FriendsFrame_ShowSubFrame.
	if (FriendsFrame.selectedTab == BADAPPLES_TAB_ID) then
		FriendsFrameTopLeft:SetTexture("Interface\\ClassTrainerFrame\\UI-ClassTrainer-TopLeft");
		FriendsFrameTopRight:SetTexture("Interface\\ClassTrainerFrame\\UI-ClassTrainer-TopRight");
		FriendsFrameBottomLeft:SetTexture("Interface\\FriendsFrame\\WhoFrame-BotLeft");
		FriendsFrameBottomRight:SetTexture("Interface\\FriendsFrame\\WhoFrame-BotRight");
		FriendsFrameTitleText:SetText("Badapples List");
		FriendsFrame_ShowSubFrame("BadapplesFrame");
	elseif (FriendsFrame.selectedTab == 1) then
		if (not FriendsFrame.showFriendsList and FriendsFrame.showBadapplesList) then
			FriendsFrameTopLeft:SetTexture("Interface\\ClassTrainerFrame\\UI-ClassTrainer-TopLeft");
			FriendsFrameTopRight:SetTexture("Interface\\ClassTrainerFrame\\UI-ClassTrainer-TopRight");
			FriendsFrameBottomLeft:SetTexture("Interface\\FriendsFrame\\WhoFrame-BotLeft");
			FriendsFrameBottomRight:SetTexture("Interface\\FriendsFrame\\WhoFrame-BotRight");
			FriendsFrameTitleText:SetText("Badapples List");
			FriendsFrame_ShowSubFrame("BadapplesFrame");
		else
			FriendsFrame.showBadapplesList = nil;
			_originalFriendsFrame_Update();
		end
	else
		_originalFriendsFrame_Update();
	end
end


------------------------------------------------------------------------------
-- OnLoad function
------------------------------------------------------------------------------
function Badapples_OnLoad()
	-- Record our frame pointer for later
	_thisFrame = this;

	-- Register slash command handler
	SLASH_BADAPPLES1 = "/badapples";
	SLASH_BADAPPLES2 = "/badapple";
	SLASH_BADAPPLES3 = "/bad";
		SlashCmdList["BADAPPLES"] = function(text)
		Badapples_SlashCommand(text);
	end

	-- Register for basic events
	_thisFrame:RegisterEvent("VARIABLES_LOADED");
	_thisFrame:RegisterEvent("PLAYER_LOGIN");
	_thisFrame:RegisterEvent("PLAYER_ENTERING_WORLD");
	_thisFrame:RegisterEvent("PLAYER_LEAVING_WORLD");

	-- Fill in the _chatEventList data
	_chatEventList["CHAT_MSG_SAY"] = Badapples_ChatMsgSay;
	_chatEventList["CHAT_MSG_WHISPER"] = Badapples_ChatMsgWhisper;
	_chatEventList["CHAT_MSG_WHISPER_INFORM"] = Badapples_ChatMsgWhisperInform
	_chatEventList["CHAT_MSG_YELL"] = Badapples_ChatMsgYell;
	_chatEventList["CHAT_MSG_PARTY"] = Badapples_ChatMsgParty;
	_chatEventList["CHAT_MSG_RAID"] = Badapples_ChatMsgRaid;
	_chatEventList["CHAT_MSG_GUILD"] = Badapples_ChatMsgGuild;
	_chatEventList["CHAT_MSG_CHANNEL"] = Badapples_ChatMsgChannel;
	_chatEventList["CHAT_MSG_AFK"] = Badapples_ChatMsgAfk;
	_chatEventList["CHAT_MSG_DND"] = Badapples_ChatMsgDnd;

	-- Add our Badapples frame to the FriendsFrame subframe list for if the
	-- Badapples social tab is enabled.  Note that as of patch 1.8 the
	-- RAIDFRAME_SUBFRAMES name changed to FRIENDSFRAME_SUBFRAMES.
	if (RAIDFRAME_SUBFRAMES) then
		table.insert(RAIDFRAME_SUBFRAMES, "BadapplesFrame");
	elseif (FRIENDSFRAME_SUBFRAMES) then
		table.insert(FRIENDSFRAME_SUBFRAMES, "BadapplesFrame");
	end

	-- Create a new BADAPPLE_PARTY_INVITE popup based on the PARTY_INVITE one
	StaticPopupDialogs["BADAPPLE_PARTY_INVITE"] = _badapplesPartyInvitePopup;
	StaticPopupDialogs["BADAPPLE_PARTY_INVITE"].OnShow = function()
		StaticPopupDialogs["PARTY_INVITE"].inviteAccepted = nil;
	end
	StaticPopupDialogs["BADAPPLE_PARTY_INVITE"].OnAccept = function()
		AcceptGroup();
		StaticPopupDialogs["PARTY_INVITE"].inviteAccepted = 1;
	end
	StaticPopupDialogs["BADAPPLE_PARTY_INVITE"].OnHide = function()
		if (not StaticPopupDialogs["PARTY_INVITE"].inviteAccepted) then
			DeclineGroup();
		end
	end

	-- Create a new BADAPPLE_INVITE popup for if we try and invite a Badapple
	StaticPopupDialogs["BADAPPLE_INVITE"] = _badapplesInvitePopup;
	StaticPopupDialogs["BADAPPLE_INVITE"].OnAccept = function(data)
		_originalInviteByName(data);
	end

	-- Create a new BADAPPLE_ADD popup for asking the name of a player to add
	-- to the Badapples list, based on the ADD_IGNORE one
	StaticPopupDialogs["BADAPPLE_ADD"] = _badapplesAddPlayerPopup;
	StaticPopupDialogs["BADAPPLE_ADD"].OnAccept = function()
		BadapplesFrame_EditBoxAddName();
	end
	StaticPopupDialogs["BADAPPLE_ADD"].EditBoxOnEnterPressed = function()
		BadapplesFrame_EditBoxAddName();
		this:GetParent():Hide();
	end

	-- Create new BADAPPLE_ADD_CONFIRM and BADAPPLE_REMOVE_CONFIRM popups for
	-- confirming adding or removing a player to or from the Badapples list
	StaticPopupDialogs["BADAPPLE_ADD_CONFIRM"] = _badapplesConfirmAddPopup;
	StaticPopupDialogs["BADAPPLE_ADD_CONFIRM"].OnAccept = function(data)
		Badapples_Add(data);
	end
	StaticPopupDialogs["BADAPPLE_REMOVE_CONFIRM"] = _badapplesConfirmRemovePopup;
	StaticPopupDialogs["BADAPPLE_REMOVE_CONFIRM"].OnAccept = function(data)
		Badapples_Remove(data);
	end

	-- Create a new BADAPPLE_REMOVEALL popup for confirming deletion of all
	-- Badapple entries
	StaticPopupDialogs["BADAPPLE_REMOVEALL"] = _badapplesConfirmRemoveAllPopup;
	StaticPopupDialogs["BADAPPLE_REMOVEALL"].OnAccept = function()
		Badapples_RemoveAll(BADAPPLES_TEXT.COMMAND_REMOVEALL_CONFIRM);
	end

	-- Announce ourselves
	DEFAULT_CHAT_FRAME:AddMessage(BADAPPLES_NAME.." v"..BADAPPLES_VERSION.." loaded");
end


------------------------------------------------------------------------------
-- OnEvent and OnUpdate functions
------------------------------------------------------------------------------
function Badapples_OnEvent(event)
	if (event == "PLAYER_TARGET_CHANGED") then
		if (BadapplesFrame:IsVisible()) then
			BadapplesFrame_ListUpdate();
		end

	elseif (event == "PARTY_MEMBERS_CHANGED") then
		if (GetNumRaidMembers() == 0) then
			Badapples_CheckParty();
		end

	elseif (event == "RAID_ROSTER_UPDATE") then
		Badapples_CheckRaid();

	elseif (event == "PLAYER_ENTERING_WORLD") then
		Badapples_RegisterEvents(1);
		Badapples_UpdateIgnoreList();
		if (_listCount > 0) then
			if (GetNumRaidMembers() > 0) then
				Badapples_CheckRaid();
			elseif (GetNumPartyMembers() > 0) then
				Badapples_CheckParty();
			end
		end

	elseif (event == "PLAYER_LEAVING_WORLD") then
		Badapples_RegisterEvents(0);
		Badapples:SetScript("OnUpdate", nil);

	elseif (event == "IGNORELIST_UPDATE") then
		Badapples_UpdateIgnoreList();

	elseif (event == "VARIABLES_LOADED") then
		Badapples_VariablesLoaded();

	elseif (event == "PLAYER_LOGIN") then
		Badapples_PlayerLoaded();

	end
end


function Badapples_OnUpdate()
	-- We only need this for knowing when to purge the party and raid data
	if (_partyMembersTimeout) then
		if (GetTime() > _partyMembersTimeout) then
			for name in pairs(_partyMembers) do
				if (_partyMembers[name] < 0) then
					_partyMembers[name] = nil;
				end
			end
			_partyMembersTimeout = nil;
		end
	end
	if (_raidMembersTimeout) then
		if (GetTime() > _raidMembersTimeout) then
			for name in pairs(_raidMembers) do
				if (_raidMembers[name] < 0) then
					_raidMembers[name] = nil;
				end
			end
			_raidMembersTimeout = nil;
		end
	end
	if (not _partyMembersTimeout and not _raidMembersTimeout) then
		Badapples:SetScript("OnUpdate", nil);
	end
end


------------------------------------------------------------------------------
-- Slash command function
------------------------------------------------------------------------------
function Badapples_SlashCommand(text)
	if (text) then
		local command, param = Badapples_GetNextParam(text);
		if (command == BADAPPLES_TEXT.COMMAND_LIST) then
			Badapples_List();
		elseif (command == BADAPPLES_TEXT.COMMAND_SHOW) then
			Badapples_Show();
		elseif ((command == BADAPPLES_TEXT.COMMAND_CHECK) or (command == BADAPPLES_TEXT.COMMAND_STATUS)) then
			Badapples_Status(param);
		elseif (command == BADAPPLES_TEXT.COMMAND_ADD) then
			Badapples_Add(param);
		elseif (command == BADAPPLES_TEXT.COMMAND_REMOVE) then
			Badapples_Remove(param);
		elseif (command == BADAPPLES_TEXT.COMMAND_REMOVEALL) then
			Badapples_RemoveAll();
		elseif ((command == BADAPPLES_TEXT.COMMAND_COLOR) or (command == BADAPPLES_TEXT.COMMAND_SETCOLOR)) then
			Badapples_ShowColorPicker();
		elseif (command == BADAPPLES_TEXT.COMMAND_NOTAB) then
			BadapplesFrame_SetTab(BADAPPLES_TEXT.DISABLE_TAB);
		elseif (command == BADAPPLES_TEXT.COMMAND_TOGGLETAB) then
			BadapplesFrame_SetTab(BADAPPLES_TEXT.TOGGLE_TAB);
		elseif (command == BADAPPLES_TEXT.COMMAND_DEBUGON) then
			_verbose = 1;
			DEFAULT_CHAT_FRAME:AddMessage(BADAPPLES_TEXT.DEBUGON_CONFIRM);
		elseif (command == BADAPPLES_TEXT.COMMAND_DEBUGOFF) then
			_verbose = nil;
			DEFAULT_CHAT_FRAME:AddMessage(BADAPPLES_TEXT.DEBUGOFF_CONFIRM);
		else
			DEFAULT_CHAT_FRAME:AddMessage(EM_ON..BADAPPLES_NAME.." v"..BADAPPLES_VERSION..EM_OFF);
			for _, string in ipairs(BADAPPLES_HELP) do
				DEFAULT_CHAT_FRAME:AddMessage(string);
			end
		end
	end
end


------------------------------------------------------------------------------
-- Exported functions
------------------------------------------------------------------------------
function BadapplesCheck(name)
	-- Returns the reason text, or BADAPPLES_TEXT.NO_REASON if the provided
	-- name is on the player's badapples list, or nil otherwise.
	if (_serverName and BadapplesState.Servers and BadapplesState.Servers[_serverName]) then
		if (name and (name ~= "")) then
			name = Badapples_FormatName(name);
			if (BadapplesState.Servers[_serverName].List[name]) then
				local reason = BadapplesState.Servers[_serverName].List[name].Reason;
				if (not reason) then
					reason = BADAPPLES_TEXT.NO_REASON;
				end
				return reason;
			end
		end
	end
end


function BadapplesColor()
	-- Returns the color used for indicating badapple names in the form:
	--   r, g, b, hex
	-- Where the hex parameter is the fully qualified color string (i.e., it
	-- starts with "|c").
	return _highlightColors.r, _highlightColors.g, _highlightColors.b, BAD_ON;
end

