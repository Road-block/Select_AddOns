local GetShapeshiftFormInfo, UnitBuff, UnitClass, GetPlayerBuff, CancelPlayerBuff, gsub, format = 
      GetShapeshiftFormInfo, UnitBuff, UnitClass, GetPlayerBuff, CancelPlayerBuff, string.gsub, string.format
local Tank = {WARRIOR = 2, DRUID = 1}
local _, class = UnitClass("player")
if not Tank[class] then return end
local Unwanted = {
  Spell_Holy_GreaterBlessingofSalvation = "Salvation", 
  Spell_Holy_SealOfSalvation = "Salvation", 
  Spell_Holy_SealOfProtection = "Blessing of Protection",
}

local addon = CreateFrame("Frame")
addon.eventManager = function()
  return this[event]~=nil and this[event](this,event,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11)
end
addon:SetScript("OnEvent",addon.eventManager)
addon:RegisterEvent("PLAYER_AURAS_CHANGED")

function addon:PLAYER_AURAS_CHANGED(event,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9)
  local _,_,tanking = GetShapeshiftFormInfo(Tank[class])
  if (tanking) then
    local buffIndex = 1
    local buffTexture = UnitBuff("player",buffIndex)
    while (buffTexture) do
      local unwanted = Unwanted[gsub(buffTexture,"Interface\\Icons\\","")]
      if (unwanted) then
        local buffId = buffIndex-1
        local checkTexture = GetPlayerBuffTexture(buffId)
        local check = (checkTexture) and Unwanted[gsub(checkTexture,"Interface\\Icons\\","")] or ""
        if unwanted == check then
          CancelPlayerBuff(buffId)
          UIErrorsFrame:AddMessage(format("Removed %s!",unwanted),0,1,0,1,2)
        end
        return
      end
      buffIndex = buffIndex + 1
      buffTexture = UnitBuff("player",buffIndex)
    end
  end
end

--[[
for debugging
  --Spell_Nature_AncestralGuardian = "Berserker Rage", 
  --Ability_Racial_BloodRage = "Bloodrage", 
  --Ability_Warrior_BattleShout = "Battle Shout", 
]]