if(GetLocale()=="frFR") then

end