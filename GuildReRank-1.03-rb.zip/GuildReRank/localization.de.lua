

if(GetLocale()=="deDE") then
	GRRG.Translation = {};
	
	GRRG.Translation["TITLE"] = "Guild ReRank";
	GRRG.Translation["WARNING"] = "\195\182ffne das Gilden Fenster und \195\182ffne dann nocheinmal Guild ReRank";
	GRRG.Translation["PROCESSING"] = "Warte auf Server...";
	GRRG.Translation["RANKID"] = "Rang ID";
	GRRG.Translation["RANKNAME"] = "Rang Name";
	GRRG.Translation["ONLINECOUNT"] = "Online";
	GRRG.Translation["TOTAL"] = "Total";
	
end