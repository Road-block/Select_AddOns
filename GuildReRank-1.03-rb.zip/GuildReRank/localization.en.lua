
GRRG.Translation = {};

GRRG.Translation["TITLE"] = "Guild ReRank";
GRRG.Translation["WARNING"] = "Open the Guild Window and Reopen Guild ReRank";
GRRG.Translation["PROCESSING"] = "Waiting for server...";
GRRG.Translation["RANKID"] = "Rank ID";
GRRG.Translation["RANKNAME"] = "Rank Name";
GRRG.Translation["ONLINECOUNT"] = "Online";
GRRG.Translation["TOTAL"] = "Total";