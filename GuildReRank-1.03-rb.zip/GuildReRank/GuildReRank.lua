-- Public calls should be via GRRG.Functions.[FunctionName]([args]). See API at the bottom.
GRRG = {};
GRRG.Debug = false;
GRRG.GuildNames = {};
GRRG.RankInfo = {};

local onLoad;
local showGRR;
local onEvent;
local updateGRRWindow;
local promoteAll;
local demoteAll;
local disableButtons;
local loadGuildData;

function onLoad( frame )
	SlashCmdList["GUILDRERANK"] = GRRG.Functions.ShowGRR;
	SLASH_GUILDRERANK1 = "/guildrerank";
	SLASH_GUILDRERANK2 = "/grr";
	if (GRRG.Debug) then getglobal("ChatFrame3"):AddMessage("GuildReRank: Loaded!", 1.0, 1.0, 0.3) end;
end

function showGRR( )
	loadGuildData();
	if (GuildControlGetNumRanks() ~= 0) then
		getglobal("GuildReRankFrameWarning"):Hide();
	else
		getglobal("GuildReRankFrameWarning"):Show();
	end
	getglobal("GuildReRankFrameProcessing"):Hide();
	getglobal("GuildReRankFrame"):Show();
	updateGRRWindow();
end

function onEvent( frame, event, arg1)
	if(event == "GUILD_ROSTER_UPDATE") then
		loadGuildData(true);
		updateGRRWindow();
	end
end

function updateGRRWindow( )
	local rankCount = GuildControlGetNumRanks();
	for i=1,rankCount do
		getglobal("GuildReRankFrameRow"..i.."RankID"):SetText(i);
		getglobal("GuildReRankFrameRow"..i.."RankName"):SetText(GRRG.RankInfo[i].Name);
		getglobal("GuildReRankFrameRow"..i.."OnlineCount"):SetText(GRRG.RankInfo[i].OnlineCount);
		getglobal("GuildReRankFrameRow"..i.."Total"):SetText(GRRG.RankInfo[i].Count);
		local row = getglobal("GuildReRankFrameRow"..i);
		getglobal(row:GetName().."Promote"):Enable();
		getglobal(row:GetName().."Demote"):Enable();
		if (i == 1 or i == 2) then  -- Can't promote GLs or promote TO GL
			getglobal(row:GetName().."Promote"):Disable();
		end
		if (i == rankCount) then
			getglobal(row:GetName().."Demote"):Disable();
		end
		row.rankID = i;
		row:Show();
	end
end

function promoteAll(rankID)
	if (rankID and CanGuildPromote() and rankID > 1) then
		getglobal("GuildReRankFrameProcessing"):Show();
		for k,v in pairs(GRRG.GuildNames[rankID]) do
			Chronos.schedule(k,GuildPromoteByName,v);
		end
	end
	showGRR();
end

function demoteAll(rankID)
	if (rankID and CanGuildDemote() and rankID < GuildControlGetNumRanks()) then
		getglobal("GuildReRankFrameProcessing"):Show();
		for k,v in pairs(GRRG.GuildNames[rankID]) do
			Chronos.schedule(k,GuildDemoteByName,v);
		end
	end
	showGRR();
end

function disableButtons()
	local rankCount = GuildControlGetNumRanks();
	for i=1,rankCount do
		local row = getglobal("GuildReRankFrameRow"..i);
		getglobal(row:GetName().."Promote"):Disable();
		getglobal(row:GetName().."Demote"):Disable();
		getglobal("GuildReRankFrameProcessing"):Show();
	end
end

function loadGuildData(eventFired)
	local name, rank, rankIndex, level, class, zone, note, officernote, online, status;
	if (not eventFired) then GuildRoster() end;
	local rankCount = GuildControlGetNumRanks();
	if (GRRG.Debug) then getglobal("ChatFrame3"):AddMessage("GuildReRank: loading Guild Data! Found ranks:"..rankCount, 1.0, 1.0, 0.3) end;
	for i=1,rankCount do
		GRRG.GuildNames[i] = {};
		if (not GRRG.RankInfo[i]) then GRRG.RankInfo[i] = {} end;
		GRRG.RankInfo[i].Name = GuildControlGetRankName(i);
		GRRG.RankInfo[i].Count = 0;
		GRRG.RankInfo[i].OnlineCount = 0;
	end
	local totalMembers = GetNumGuildMembers(true);
	for i=1,totalMembers do
		name, rank, rankIndex, level, class, zone, note, officernote, online, status = GetGuildRosterInfo(i);
		rankIndex = rankIndex + 1;
		table.insert(GRRG.GuildNames[rankIndex],name);   --Ex:  GRRG.GuildNames[1] = { Officer, Officertwo }
		GRRG.RankInfo[rankIndex].Count = GRRG.RankInfo[rankIndex].Count + 1;
		if (online) then
			GRRG.RankInfo[rankIndex].OnlineCount = GRRG.RankInfo[rankIndex].OnlineCount + 1;
		end
	end
end


-------------------------------------------------------------------------------
-- Generic error
-------------------------------------------------------------------------------
StaticPopupDialogs["GRRG_NotAllowed"] = {
  text = "You are not allowed to promote or demote.",
  button1 = TEXT(OKAY),
  OnAccept = function()
      -- do nothing, actually
  end,
  timeout = 0,
  whileDead = 1,
  hideOnEscape = 1,
  showAlert = 1,
};
--usage:  StaticPopup_Show ("GRRG_NotAllowed);


-------------------------------------------------------------------------------
-- Public API
-------------------------------------------------------------------------------

GRRG.Functions = {
	OnLoad = onLoad,
	ShowGRR = showGRR,
	OnEvent = onEvent,
	UpdateGRRWindow = updateGRRWindow,
	PromoteAll = promoteAll,
	DemoteAll = demoteAll,
	LoadGuildData = loadGuildData,
};
