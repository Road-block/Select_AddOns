

AtlasQuest
Zur Verf�gung gestellt von Thandrenn (aka Mystery8)
Email: mystery8@gmail.com
Forum: http://www.atlasmod.com/phpBB3/viewforum.php?f=7



�ber AtlasQuest:
=================

AtlasQuest ist ein Addon f�r Atlas oder AlphaMap, das eine Liste von Quests 
mit zus�tzlichen Informationen und den zugeh�rigen Belohnungen 
f�r alle Instanzen, Schlachtfelder und Au�enweltschlachtz�ge anzeigt. 

AtlasQuest wurde urspr�nglich von Asurn erstellt. 
Derzeit leitet Thandrenn (aka Mystery8) das Projekt.



�bersetzungen:
=============

EN: Thandrenn  (vorher Asurn und Lothaer)
DE: Telchar und Nalumis  (vorher Asurn und Nihlo)
CN: yeachan  (vorher DIY)



Lizenz:
========

AtlasQuest wird unter der GNU General Public License (GPL) vertrieben.
F�r den gesamten Lizenztext siehe: gpl-v2-de.txt
