local  UnitBuff, UnitClass, GetPlayerBuff, CancelPlayerBuff, GetPlayerBuffTexture, gsub, format = 
 UnitBuff, UnitClass, GetPlayerBuff, CancelPlayerBuff, GetPlayerBuffTexture, string.gsub, string.format
local _, class = UnitClass("player")
if class ~= "PALADIN" then return end
local Unwanted = {
  Spell_Shadow_Charm = "Siphon Blessing", -- 23418
}
local zones = {
  ["Blackwing Lair-Nefarian\'s Lair"] = true,
}

local addon = CreateFrame("Frame")
addon.eventManager = function()
  return this[event]~=nil and this[event](this)
end
addon:SetScript("OnEvent",addon.eventManager)
addon:RegisterEvent("PLAYER_AURAS_CHANGED")
addon:RegisterEvent("ZONE_CHANGED")
addon:RegisterEvent("ZONE_CHANGED_INDOORS")
addon:RegisterEvent("ZONE_CHANGED_NEW_AREA")
addon:RegisterEvent("PLAYER_ENTERING_WORLD")

function addon:PLAYER_AURAS_CHANGED()
  if not (addon._Nefarian) then return end
  local buffIndex = 1
  local buffTexture = UnitBuff("player",buffIndex)
  while (buffTexture) do
    local unwanted = Unwanted[gsub(buffTexture,"Interface\\Icons\\","")]
    if (unwanted) then
      local buffId = buffIndex-1
      local checkTexture = GetPlayerBuffTexture(buffId)
      local check = (checkTexture) and Unwanted[gsub(checkTexture,"Interface\\Icons\\","")] or ""
      if unwanted == check then
        CancelPlayerBuff(buffId)
        UIErrorsFrame:AddMessage(format("Removed %s!",unwanted),0,1,0,1,2)
        PlaySoundFile("Sound/SPELLS/Purge.wav")
      end
      return
    end
    buffIndex = buffIndex + 1
    buffTexture = UnitBuff("player",buffIndex)
  end
end

function addon:ZONE_CHANGED_NEW_AREA()
  local zone = GetZoneText()
  local subzone = GetSubZoneText()
  local check = format("%s-%s",zone,subzone)
  if zones[check] then
    addon._Nefarian = true
  else
    addon._Nefarian = false
  end
end
addon.ZONE_CHANGED, addon.ZONE_CHANGED_INDOORS, addon.PLAYER_ENTERING_WORLD =
addon.ZONE_CHANGED_NEW_AREA, addon.ZONE_CHANGED_NEW_AREA, addon.ZONE_CHANGED_NEW_AREA