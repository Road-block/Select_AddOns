--[[
--
--  EkRaidAttend 2.42
--
--  Author: Dargen of Eternal Keggers, Norgannon.
--          http://www.eternalkeggers.net
--
--  See "manual.html" for the documentation.
--  See "history.html" for the full change history.
--
--]]

-- ------
-- Saved variables
-- ------
EkRaidAttend_Data = {};   -- Attendance lists data
EkRaidAttend_Status = 0;  -- 0==Timed attendance timer is stopped, 1==Timed attendance timer is started.
EkRaidAttend_Len = 60;  -- Timed attendance interval in minutes.
EkRaidAttend_LastTitle = nil;   -- The name of the most recent attendance.
EkRaidAttend_PlayAttendSound = 1;  -- 1==Play sound when timed attendance is taken, 0==Don't play a sound
EkRaidAttend_ShowAttendNames = 0;  -- 0==Show no names in chat window, 1==Show online, 2=Show offline, 3=Show online and offline
EkRaidAttend_SaveAttendNames = 2;  -- 1==Save only online names, 2==Save online and offline names
EkRaidAttend_BossKillAttend = 0;   -- 0==Don't take attendance when a boss is killed, 1=Take attendance when a boss is killed.

-- New saved variables in version 2.0:
EkRaidAttend_TakeScreenshot = 0;  -- 0==No, 1==Yes, 2==Yes with raid window
EkRaidAttend_Comment = "";   -- Comment from the editbox that will be included at the end of the next attendance name.
EkRaidAttend_ClearComment = 1;  -- 1==Clear comment editbox after the next attendance is taken, 0==Don't clear it.
EkRaidAttend_UnsavedReminderStatus = 0;  -- 0==No, 1 == Yes, 2 == Prompt to reload UI.
EkRaidAttend_UnsavedReminderInterval = 15;  -- Time in minutes.
EkRaidAttend_ReloadUI = 0;   -- 0==No, 1==Yes (Prompt to reload UI when attendance is taken)
EkRaidAttend_TimedReminderStatus = 0;  -- 0==No, 1 == Yes, 2=Prompt.
EkRaidAttend_TimedReminderInterval = 10;  -- Time in minutes.
EkRaidAttend_InRaidFlag = nil;   -- nil==Not in a raid, 1==In a raid
EkRaidAttend_MovableWindow = 0;   -- 0==Window not movable, 1==Movable
EkRaidAttend_BossConfig = {};  -- Boss settings configured by user.
EkRaidAttend_RecordMainName = 1;  -- Record attendance using main character names: 0=No, 1=Yes.
EkRaidAttend_ShowVersionFlag = 0;   -- Show addon name, version number, slash command when entering game: 0=No, 1=Yes
EkRaidAttend_ShowStatusFlag = 0;   -- Show addon status information when entering game: 0=No, 1=Yes
EkRaidAttend_ResistCheckConfig = {}; -- Resist check configurations
EkRaidAttend_ItemCheckConfig = {}; -- Item check configurations

-- New saved variables in version 2.1:

-- New saved variables in version 2.2:
EkRaidAttend_DurabilityCheckConfig = 100; -- Durability check configuration (minimum durability value)

-- New saved variables in version 2.2.2:
EkRaidAttend_ShowLotsPrompt = 1;  -- 0==Don't display the "lots of attendances" prompt again, 1=Show it when user has lots of attendances.

-- New saved variables in version 2.3:
EkRaidAttend_FirstRun = nil;  -- nil==First time the addon has been run, 0==Not the first time.

-- New saved variables in version 2.4:
EkRaidAttend_MainNameUse = 1;  -- Use main character names in guild notes (0==No, 1==Yes)
EkRaidAttend_MainNameNote = 1;  -- Main character name is stored in: 1==Public note, 2==Officer note
EkRaidAttend_MainNameStart = "[";  -- Character(s) used to start the main character name (0 to 5 characters).
EkRaidAttend_MainNameEnd = "]";  -- Character(s) used to end the main character name (0 to 5 characters).
EkRaidAttend_WaitListSeparate = 1;  -- 1==Create separate attendance list for the wait list, 0==Append wait list names to main attendance list.
EkRaidAttend_WaitListAttend = 1;  -- 1==Record wait list names when attendance is taken, 0==Don't record wait list names in an attendance list.
EkRaidAttend_AutoTime = 0;  -- Time of next timed attendance (a time() value).
EkRaidAttend_LastTime = nil;  -- Time of last timed attendance (a time() value). Is nil until first attendance is taken.

-- ------
-- Variables not saved.
-- ------
EkRaidAttend_cVersion = "2.42";

EkRaidAttend_AddonName = "<EkAttend>";  -- Used at start of messages in chat frame.
EkRaidAttend_Test = 0;  -- 0==Normal mode, 1=Test mode.
EkRaidAttend_VarsLoaded = false;
EkRaidAttend_ForceZoneAttend = 0;
EkRaidAttend_ScreenshotWait = nil;  -- nil==Not waiting, 1==waiting.
EkRaidAttend_FriendsTab = nil;
EkRaidAttend_FriendsVis = nil;
EkRaidAttend_UnsavedReminderElapsed = EkRaidAttend_UnsavedReminderInterval * 60;
EkRaidAttend_ReloadFlag = nil;  -- nil==Don't reload UI, 1==Need to reload the UI.
EkRaidAttend_TimedReminderElapsed = 0;   -- EkRaidAttend_TimedReminderInterval * 60;
EkRaidAttend_RazorgoreYell = nil;

EkRaidAttend_DefPromptDelay = 1;  -- Default delay between prompt windows
EkRaidAttend_PromptTimer = nil;  -- nil==No prompt timer, not nil==Prompt frame time remaining.
EkRaidAttend_PromptDelay = nil;  -- nil==No delay, not nil==Delay between prompt frames
EkRaidAttend_ShowPrompts = {};  -- element is 1 if we want to show the user the prompt, else nil.
EkRaidAttend_DisabledRaidPrompts = {};   -- element is 1 if user has disabled prompt for remainder of this raid, else nil.
EkRaidAttend_StatusSep = "\t";  -- Separator character(s) between values in attendance list player status .

EkRaidAttend_old_CT_RADurability_Update = nil;  -- Used in hooking CT_RADurability_Update().

-- Values used for player status in each attendance list.
EkRaidAttend_PlayerStatus_OFFLINE = 0;
EkRaidAttend_PlayerStatus_ONLINE = 1;
EkRaidAttend_PlayerStatus_ADDED = 2;
EkRaidAttend_PlayerStatus_WAITLIST = 3;
EkRaidAttend_PlayerStatus_RESIST = 4;
EkRaidAttend_PlayerStatus_ITEM = 5;
EkRaidAttend_PlayerStatus_UNKNOWN = 6;
EkRaidAttend_PlayerStatus_DURABILITY = 7;

-- Keys for the _ShowPrompts[] and _DisabledRaidPrompts[] tables.
EkRaidAttend_PROMPT_TIMED_REMIND = "tr";  -- Prompt to start timed attendance
EkRaidAttend_PROMPT_RELOADUI_UNSAVED = "ru";  -- Prompt to reload ui (unsaved attendance reminder)
EkRaidAttend_PROMPT_LOTS_OF_ATTENDANCES = "la";  -- Prompt if user has lots of attendances saved
EkRaidAttend_PROMPT_RELOADUI_ATTEND = "ra";  -- Prompt to reload ui when attendance is taken

EkRaidAttend_PromptKeys = {
	EkRaidAttend_PROMPT_RELOADUI_UNSAVED,
	EkRaidAttend_PROMPT_TIMED_REMIND,
	EkRaidAttend_PROMPT_LOTS_OF_ATTENDANCES,
	EkRaidAttend_PROMPT_RELOADUI_ATTEND,
};

-- EkCheck configuration for this addon.
EkRaidAttend_EkCheck_Config = {
	addonName = "EkRaidAttend",
	funcPrefix = "EkRaidAttend_EkCheck_",
	defaultColumn = 11,
	columns = {
		{ heading="Version", width=60, show=11, sort=11, order="A", justify="CENTER", red=nil, green=nil, blue=nil },
	},
};

EkRaidAttend_GuildInfo = {};
EkRaidAttend_GuildRosterFlag = nil;
EkRaidAttend_GuildRosterUpdates = 0;


-- -----------
-- These are the mob names that will trigger an attendance
-- when your computer sees the "<Mob_Name> dies." message.
--
-- The names listed here must EXACTLY match the name that
-- gets displayed in the combat log window when the mob dies.
--
-- You may also have to be within a certain distance of the
-- mob when it dies in order to see the death message.
-- -----------

EkRaidAttend_Bosses = {
	{["header"] = 1, ["enabled"] = 1, ["name"] = "Blackwing Lair"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Broodlord Lashlayer"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Chromaggus"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Ebonroc"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Firemaw"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Flamegor"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Nefarian"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Razorgore the Untamed"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Vaelastrasz the Corrupt"},

	{["header"] = 1, ["enabled"] = 1, ["name"] = "Molten Core"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Baron Geddon"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Garr"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Gehennas"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Golemagg the Incinerator"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Lucifron"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Magmadar"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Majordomo Executus"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Ragnaros"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Shazzrah"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Sulfuron Harbinger"},

	{["header"] = 1, ["enabled"] = 1, ["name"] = "Naxxramas"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Anub'Rekhan"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Gluth"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Gothik the Harvester"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Grand Widow Faerlina"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Grobbulus"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Heigan the Unclean"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Highlord Mograine"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Instructor Razuvious"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Kel'Thuzad"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Lady Blaumeux"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Loatheb"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Maexxna"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Noth the Plaguebringer"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Patchwerk"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Sapphiron"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Sir Zeliek"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Thaddius"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Thane Korth'azz"},

	{["header"] = 1, ["enabled"] = 1, ["name"] = "Non-Instance"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Azuregos"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Emeriss"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Lethon"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Lord Kazzak"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Taerar"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Ysondre"},

	{["header"] = 1, ["enabled"] = 1, ["name"] = "Onyxia's Lair"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Onyxia"},

	{["header"] = 1, ["enabled"] = 1, ["name"] = "Ruins of Ahn'Qiraj"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Ayamiss the Hunter"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Buru the Gorger"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "General Rajaxx"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Kurinnaxx"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Moam"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Ossirian the Unscarred"},

	{["header"] = 1, ["enabled"] = 1, ["name"] = "Silithus"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Baron Kazum"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "High Marshal Whirlaxis"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Lord Skwol"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Prince Skaldrenox"},

	{["header"] = 1, ["enabled"] = 1, ["name"] = "Temple of Ahn'Qiraj"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Battleguard Sartura"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "C'Thun"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Emperor Vek'lor"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Emperor Vek'nilash"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Fankriss the Unyielding"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Lord Kri"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Ouro"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Princess Huhuran"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Princess Yauj"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "The Prophet Skeram"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Vem"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Viscidus"},

	{["header"] = 1, ["enabled"] = 1, ["name"] = "Zul'Gurub"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Bloodlord Mandokir"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Gahz'ranka"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Hakkar"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "High Priestess Arlokk"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "High Priestess Jeklik"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "High Priestess Mar'li"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "High Priest Thekal"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "High Priest Venoxis"},
	{["header"] = 0, ["enabled"] = 1, ["name"] = "Jin'do the Hexxer"},
};



function EkRaidAttend_OnLoad()
	-- --------------
	-- Adding is being loaded.
	-- --------------
	SLASH_ekraidattend1 = "/ekattend";
	SLASH_ekraidattend2 = "/ekat";
	SLASH_ekraidattend3 = "/ekraidattend";

	SlashCmdList["ekraidattend"] = function( msg )
		EkRaidAttend_Command(msg);
	end

	this:RegisterEvent("CHAT_MSG_COMBAT_HOSTILE_DEATH"); 
	this:RegisterEvent("CHAT_MSG_MONSTER_YELL"); 
	this:RegisterEvent("GUILD_ROSTER_UPDATE");
	this:RegisterEvent("PLAYER_LOGIN"); 
	this:RegisterEvent("SCREENSHOT_FAILED"); 
	this:RegisterEvent("SCREENSHOT_SUCCEEDED"); 
end


function EkRaidAttend_ShowVersion(print2)
	-- --------------
	-- Display current version of the addon.
	-- --------------
	local text = "EkRaidAttend " .. EkRaidAttend_cVersion .. " by Dargen, Eternal Keggers, Norgannon."
	if (print2) then
		EkRaidAttend_Print2(text);
	else
		EkRaidAttend_Print(text);
	end
end


function EkRaidAttend_ShowInvalid()
	-- --------------
	-- Display message when an invalid command is supplied.
	-- --------------
	EkRaidAttend_Print("Invalid command. For help type: /ekattend help");
end

function EkRaidAttend_OnEvent(event)
	-- --------------
	-- Envent handler.
	-- --------------
	if (event == "PLAYER_LOGIN") then
		if (not EkRaidAttend_VarsLoaded) then
			EkRaidAttend_VarsLoaded = true;

			if (EkRaidAttend_MovableWindow == 1) then
				EkRaidAttend_Frame_UISpecialFrame(1);
				EkRaidAttend_Frame_UIPanel(0);
				EkRaidAttend_Frame_MoveButton:Show();
			else
				EkRaidAttend_Frame_MoveButton:Hide();
				EkRaidAttend_Frame_UISpecialFrame(0);
				EkRaidAttend_Frame_UIPanel(1);
			end

			-- Initialize the attendance list used for browsing, etc.
			EkRaidAttend_ListsFrame_ListInit();

			-- Initialize the boss settings.
			EkRaidAttend_OptionsFrame_BossList_Config();

			if (EkRaidAttend_FirstRun == nil) then
				EkRaidAttend_Print("First run detected.");
			end
			if (EkRaidAttend_FirstRun == nil or EkRaidAttend_ShowVersionFlag == 1) then
				EkRaidAttend_ShowVersion();
				EkRaidAttend_Print("To open the window use /ekat, /ekattend, or /ekraidattend.");
			end
			if (EkRaidAttend_FirstRun == nil) then
				EkRaidAttend_FirstRun = 0;
			else
				-- Display some info to remind the user when the next attendance is,
				-- if timed attendance is turned on, etc.
				if (EkRaidAttend_ShowStatusFlag == 1) then
					EkRaidAttend_ShowStatus();
					EkRaidAttend_ShowInterval();
					EkRaidAttend_NextAttendance();
				end
			end

			-- Request an updated guild roster.
			if (IsInGuild()) then
				EkRaidAttend_GuildRoster();
			end

			if (EkCheck_RegisterAddon) then
				EkCheck_RegisterAddon(EkRaidAttend_EkCheck_Config);
			end
		end
		return;
	end

	if (not EkRaidAttend_VarsLoaded) then
		return;
	end

	if (EkRaidAttend_Test > 0) then
		-- Dump event on screen (testing mode only).
		EkRaidAttend_EventPrint(0, event, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
	end

	if (event == "SCREENSHOT_FAILED" or event == "SCREENSHOT_SUCCEEDED") then
		-- ----
		-- Handle screenshot results.
		-- ----
		if (EkRaidAttend_ScreenshotWait) then
			-- Restore original state from prior to screenshot as best we can.
			if (EkRaidAttend_FriendsTab) then
				PanelTemplates_SetTab(FriendsFrame, EkRaidAttend_FriendsTab);
				FriendsFrame_OnShow();
				if ( not EkRaidAttend_FriendsVis ) then
					HideUIPanel(FriendsFrame);
				end
			end

			EkRaidAttend_ScreenshotWait = nil;

			if (event == "SCREENSHOT_FAILED") then
				EkRaidAttend_Print("Screenshot failed.");
			else
				if (EkRaidAttend_TakeScreenshot == 1) then
					EkRaidAttend_Print("Screenshot taken (without raid window).");
				else
					EkRaidAttend_Print("Screenshot taken (with raid window).");
				end
			end
		end

	elseif (event == "CHAT_MSG_COMBAT_HOSTILE_DEATH") then
		-- ----
		-- Test for a boss kill.
		-- ----
		if (EkRaidAttend_BossKillAttend == 0) then
			return;
		end

		-- If not in raid, and test mode is disabled, then don't try to detect boss kills.
		if (GetNumRaidMembers() == 0 and EkRaidAttend_Test == 0) then
			return;
		end

		-- Detect if a boss dies.
		local pos1, pos2, val1 = string.find(arg1, "^(.+) dies.");
		if (val1) then
			-- Ignore Majordomo's death. He is handled in the monster yell section
			-- when he submits.
			if (val1 == "Majordomo Executus") then
				return;
			end

			-- Ignore The Prophet Skeram's death. He is handled in the monster yell section
			-- to avoid taking attendances when the false Skeram's die.
			if (val1 == "The Prophet Skeram") then
				return;
			end

			-- Ignore Razorgore's death if the raid wipes before killing Razorgore.
			-- He will yell two different things when these premature deaths occur.
			if (val1 == "Razorgore the Untamed" and EkRaidAttend_RazorgoreYell) then
				EkRaidAttend_RazorgoreYell = nil;
				return;
			end

			-- Scan the table of boss names for a match.
			local lowerval1 = string.lower(val1);
			for i=1, getn(EkRaidAttend_Bosses) do
				local boss = EkRaidAttend_Bosses[i];
				if (boss["header"] == 0) then
					if (boss["enabled"] == 1) then
						if (string.lower(boss["name"]) == lowerval1) then
							EkRaidAttend_TakeAttendance(1, "", "Boss", val1);
							EkRaidAttend_PlaySound();
							return;
						end
					end
				end
			end
		end

	elseif (event == "CHAT_MSG_MONSTER_YELL") then
		-- ----
		-- Test for special boss "kills".
		-- ----
		if (EkRaidAttend_BossKillAttend == 0) then
			return;
		end

		-- If not in raid, and test mode is disabled, then don't try to detect boss kills.
		if (GetNumRaidMembers() == 0 and EkRaidAttend_Test == 0) then
			return;
		end

		if (arg1) then
			-- Test for Majordomo Executus when he yells that he submits, rather than wait
			-- for his death in Ragnaros' lair.
			if (arg1 == "Impossible! Stay your attack, mortals... I submit! I submit!") then
				if (EkRaidAttend_BossList_IsEnabled("Majordomo Executus")) then
					EkRaidAttend_TakeAttendance(1, "", "Boss", "Majordomo Executus");
					EkRaidAttend_PlaySound();
				end
				return;
			end

			-- Test for The Prophet Skeram when he yells before he dies.
			if (arg1 == "You only delay the inevitable!") then
				if (EkRaidAttend_BossList_IsEnabled("The Prophet Skeram")) then
					EkRaidAttend_TakeAttendance(1, "", "Boss", "The Prophet Skeram");
					EkRaidAttend_PlaySound();
				end
				return;
			end

			-- Test for Razorgore the Corrupt's yell just before he dies after the raid
			-- failed to destroy all the eggs.
			if (arg1 == "If I fall into the abyss, I'll take all of you mortals with me!") then
				-- Initilalize razorgore yell flag/timer to zero.  If we see his death in
				-- the next "n" seconds, then we will not treat it as a normal boss kill
				-- and attendance won't be taken.
				EkRaidAttend_RazorgoreYell = 0;
			end

			-- Test for Razorgore the Corrupt's yell just before he dies after the raid
			-- has destroyed all the eggs.
			if (arg1 == "I'm free!  That device shall never torment me again!") then
				-- Initilalize razorgore yell flag/timer to zero.  If we see his death in
				-- the next "n" seconds, then we will not treat it as a normal boss kill
				-- and attendance won't be taken.
				EkRaidAttend_RazorgoreYell = 0;
			end
		end

	elseif (event == "GUILD_ROSTER_UPDATE") then
		-- ----
		-- Guild roster updates.
		-- ----
		if (EkRaidAttend_GuildRosterUpdates > 0) then
			-- This is an update event that resulted from calls to EkRaidAttend_SetGuildRosterShowOffline().
			EkRaidAttend_GuildRosterUpdates = EkRaidAttend_GuildRosterUpdates - 1;
			if (EkRaidAttend_GuildRosterUpdates <= 0) then
				EkRaidAttend_GuildRosterUpdates = 0;
			end
		else
			-- Unexpected or GuildRoster() guild roster update event. Set a flag so we can deal with
			-- it the next time we need to access the guild info array.
			EkRaidAttend_GuildRosterFlag = 1;
		end

	end
end


function EkRaidAttend_OnUpdate(elapsed)
	-- --------------
	-- Handles timed events, etc.
	-- --------------
	local inRaid;

	if (not EkRaidAttend_VarsLoaded) then
		return;
	end

	if (EkRaidAttend_InRaid()) then
		inRaid = 1;  -- in raid, or pretending to be while testing.
	else
		inRaid = nil;
	end

	if (not EkRaidAttend_old_CT_RADurability_Update) then
		if (CT_RADurability_Update) then
			EkRaidAttend_old_CT_RADurability_Update = CT_RADurability_Update;
			CT_RADurability_Update = EkRaidAttend_CT_RADurability_Update;

			if (CT_RA_DurabilityFrameDrag) then
				EkRaidAttend_old_CT_RA_DurabilityFrameDrag_OnMouseUp = CT_RA_DurabilityFrameDrag:GetScript("OnMouseUp");
				CT_RA_DurabilityFrameDrag:SetScript("OnMouseUp", EkRaidAttend_CT_RADurabilityFrameDrag_OnMouseUp);
			end
		end
	end

	if (not inRaid and EkRaidAttend_InRaidFlag) then
		-- We were in a raid, but aren't any longer.
		EkRaidAttend_DisabledRaidPrompts = {};
		EkRaidAttend_ShowPrompts = {};
	end

	if (inRaid and not EkRaidAttend_InRaidFlag) then
		-- We are in a raid now, but we weren't until now.
		EkRaidAttend_TestPrint("You have joined a raid.");
	end

	EkRaidAttend_InRaidFlag = inRaid;

	if (EkRaidAttend_UnsavedReminderStatus > 0) then
		-- ----
		-- Is it time to remind the user about unsaved attendance lists?
		-- ----
		EkRaidAttend_UnsavedReminderElapsed = EkRaidAttend_UnsavedReminderElapsed - elapsed;
		if (EkRaidAttend_UnsavedReminderElapsed < 0.1) then
			EkRaidAttend_UnsavedReminderReset();

			-- Show number of unsaved attendance lists.
			local unsaved = EkRaidAttend_ShowUnsaved();

			if (unsaved > 0 and EkRaidAttend_UnsavedReminderStatus == 2) then
				if (EkRaidAttend_PromptFrame_Mode ~= EkRaidAttend_PROMPT_RELOADUI_UNSAVED) then
					EkRaidAttend_ShowPrompts[EkRaidAttend_PROMPT_RELOADUI_UNSAVED] = 1;
				end
			end
		end
	end

	if (EkRaidAttend_RazorgoreYell) then
		-- Timer to reset Razorgore yell flag in case user releases after the yell, but before he dies.
		EkRaidAttend_RazorgoreYell = EkRaidAttend_RazorgoreYell + elapsed;
		if (EkRaidAttend_RazorgoreYell > 20) then
			EkRaidAttend_RazorgoreYell = nil;
		end
	end

	-- Test for delay between prompt windows.
	if (EkRaidAttend_PromptDelay) then
		EkRaidAttend_PromptDelay = EkRaidAttend_PromptDelay - elapsed;
		if (EkRaidAttend_PromptDelay < 0.1) then
			EkRaidAttend_PromptDelay = nil;
		end
	end

	-- If waiting for user to respond to the prompt window...
	if (EkRaidAttend_PromptTimer and EkRaidAttend_PromptFrame_:IsShown() and EkRaidAttend_PromptTimer < 9999) then
		EkRaidAttend_PromptTimer = EkRaidAttend_PromptTimer - elapsed;
		if (EkRaidAttend_PromptTimer < 0.1) then
			-- Window timer has run out, so cancel the prompt.
			EkRaidAttend_PromptTimer = nil;
			EkRaidAttend_PromptFrame_Button2_OnClick();
			EkRaidAttend_PromptDelay = EkRaidAttend_DefPromptDelay;
		else
			EkRaidAttend_PromptFrame_Button2:SetText("Close  (" .. ceil(EkRaidAttend_PromptTimer) .. ")");
		end
	end

	-- If not waiting for screenshot results, and we want to reload the UI...
	if (not EkRaidAttend_ScreenshotWait) then
		if (EkRaidAttend_ReloadFlag) then
			EkRaidAttend_ReloadFlag = nil;
			if (EkRaidAttend_ReloadUI == 1) then
				if (EkRaidAttend_PromptFrame_Mode ~= EkRaidAttend_PROMPT_RELOADUI_ATTEND) then
					EkRaidAttend_ShowPrompts[EkRaidAttend_PROMPT_RELOADUI_ATTEND] = 1;
				end
			end
		end
	end

	if (EkRaidAttend_TimedReminderStatus > 0) then
		-- ----
		-- Is it time to remind the user about not having started the timed attendance?
		-- ----
		if (not inRaid) then
			-- Hold at zero to force immediate reminder when join next raid.
			EkRaidAttend_TimedReminderElapsed = 0;
		else
			if (EkRaidAttend_Status == 0) then
				-- We are in a raid, and the timed attendance is off.
				EkRaidAttend_TimedReminderElapsed = EkRaidAttend_TimedReminderElapsed - elapsed;
				if (EkRaidAttend_TimedReminderElapsed < 0.1) then
					EkRaidAttend_TimedReminderReset();

					-- Show reminder.
					EkRaidAttend_Print("Reminder: You are in a raid and have not started the timed attendance.");

					-- Prompt to start timed attendance.
					if (EkRaidAttend_TimedReminderStatus == 2) then
						if (EkRaidAttend_PromptFrame_Mode ~= EkRaidAttend_PROMPT_TIMED_REMIND) then
							EkRaidAttend_ShowPrompts[EkRaidAttend_PROMPT_TIMED_REMIND] = 1;
						end
					end
				end
			end
		end
	end

	-- Test if we need to display a prompt window.
	for i=1, getn(EkRaidAttend_PromptKeys) do
		local k = EkRaidAttend_PromptKeys[i];
		if (EkRaidAttend_ShowPrompts[k]) then
			if (EkRaidAttend_DisabledRaidPrompts[k]) then
				EkRaidAttend_ShowPrompts[k] = nil;
			else
				if (not EkRaidAttend_PromptTimer and not EkRaidAttend_PromptDelay) then
					-- Prompt user.
					EkRaidAttend_ShowPrompts[k] = nil;
					EkRaidAttend_PromptFrame_Mode = k;
					EkRaidAttend_PromptFrame_:Show();
				end
			end
		end
	end

	-- Timed attendance handling --

	if (EkRaidAttend_Status == 0) then
		-- Time attendance is turned off.
		return;
	end

	if (not inRaid) then
		-- Don't worry about timed attendance if we are not in a raid.
		return;
	end

	-- ----
	-- Determine if it is time for a timed attendance to be taken.
	-- ----
	if (time() > EkRaidAttend_AutoTime) then
		local zone = GetRealZoneText();
		if ( not zone or zone == "" ) then
			return;
		end

		-- Take attendance.
		EkRaidAttend_TakeAttendance(1, "", "Timed", nil);
		EkRaidAttend_PlaySound();

		-- Calculate time of next timed attendance.
		EkRaidAttend_NextAlarm();

		-- Tell user when next attendance will occur.
		EkRaidAttend_NextAttendance();
	end
end


function EkRaidAttend_Command(msg)
	-- --------------
	-- Main command routine.
	-- --------------
	local command = string.lower(msg);

	if (command == nil or command == "" or command == "ui") then
		-- Toggle GUI visibility.
		EkRaidAttend_UIToggle();

	elseif (command == "?" or command == "help") then
		-- Display help.
		EkRaidAttend_Print2(" ");
		EkRaidAttend_ShowVersion(2);
		EkRaidAttend_Print2(" ");
		EkRaidAttend_Print2("/ekattend <comment> -- Take instant attendance.");
		EkRaidAttend_Print2("/ekattend zone [<comment>] -- Take attendance in your current zone.");
		EkRaidAttend_Print2("/ekattend start [<comment>] -- Start taking timed attendance.");
		EkRaidAttend_Print2("/ekattend stop [<comment>] -- Stop taking timed attendance.");
		EkRaidAttend_Print2("/ekattend toggle [<comment>] -- Toggle timed attendance taking on/off.");
		EkRaidAttend_Print2("/ekattend timer -- Show timer interval and next attendance time.");
		EkRaidAttend_Print2("/ekattend timer <minutes> -- Set timed attendance timer interval.");
		EkRaidAttend_Print2("/ekattend timer off/stop -- Stop timer without taking attendance.");
		EkRaidAttend_Print2("/ekattend timer on/start -- Start timer without taking attendance.");
		EkRaidAttend_Print2("/ekattend timer toggle -- Toggle timer without taking attendance.");
		EkRaidAttend_Print2(" ");
		EkRaidAttend_Print2("/ekattend [ui] -- Toggle the EkRaidAttend window.");
		EkRaidAttend_Print2("/ekattend show/hide -- Show/hide the EkRaidAttend window.");
		EkRaidAttend_Print2("/ekattend main -- Toggle the main window.");
		EkRaidAttend_Print2("/ekattend options -- Toggle the options window.");
		EkRaidAttend_Print2("/ekattend lists -- Toggle the lists window.");
		EkRaidAttend_Print2("/ekattend reset -- Reset window position.");
		EkRaidAttend_Print2(" ");
		EkRaidAttend_Print2("/ekattend rui -- Immediately reload your user interface.");
		EkRaidAttend_Print2("/ekattend info/status -- Show some status information.");
		EkRaidAttend_Print2("/ekattend time/date -- Show current date and time.");
		EkRaidAttend_Print2(" ");
		EkRaidAttend_Print2("/ekattend help/? -- Display this command summary.");
		EkRaidAttend_Print2(" ");
		EkRaidAttend_Print2("As a shorter alternative to /ekattend you can also use /ekat.");
		EkRaidAttend_Print2("To open the EkRaidAttend window type: /ekattend");

	elseif (command == "date" or command == "time") then
		-- Display current date/time.
		EkRaidAttend_ShowDateTime();

	elseif (command == "hide") then
		-- Hide the GUI
		EkRaidAttend_UIHide();

	elseif (command == "info" or command == "status") then
		EkRaidAttend_ShowInfo();

	elseif (command == "lists") then
		-- Toggle the lists pane
		EkRaidAttend_UIToggleLists();

	elseif (command == "main") then
		-- Toggle the main pane
		EkRaidAttend_UIToggleMain();

	elseif (command == "options") then
		EkRaidAttend_UIToggleOptions(nil);

	elseif (command == "reset") then
		-- Reset the window to the default locked position.
		if (EkRaidAttend_MovableWindow == 1) then
			EkRaidAttend_Frame_UnlockWindow(0);  -- Lock it (will reset position).
			EkRaidAttend_Frame_UnlockWindow(1);  -- Unlock it again (make it movable).
		else
			EkRaidAttend_Frame_UnlockWindow(0);  -- Lock it (will reset position).
		end
		EkRaidAttend_Print("The window location has been reset.");

	elseif (command == "rui") then
		-- Reload user interface.
		ReloadUI();

	elseif (command == "show") then
		-- Show the GUI
		EkRaidAttend_UIShow();

	elseif (strsub(command, 1, 5) == "start") then
		-- Start timed attendance taking.
		EkRaidAttend_TimedStart(strsub(msg, 7));

	elseif (strsub(command, 1, 4) == "stop") then
		-- Stop timed attendance taking.
		EkRaidAttend_TimedStop(strsub(msg, 6));

	elseif (strsub(command, 1, 5) == "timer") then
		-- Set timed attendance interval in minutes.

		if (command == "timer on" or command == "timer start") then
			-- Turn on timed attendance without doing a start attendance, etc.
			EkRaidAttend_TimerOn();
			return;
		end

		if (command == "timer off" or command == "timer stop") then
			-- Turn off timed attendance without doing a stop attendance, etc.
			EkRaidAttend_TimerOff()
			return;
		end

		if (command == "timer toggle") then
			-- Toggle timed attendance without doing a stop attendance, etc.
			EkRaidAttend_TimerToggle()
			return;
		end

		local pos1, pos2, val1 = string.find(command, "^timer (%d+)$");

		if (val1) then
			val1 = tonumber(val1);

			if (val1) then
				if (val1 < 1) then
					EkRaidAttend_Print("Timed attendance interval must be at least 1 minute.");
					return;
				elseif (val1 > 600) then
					EkRaidAttend_Print("Timed attendance interval must be less than 600 minutes.");
					return;
				end
			end

			EkRaidAttend_TimerSet(val1);
		else
			EkRaidAttend_ShowInterval();
			EkRaidAttend_NextAttendance();
		end

	elseif (strsub(command, 1, 6) == "toggle") then
		-- Toggle timed attendance taking.
		EkRaidAttend_TimedToggle(strsub(msg, 8));

	elseif (strsub(command, 1, 4) == "zone") then
		-- Take a instant attendance just for people in the current zone.

		if (command == "zone override") then
			-- Force zone attendance, and assume anyone with an unavailable
			-- zone name is in your zone.
			EkRaidAttend_ZoneOverride(strsub(msg, 15));
		else
			EkRaidAttend_Zone(strsub(msg, 6));
		end

	elseif (command == "_test") then
		-- Toggle test mode.
		if (EkRaidAttend_Test == 1) then
			EkRaidAttend_Print("Test mode disabled.");
			EkRaidAttend_Test = 0;
			return;
		end

		-- Test mode will:
		-- - Bypass the warning about not being in a raid.
		-- - Enable printing of certain events and their arguments.
		EkRaidAttend_Test = 1;
		EkRaidAttend_Print("Test mode enabled.");

		-- Display the various zone names provided by the UI
		EkRaidAttend_Zones();

		-- Display realm name
		local realm = GetCVar("realmName");
		if (realm) then
			EkRaidAttend_Print("Realm=" .. realm);
		end
	else
		-- Take an instant attendance.
		EkRaidAttend_Instant(msg);
	end
end


-- ------------------------------------------------------------------
-- Show/hide/toggle/refresh UI panels
-- ------------------------------------------------------------------

function EkRaidAttend_UIRefresh()
	-- ----
	-- Refresh the current UI frame.
	-- ----
	if (EkRaidAttend_Frame_:IsShown()) then
		EkRaidAttend_Frame_Refresh();
	end
end

function EkRaidAttend_UIShow()
	-- Show the GUI
	if (not EkRaidAttend_Frame_:IsShown()) then
		ShowUIPanel(EkRaidAttend_Frame_);
	end
end

function EkRaidAttend_UIHide()
	-- Hide the GUI
	if (EkRaidAttend_Frame_:IsShown()) then
		HideUIPanel(EkRaidAttend_Frame_);
	end
end

function EkRaidAttend_UIToggle()
	-- Toggle GUI visibility.
	if (EkRaidAttend_Frame_:IsShown()) then
		HideUIPanel(EkRaidAttend_Frame_);
	else
		ShowUIPanel(EkRaidAttend_Frame_);
	end
end

function EkRaidAttend_UIToggleMain()
	-- Toggle the main pane
	if (EkRaidAttend_Frame_:IsShown()) then
		if (EkRaidAttend_Frame_GetTab() == EkRaidAttend_Frame_TabMain) then
			HideUIPanel(EkRaidAttend_Frame_);
			return;
		end
	end

	ShowUIPanel(EkRaidAttend_Frame_);
	EkRaidAttend_Frame_GotoTab(EkRaidAttend_Frame_TabMain);
end

function EkRaidAttend_UIToggleOptions(page)
	-- Toggle the options pane
	if (EkRaidAttend_Frame_:IsShown()) then
		if (EkRaidAttend_Frame_GetTab() == EkRaidAttend_Frame_TabOptions) then
			if (EkRaidAttend_OptionsFrame_Page == page or page == nil) then
				HideUIPanel(EkRaidAttend_Frame_);
				return;
			end
		end
	end

	ShowUIPanel(EkRaidAttend_Frame_);
	if (page ~= nil) then
		EkRaidAttend_OptionsFrame_Page = page;
	end
	EkRaidAttend_Frame_GotoTab(EkRaidAttend_Frame_TabOptions);
end

function EkRaidAttend_UIToggleLists()
	-- Toggle the lists pane
	if (EkRaidAttend_Frame_:IsShown()) then
		if (EkRaidAttend_Frame_GetTab() == EkRaidAttend_Frame_TabLists) then
			HideUIPanel(EkRaidAttend_Frame_);
			return;
		end
	end

	ShowUIPanel(EkRaidAttend_Frame_);
	EkRaidAttend_ListsFrame_Mode = 0;
	EkRaidAttend_Frame_GotoTab(EkRaidAttend_Frame_TabLists);
end


-- ------------------------------------------------------------------
-- Unsaved attendance reminder
-- ------------------------------------------------------------------

function EkRaidAttend_UnsavedReminderOff(showStatus)
	-- -----
	-- Turn off unsaved reminder.
	-- -----
	EkRaidAttend_UnsavedReminderStatus = 0;
	EkRaidAttend_UnsavedReminderUpdate(showStatus);
end


function EkRaidAttend_UnsavedReminderOn(showStatus)
	-- -----
	-- Turn on unsaved attendance reminder.
	-- -----
	EkRaidAttend_UnsavedReminderStatus = 1;
	EkRaidAttend_UnsavedReminderUpdate(showStatus);
end


function EkRaidAttend_UnsavedReminderPrompt(showStatus)
	-- -----
	-- Turn on unsaved reminder and prompt to reload ui.
	-- -----
	EkRaidAttend_UnsavedReminderStatus = 2;
	-- Also clear the "disabled while in raid" flag.
	EkRaidAttend_DisabledRaidPrompts[EkRaidAttend_PROMPT_RELOADUI_UNSAVED] = nil;
	EkRaidAttend_UnsavedReminderUpdate(showStatus);
end


function EkRaidAttend_UnsavedReminderSet(minutes, showStatus)
	-- -----
	-- Set unsaved reminder interval
	-- -----
	EkRaidAttend_UnsavedReminderInterval = minutes;
	EkRaidAttend_UnsavedReminderUpdate(showStatus);
end


function EkRaidAttend_UnsavedReminderUpdate(showStatus)
	-- -----
	-- Update unsaved attendance reminder.
	-- -----
	EkRaidAttend_UnsavedReminderReset();
	if (showStatus) then
		EkRaidAttend_ShowUnsavedReminderStatus();
	end
	EkRaidAttend_UIRefresh();
end


function EkRaidAttend_UnsavedReminderReset()
	-- -----
	-- Reset unsaved reminder interval.
	-- -----
	EkRaidAttend_UnsavedReminderElapsed = EkRaidAttend_UnsavedReminderInterval * 60;
end


-- ------------------------------------------------------------------
-- Timed attendance reminder
-- ------------------------------------------------------------------

function EkRaidAttend_TimedReminderOff(showStatus)
	-- -----
	-- Turn off timed reminder.
	-- -----
	EkRaidAttend_TimedReminderStatus = 0;
	EkRaidAttend_TimedReminderUpdate(showStatus);
end


function EkRaidAttend_TimedReminderOn(showStatus)
	-- -----
	-- Turn on timed attendance reminder.
	-- -----
	EkRaidAttend_TimedReminderStatus = 1;
	EkRaidAttend_TimedReminderUpdate(showStatus);
end


function EkRaidAttend_TimedReminderPrompt(showStatus)
	-- -----
	-- Turn on timed attendance reminder and prompt.
	-- -----
	EkRaidAttend_TimedReminderStatus = 2;
	-- Also clear the "disabled while in raid" flag.
	EkRaidAttend_DisabledRaidPrompts[EkRaidAttend_PROMPT_TIMED_REMIND] = nil;
	EkRaidAttend_TimedReminderUpdate(showStatus);
end


function EkRaidAttend_TimedReminderSet(minutes, showStatus)
	-- -----
	-- Set timed attendance reminder interval.
	-- -----
	EkRaidAttend_TimedReminderInterval = minutes;
	EkRaidAttend_TimedReminderUpdate(showStatus);
end


function EkRaidAttend_TimedReminderUpdate(showStatus)
	-- -----
	-- Update timed attendance reminder.
	-- -----
	EkRaidAttend_TimedReminderReset();
	if (showStatus) then
		EkRaidAttend_ShowTimedReminderStatus();
	end
	EkRaidAttend_UIRefresh();
end


function EkRaidAttend_TimedReminderReset()
	-- -----
	-- Reset timed attendance reminder interval.
	-- -----
	EkRaidAttend_TimedReminderElapsed = EkRaidAttend_TimedReminderInterval * 60;
end


-- ------------------------------------------------------------------
-- Timed attendance timer
-- ------------------------------------------------------------------

function EkRaidAttend_TimerToggle()
	-- Toggle timed attendance without doing a start attendance, etc.
	if (EkRaidAttend_Status == 1) then
		EkRaidAttend_TimerOff();
	else
		EkRaidAttend_TimerOn();
	end
end


function EkRaidAttend_TimerOn()
	-- Turn on timed attendance without doing a start attendance, etc.

	if (not EkRaidAttend_InRaid()) then
		EkRaidAttend_Not_In_A_Raid(0);
		return;
	end

	-- Calculate when next timed attendance is to occur.
	EkRaidAttend_NextAlarm();

	EkRaidAttend_Status = 1;
	EkRaidAttend_ShowStatus();

	EkRaidAttend_TimedReminderReset();

	-- Tell user when next attendance will occur.
	EkRaidAttend_NextAttendance();

	EkRaidAttend_UIRefresh();
	return;
end


function EkRaidAttend_TimerOff()
	-- Turn off timed attendance without doing a stop attendance, etc.
	EkRaidAttend_Status = 0;
	EkRaidAttend_ShowStatus();

	EkRaidAttend_TimedReminderReset();

	EkRaidAttend_UIRefresh();
	return;
end


function EkRaidAttend_TimerSet(minutes)
	-- Set timed attendance interval.
	EkRaidAttend_Len = minutes;
	EkRaidAttend_NextAlarm();  -- Calc new next start time.

	EkRaidAttend_ShowInterval();

	-- Tell user when next attendance will occur.
	EkRaidAttend_NextAttendance();

	EkRaidAttend_UIRefresh();
end


function EkRaidAttend_NextAlarm()
	-- ------------------
	-- Calculate when next attendance will be taken.
	-- ------------------

	-- Save the time of the next attendance.
	EkRaidAttend_AutoTime = time() + (EkRaidAttend_Len * 60);
end


function EkRaidAttend_NextAttendance()
	-- ------------------
	-- Tell user when next attendance will occur.
	-- ------------------
	if (EkRaidAttend_Status == 0 or not EkRaidAttend_InRaid()) then
		return;
	end

	EkRaidAttend_Print("Next timed attendance is at " .. date("%I:%M %p", EkRaidAttend_AutoTime) .. " local time.");
end


function EkRaidAttend_LastAttendance()
	-- ------------------
	-- Tell user when last attendance was done.
	-- ------------------
	if (not EkRaidAttend_LastTime) then
		return;  -- Haven't done one yet.
	end
	EkRaidAttend_Print("Last attendance was taken at " .. date("%I:%M %p", EkRaidAttend_LastTime) .. " local time.");
	EkRaidAttend_Print("Last attendance name was " .. EkRaidAttend_LastTitle);
end


-- ------------------------------------------------------------------
-- Display status messages.
-- ------------------------------------------------------------------

function EkRaidAttend_ShowReloadUI()
	-- ------------------
	-- Show reload UI setting.
	-- ------------------
	local text = {"OFF", "ON"};
	EkRaidAttend_Print("Prompt to reload UI after attendance is " .. text[EkRaidAttend_ReloadUI + 1] .. ".");
end


function EkRaidAttend_ShowUnsaved()
	-- ------------------
	-- Show number of unsaved attendance lists.
	--
	-- Returns: Number of unsaved attendance lists.
	-- ------------------
	local count = EkRaidAttend_ListsFrame_UnsavedCount();

	if (count > 0) then
		EkRaidAttend_Print("Reminder: There are " .. count .. " unsaved attendances in memory. They won't be saved until you logout or reload your UI.");
	end

	return count;
end


function EkRaidAttend_ShowUnsavedReminderStatus()
	-- ------------------
	-- Show unsaved reminder setting.
	-- ------------------
	local text = {"OFF", "ON (without prompt)", "ON (with prompt)"};
	EkRaidAttend_Print("Unsaved attendance reminder is " .. text[EkRaidAttend_UnsavedReminderStatus + 1] .. ".");
	EkRaidAttend_Print("Unsaved attendance reminder interval is " .. EkRaidAttend_UnsavedReminderInterval .. " minutes.");
end


function EkRaidAttend_ShowTimedReminderStatus()
	-- ------------------
	-- Show timed reminder setting.
	-- ------------------
	local text = {"OFF", "ON (without prompt)", "ON (with prompt)"};
	EkRaidAttend_Print("Timed attendance reminder is " .. text[EkRaidAttend_TimedReminderStatus + 1] .. ".");
	EkRaidAttend_Print("Timed attendance reminder interval is " .. EkRaidAttend_TimedReminderInterval .. " minutes.");
end


function EkRaidAttend_ShowStatus()
	-- ------------------
	-- Show current timed attendance status (on/off).
	-- ------------------
	local text = {"OFF", "ON"};
	EkRaidAttend_Print("Timed attendance taking is " .. text[EkRaidAttend_Status + 1] .. ".");
end


function EkRaidAttend_ShowInterval()
	-- ------------------
	-- Show current timed attendance interval.
	-- ------------------
	EkRaidAttend_Print("Timed attendance interval is every " .. EkRaidAttend_Len .. " minutes.");
end


function EkRaidAttend_ShowInfo()
	-- ------------------
	-- Show current information/status.
	-- ------------------
	EkRaidAttend_ShowVersion();
	EkRaidAttend_ShowUnsavedReminderStatus();
	EkRaidAttend_ShowTimedReminderStatus();
	EkRaidAttend_ShowInterval();
	EkRaidAttend_LastAttendance();
	EkRaidAttend_NextAttendance();
	EkRaidAttend_ShowStatus();
end


function EkRaidAttend_Zones()
	-- ------------------
	-- Display the variouis zone names that the UI can provide.
	-- ------------------
	EkRaidAttend_Print("GetMinimapZoneText = " .. GetMinimapZoneText());
	EkRaidAttend_Print("GetRealZoneText = " .. GetRealZoneText());
	EkRaidAttend_Print("GetZoneText = " .. GetZoneText());
	EkRaidAttend_Print("GetSubZoneText = " .. GetSubZoneText());
end


-- ------------------------------------------------------------------
-- Take attendance
-- ------------------------------------------------------------------

function EkRaidAttend_Instant(msg)
	-- ------------------
	-- Take an instant (manual) attendance.
	-- ------------------
	if (not EkRaidAttend_InRaid()) then
		EkRaidAttend_Not_In_A_Raid(1);
		return;
	end

	EkRaidAttend_TakeAttendance(1, msg, "Instant", nil);
end


function EkRaidAttend_Zone(msg)
	-- ------------------
	-- Take an instant attendance just for people in the current zone.
	-- ------------------
	if (not EkRaidAttend_InRaid()) then
		EkRaidAttend_Not_In_A_Raid(1);
		return;
	end

	EkRaidAttend_ForceZoneAttend = 0;
	EkRaidAttend_TakeAttendance(2, msg, "Zone", nil);
end


function EkRaidAttend_ZoneOverride(msg)
	-- ------------------
	-- Take a instant attendance just for people in the current zone.
	-- ------------------
	if (not EkRaidAttend_InRaid()) then
		EkRaidAttend_Not_In_A_Raid(1);
		return;
	end

	-- Force zone attendance, and assume anyone with an unavailable
	-- zone name is in your zone.
	EkRaidAttend_ForceZoneAttend = 1;
	EkRaidAttend_TakeAttendance(2, msg, "Zone", nil);
	EkRaidAttend_ForceZoneAttend = 0;
end


function EkRaidAttend_TimedToggle(user_msg)
	-- ------------------
	-- Toggle timed attendance taking.
	-- ------------------
	if (EkRaidAttend_Status == 1) then
		EkRaidAttend_TimedStop(user_msg);
	else
		EkRaidAttend_TimedStart(user_msg);
	end
end

function EkRaidAttend_TimedStart(user_msg)
	-- ------------------
	-- Start timed attendance taking.
	-- ------------------
	if (not EkRaidAttend_InRaid()) then
		EkRaidAttend_Not_In_A_Raid(0);
		return;
	end

	-- Calculate when next timed attendance is to occur.
	EkRaidAttend_NextAlarm();

	-- Enable the attendance timer.
	EkRaidAttend_Status = 1;

	EkRaidAttend_TimedReminderReset();

	-- Take an initial attendance.
	EkRaidAttend_TakeAttendance(1, user_msg, "Timed start", nil);

	-- Tell user when next attendance will occur.
	EkRaidAttend_NextAttendance();

	EkRaidAttend_ShowStatus();
end


function EkRaidAttend_TimedStop(user_msg)
	-- ------------------
	-- Stop timed attendance taking.
	-- ------------------

	-- Disable the attendance timer.
	EkRaidAttend_Status = 0;

	EkRaidAttend_TimedReminderReset();

	-- Take a final attendance.
	EkRaidAttend_TakeAttendance(1, user_msg, "Timed stop", nil);

	EkRaidAttend_ShowStatus();
end


function EkRaidAttend_PlaySound()
	-- ------------------
	-- Play timed attendance sound.
	-- ------------------
	if ( EkRaidAttend_PlayAttendSound == 1 ) then
		PlaySoundFile("Sound\\Doodad\\BellTollNightElf.wav");
	end
end


function EkRaidAttend_Not_In_A_Raid(which)
	-- ----------
	-- Print message about not being in a raid, etc.
	--
	-- which -- 0 == You are not in a raid!
	--          1 == Unable to take attendance. You are not in a raid!
	-- ----------
	if (which == 1) then
		EkRaidAttend_Print("Unable to take attendance. You are not in a raid!");
	else
		EkRaidAttend_Print("You are not in a raid!");
	end
end


function EkRaidAttend_TakeAttendance(mode, user_msg, sys_msg, boss)
	-- ------------------
	-- Take attendance.
	--
	-- Parameter: mode -- 1 == All raid members included in attendance.
	--                    2 == Raid member must be in same zone as
	--                         attendance taker to be included.
	-- Parameter: user_msg  -- User supplied message to appear at end of title.
	-- Parameter: sys_msg   -- System message to appear after date/time.
	--                         Examples:
	--                            Boss
	--                            Instant
	--                            Zone
	--                            Timed
	--                            Timed start
	--                            Timed stop
	--                            
	-- Parameter: boss      -- Boss name (if a boss kill).
	-- ------------------
	local index, newSave, wait_index, newWait, taken;

	taken, index, newSave, wait_index, newWait = EkRaidAttend_AttendFunc(mode, user_msg, sys_msg, boss);

	if (not taken) then
		EkRaidAttend_UIRefresh();
		return;
	end

	if ( EkRaidAttend_TakeScreenshot > 0 ) then
		-- We want to take a screenhot.
		if ( EkRaidAttend_TakeScreenshot == 2 ) then
			-- Display the raid tab in the FriendsFrame.

			-- Remember current state of the friends window.
			EkRaidAttend_FriendsTab = PanelTemplates_GetSelectedTab(FriendsFrame);
			EkRaidAttend_FriendsVis = FriendsFrame:IsVisible();

			local newTab = 4;  -- 4 == Raid tab on the socials (friends) window.

			PanelTemplates_SetTab(FriendsFrame, newTab);
			if ( FriendsFrame:IsVisible() ) then
				FriendsFrame_OnShow();
			else
				ShowUIPanel(FriendsFrame);
			end
		else
			EkRaidAttend_FriendsTab = nil;
			EkRaidAttend_FriendsVis = nil;
		end

		Screenshot();

		EkRaidAttend_ScreenshotWait = 1;  -- Wait for screenshot event (fail/succeed).
	end

	if (newSave) then
		-- Add new save entry to the ListsFrame list.
		local list = EkRaidAttend_ListsFrame_List;
		local rec = EkRaidAttend_ListsFrame_ListInitRec(index);
		table.insert(list, rec);
		EkRaidAttend_ListsFrame_Sort(EkRaidAttend_ListsFrame_Order);
	end

	if (newWait) then
		-- Add new wait list entry to the ListsFrame list.
		local list = EkRaidAttend_ListsFrame_List;
		local rec = EkRaidAttend_ListsFrame_ListInitRec(wait_index);
		table.insert(list, rec);
		EkRaidAttend_ListsFrame_Sort(EkRaidAttend_ListsFrame_Order);
	end

	-- Reset the unsaved attendance reminder timer.
	EkRaidAttend_UnsavedReminderReset();

	-- Set unsaved attendance reminder timer to 0 to force it to appear (if enabled).
	EkRaidAttend_UnsavedReminderElapsed = 0;

	-- Update UI if visible.
	if (EkRaidAttend_Frame_:IsShown()) then

		-- If saved attendance players frame is currently shown, and the saved
		-- attendance name just taken matches the one being viewed, then
		-- we need to reinitalize the players frame list before we refresh it.
		if (EkRaidAttend_PlayersFrame_:IsShown()) then

			if ((index and EkRaidAttend_PlayersFrame_RaidIndex == index) or (wait_index and EkRaidAttend_PlayersFrame_RaidIndex == wait_index)) then
				EkRaidAttend_PlayersFrame_ListInit();
			end
		end

		EkRaidAttend_Frame_Refresh();
	end

	-- Set flag to indicate that the user may want to reload the ui.
	EkRaidAttend_ReloadFlag = 1;

	if (EkRaidAttend_ShowLotsPrompt == 1) then
		if (getn(EkRaidAttend_ListsFrame_List) > 100) then
			if (EkRaidAttend_PromptFrame_Mode ~= EkRaidAttend_PROMPT_LOTS_OF_ATTENDANCES) then
				EkRaidAttend_ShowPrompts[EkRaidAttend_PROMPT_LOTS_OF_ATTENDANCES] = 1;
			end
		end
	end
end

function EkRaidAttend_AttendFunc(mode, user_msg, sys_msg, boss)
	-- ------------------
	-- Attendance function.
	--
	-- Parameter: mode -- 1 == All raid members included in attendance.
	--                    2 == Raid member must be in same zone as
	--                         attendance taker to be included.
	-- Parameter: user_msg  -- User supplied message to appear at end of title.
	-- Parameter: sys_msg   -- System message to appear after date/time.
	-- Parameter: boss      -- Boss name (if a boss kill).
	--
	-- Returns: 1) taken -- true if attendance was taken, false if it was not.
	--          2) title -- name that the raid was recorded under.
	--          3) newSave -- true if attendance name was not already in the list, false if it was.
	--          4) wait_title -- name that the wait list was recorded under.
	--          5) newWait -- true if wait list name was not already in the list, false if it was, nil if not recorded.
	-- ------------------
	local name, rank, subgroup, level, class, fileName, zone, online, isDead;
	local newSave, newWait;
	local main;

	local minimapzonetext = GetMinimapZoneText();
	local zonetext = GetZoneText();
	local subzonetext = GetSubZoneText();

	local numRaidMembers;
	local consider_member, save_member;
	local zone_not_found;

	local this_zone, server_hour, server_minute, local_date, local_time;
	local title

	local attend_count;
	local wait_title, wait_count;
	local temp;
	local online_count, offline_count;

	if (EkWaitList_WaitFrame_RemoveMembers) then
		-- If people in the wait list are also in the party/raid, then remove them from the wait list.
		EkWaitList_WaitFrame_RemoveMembers();
	end

	-- Get zone, date, time information.
	this_zone = GetRealZoneText();
	server_hour, server_minute = GetGameTime();
	local_time = time();
	local_date = date("*t", local_time);

	zone_not_found = 0;

	numRaidMembers = GetNumRaidMembers();
	if (numRaidMembers == 0 and EkRaidAttend_Test == 0) then
		EkRaidAttend_Print("Unable to take attendance. You are not in a raid!");
		return false, nil, nil;
	end

	if (EkRaidAttend_ForceZoneAttend == 0) then
		-- Test to see if any of the zone names for people are nil.
		-- This can happen if you (or someone else) has reloaded the UI while
		-- in the game (due to a Blizzard bug apparently introduced in Feb 2005
		-- ... see http://www.wowwiki.com/API_GetRaidRosterInfo).
		-- NOTE: This bug may be fixeded in either the 1.6 or 1.7 WoW patch.

		for i=1, numRaidMembers do
			name, rank, subgroup, level, class, fileName, zone, online, isDead = EkRaidAttend_GetRaidRosterInfo(i);

			if (name and not zone and mode == 2) then
				if ( name ~= UnitName("player") ) then
					-- We're doing a zone attendance and we don't know what their zone is.
					EkRaidAttend_Print("*** Unable to determine zone for " .. name .. " ***");
					zone_not_found = 1;
				end
			end
		end

		if (zone_not_found == 1) then
			-- Force assumption that player with unknown zone is in current zone.
			EkRaidAttend_ForceZoneAttend = 1;
		end
	end

	-- Generate attendance title (eg. "Molten Core 2006/06/10 11:00:00 13:00 Timed start.")
	-- Generate attendance title (eg. "Lord Kazzak 2006/06/10 23:00:00 01:00 Boss.")

	-- Note: Over time there have been 4 date/time formats used in the attendance titles.
	-- The first was "MM/DD HH:MMAM HH:MMAM" which was used prior to EkRaidAttend version 2.0.
	-- The second was "YYYY/MM/DD HH:MMAM HH:MMAM" which was used during testing of version 2.0.
	-- The third was "YYYY/MM/DD HH:MM:SSAM HH:MMAM" which is used by the release version of 2.0.
	-- The fourth was "YYYY/MM/DD HH:MM:SS HH:MM" which is used by the release version of 2.4.

	if ( boss ) then
		-- Start with boss name.
		title = boss;
	else
		-- Start with zone name.
		title = this_zone;
	end

	-- Add local date and time.
	title = title .. " " .. string.format("%04d/%02d/%02d %02d:%02d:%02d", local_date["year"], local_date["month"],
			local_date["day"], local_date["hour"], local_date["min"], local_date["sec"]);

	-- Add server time.
	title = title .. " " .. string.format("%02d:%02d", server_hour, server_minute) .. "";

	wait_title = title;

	if ( sys_msg and sys_msg ~= "" ) then
		title = title .. " " .. sys_msg;
		wait_title = wait_title .. " " .. sys_msg;

		-- if ( mode == 2 and EkRaidAttend_ForceZoneAttend == 1 ) then
		-- 	title = title .. " (all assumed to be in the zone)"
		-- end

		if (EkWaitList_WaitList and EkRaidAttend_WaitListAttend == 1 and EkRaidAttend_WaitListSeparate == 0) then
			-- Use a "+" to indicate the wait list is being combined with the normal attendance data.
			title = title .. " + wait list";  -- lower case "w" for "wait list" to distinguish it from the "Wait list." used for separate wait lists.
		end

		title = title .. ".";
	end

	-- Note: Some other code relies on the fact that wait list attendance names end with "Wait list." (the "intersection" button on the lists window)
	wait_title = wait_title .. " Wait list."

	-- Add comment supplied by user from the command line.
	if ( user_msg and user_msg ~= "" ) then
		title = title .. " " .. user_msg;
		wait_title = wait_title .. " " .. user_msg;
	end

	-- Add comment supplied by user on the main window.
	if ( not boss and EkRaidAttend_Comment ~= "" ) then
		-- Add the user supplied comment (editable via the UI).
		if ( title ~= "" ) then
			title = title .. " ";
		end
		title = title .. EkRaidAttend_Comment;

		if ( wait_title ~= "" ) then
			wait_title = wait_title .. " ";
		end
		wait_title = wait_title .. EkRaidAttend_Comment;
	end

	-- Translate certain characters.
	title = string.gsub(title, "%[", "(");
	title = string.gsub(title, "%]", ")");
	title = string.gsub(title, "\"", "'");

	wait_title = string.gsub(wait_title, "%[", "(");
	wait_title = string.gsub(wait_title, "%]", ")");
	wait_title = string.gsub(wait_title, "\"", "'");

	if (EkRaidAttend_Data[title] == nil) then
		newSave = true;  -- not in list yet.
	else
		newSave = false;  -- overwriting existing save
	end

	EkRaidAttend_Data[title] = {};

	if (EkRaidAttend_ShowAttendNames == 1) then
		EkRaidAttend_Print(" ");
		EkRaidAttend_Print("Online players:");

	elseif (EkRaidAttend_ShowAttendNames == 2) then
		EkRaidAttend_Print(" ");
		EkRaidAttend_Print("Offline players:");

	elseif (EkRaidAttend_ShowAttendNames == 3) then
		EkRaidAttend_Print(" ");
		EkRaidAttend_Print("Online and offline players:");
	end

	if (EkRaidAttend_MainNameUse == 1 and EkRaidAttend_RecordMainName == 1 and IsInGuild()) then
		EkRaidAttend_GuildRoster();
		EkRaidAttend_GetGuildInfo();
	end

	attend_count = 0;
	online_count = 0;
	offline_count = 0;
	for i=1, numRaidMembers do
		name, rank, subgroup, level, class, fileName, zone, online, isDead = EkRaidAttend_GetRaidRosterInfo(i);

		if (not name) then
			name = "Unknown" .. i;
		end

		if ( name == UnitName("player") ) then
			zone = GetRealZoneText();
		end

		main = nil;
		if (EkRaidAttend_MainNameUse == 1 and EkRaidAttend_RecordMainName == 1 and IsInGuild()) then
			-- Get name of main character for this player.
			local pos = EkRaidAttend_IsNameInGuild(name);
			if (pos > 0) then
				-- Name is in the guild.
				local guildRec = EkRaidAttend_GuildInfo[pos];
				main = guildRec["main"];
			end
		end

		-- If we still don't know that zone it is, and we're doing a zone attendance...
		if (not zone) then
			-- If we're doing a zone attendance...
			if (mode == 2) then
				if (EkRaidAttend_ForceZoneAttend == 1) then
					-- User is forcing a zone attendance, so give the player (with the
					-- unavailable zone) the benefit of the doubt, and pretend they are
					-- in the same zone as us.
					zone = GetRealZoneText();
				else
					-- We don't know their zone, and the user is not forcing it to
					-- assume the same zone as us, so just set the zone to "???".
					zone = "???";
				end
			else
				-- Since we're not doing a zone attendance, knowing the user's
				-- actual zone is not that important.
				zone = "???";
			end
		else
			if (zone == "") then
				zone = "???";
			end
		end

		-- Should we consider this member for attendance?
		consider_member = 0;

		if (mode == 2) then
			-- Only consider member if they are in this zone.
			if (zone == this_zone or zone == minimapzonetext or zone == zonetext or zone == subzonetext) then
				consider_member = 1;
			end
		else
			-- Consider all members regardless of what zone they are in.
			consider_member = 1;
		end

		if (not online) then
			-- Convert nil value for offline people into a zero so it will
			-- save in the SavedVariables.lua file.
			online = EkRaidAttend_PlayerStatus_OFFLINE;
		else
			online = EkRaidAttend_PlayerStatus_ONLINE;
		end

		save_member = 0;

		if (consider_member == 1) then
			-- Are we going to save this raid member?
			if (EkRaidAttend_SaveAttendNames == 1) then
				-- Save online people only.
				if (online == 1) then
					save_member = 1;
				end
			else
				-- Save online and offline people.
				save_member = 1;
			end

			if (save_member == 1) then
				if (main and EkRaidAttend_MainNameUse == 1 and EkRaidAttend_RecordMainName == 1 and main ~= name) then
					EkRaidAttend_Data[title][main] = online .. EkRaidAttend_StatusSep .. name; -- Remember name that was actually in the raid.
				else
					EkRaidAttend_Data[title][name] = online;
				end
				attend_count = attend_count + 1;
				if (online == 1) then
					online_count = online_count + 1;
				else
					offline_count = offline_count + 1;
				end
			end
		end

		-- Are we going to display this raid member on screen?
		if (online == 1 and (EkRaidAttend_ShowAttendNames == 1 or EkRaidAttend_ShowAttendNames == 3)) then
			show_member = 1;
		elseif (online == 0 and (EkRaidAttend_ShowAttendNames == 2 or EkRaidAttend_ShowAttendNames == 3)) then
			show_member = 1;
		else
			show_member = 0;
		end

		if (show_member == 1) then
			if (main and EkRaidAttend_MainNameUse == 1 and EkRaidAttend_RecordMainName == 1 and main ~= name) then
				if (save_member == 0) then
					text = "(not recorded)";
				else
					text = "(recorded as: " .. main .. ")";
				end
			else
				if (save_member == 0) then
					text = "(not recorded)";
				else
					text = "(recorded)";
				end
			end
			EkRaidAttend_Print("  " .. name .. " " .. text .. ", " .. zone);
		end
	end

	newWait = nil;
	wait_count = 0;
	if (EkWaitList_WaitList) then
		wait_count = getn(EkWaitList_WaitList);

		if (EkRaidAttend_WaitListAttend == 1) then
			-- --------
			-- Record the players on the waitlist
			-- --------
			if (EkRaidAttend_Data[wait_title] == nil) then
				newWait = true;  -- not in list yet.
			else
				newWait = false;  -- overwriting existing save
			end

			show_member = 0;

			-- If showing online (or online and offline) players then also show wait list players.
			-- (waitlist players are assumed to be online).
			if (EkRaidAttend_ShowAttendNames == 1 or EkRaidAttend_ShowAttendNames == 3) then
				show_member = 1;
			end

			if (show_member == 1) then
				EkRaidAttend_Print(" ");
				EkRaidAttend_Print("Waitlist players:");
			end

			-- Update waitlist and possibly display names
			EkRaidAttend_Data[wait_title] = {};

			for i=1, wait_count, 1 do
				name = EkWaitList_WaitList[i]["name"];

				main = nil;
				if (EkRaidAttend_MainNameUse == 1 and EkRaidAttend_RecordMainName == 1 and IsInGuild()) then
					-- Get name of main character for this player.
					local pos = EkRaidAttend_IsNameInGuild(name);
					if (pos > 0) then
						-- Name is in the guild.
						local guildRec = EkRaidAttend_GuildInfo[pos];
						main = guildRec["main"];
					end
				end

				if (main and EkRaidAttend_MainNameUse == 1 and EkRaidAttend_RecordMainName == 1 and main ~= name) then
					EkRaidAttend_Data[wait_title][main] = EkRaidAttend_PlayerStatus_WAITLIST .. EkRaidAttend_StatusSep .. name; -- Remember name that was actually in the raid.

					if (show_member == 1) then
						EkRaidAttend_Print("  " .. name .. " " .. "(recorded as: " .. main .. ")");
					end
				else
					EkRaidAttend_Data[wait_title][name] = EkRaidAttend_PlayerStatus_WAITLIST;

					if (show_member == 1) then
						EkRaidAttend_Print("  " .. name .. " " .. "(recorded)");
					end
				end
			end
		end
	end

	-- Display summary of the attendance just taken.
	EkRaidAttend_Print(" ");

	if (attend_count == 1) then
		temp = "name";
	else
		temp = "names";
	end
	if (EkRaidAttend_SaveAttendNames == 1) then
		EkRaidAttend_Print("Attendance (" .. online_count .. " online) recorded as:");
	else
		EkRaidAttend_Print("Attendance (" .. online_count .. " online, " .. offline_count .. " offline) recorded as:");
	end
	EkRaidAttend_Print("   " .. title);

	if (EkWaitList_WaitList) then
		if (wait_count == 1) then
			temp = "name";
		else
			temp = "names";
		end
		if (EkRaidAttend_WaitListAttend == 1) then
			EkRaidAttend_Print("Wait list attendance (" .. wait_count .. " " .. temp .. ") recorded as:");
			if (EkRaidAttend_WaitListSeparate == 1) then
				EkRaidAttend_Print("   " .. wait_title);
			else
				EkRaidAttend_Print("   " .. title);
			end
		else
			EkRaidAttend_Print("Wait list attendance (" .. wait_count .. " " .. temp .. ") was not recorded.");
		end
	end

	if (zone_not_found == 1 and EkRaidAttend_ForceZoneAttend == 1) then
		-- We assumed that player with unknown zone is in current zone.
		EkRaidAttend_Print(" ");
		EkRaidAttend_Print("*** Due to 'unknown zone' issues, zone attendance was taken with the assumption that everyone is in the current zone. ***");
	end

	if (EkWaitList_WaitList) then
		if (EkRaidAttend_WaitListAttend == 1 and EkRaidAttend_WaitListSeparate == 0) then
			-- Append the wait list to the main attendance list, rather than create a separate wait list attendance.
			local wl = EkRaidAttend_Data[wait_title];  -- wait list attendance
			local al = EkRaidAttend_Data[title];  -- main attendance list
			for k, v in wl do
				al[k] = v;
			end
			EkRaidAttend_Data[wait_title] = nil;  -- Get rid of the wait list attendance.
			newWait = nil;
		end
	end

	-- Remember the last time we did a snapshot.
	EkRaidAttend_LastTime = local_time;
	EkRaidAttend_LastTitle = title;

	EkRaidAttend_ForceZoneAttend = 0;

	-- Now that we've used the user supplied comment, clear it if requested to.
	if ( not boss and EkRaidAttend_ClearComment == 1 ) then
		EkRaidAttend_Comment = "";
	end

	return true, title, newSave, wait_title, newWait;
end

function EkRaidAttend_TakeSpecial(user_msg, sys_msg, durSub, minimum, checkMsg, statusNum)
	-- ------------------
	-- Take Special attendance (resistance check, item check, etc).
	--
	-- Parameter: user_msg  -- User supplied message to appear at end of title.
	-- Parameter: sys_msg   -- System message to appear after date/time.
	--                         Examples:
	--                            Resist Fire 99
	--                            Resist Nature 99
	--                            Item Greater Fire Protection Potion 99
	--                            
	-- Parameter: durSub    -- CT_RADurability_Shown[] subscript of the value to use.
	-- Parameter: minimum   -- Minimum value required for inclusion in the attendance.
	-- Parameter: checkMsg  -- Type of check (eg. "Fire resist", "Item resist").
	-- Parameter: statusNum -- Status number to use (eg. EkRaidAttend_PlayerStatus_ITEM)
	-- ------------------
	local index, newSave, taken;

	taken, index, newSave = EkRaidAttend_SpecialFunc(user_msg, sys_msg, durSub, minimum, checkMsg, statusNum);

	if (not taken) then
		EkRaidAttend_UIRefresh();
		return;
	end

	if (newSave) then
		-- Add new save entry to the SaveFrame list.
		local list = EkRaidAttend_ListsFrame_List;
		local rec = EkRaidAttend_ListsFrame_ListInitRec(index);
		table.insert(list, rec);
		EkRaidAttend_ListsFrame_Sort(EkRaidAttend_ListsFrame_Order);
	end

	-- Update UI if visible.
	if (EkRaidAttend_Frame_:IsShown()) then

		-- If saved attendance players frame is currently shown, and the saved
		-- attendance name just taken matches the one being viewed, then
		-- we need to reinitalize the players frame list before we refresh it.
		if (EkRaidAttend_PlayersFrame_:IsShown()) then

			if (EkRaidAttend_PlayersFrame_RaidIndex == index) then
				EkRaidAttend_PlayersFrame_ListInit();
			end
		end

		EkRaidAttend_Frame_Refresh();
	end

	-- Set flag to indicate that the user may want to reload the ui.
	EkRaidAttend_ReloadFlag = 1;
end

function EkRaidAttend_SpecialFunc(user_msg, sys_msg, durSub, minimum, checkMsg, statusNum)
	-- ------------------
	-- Special attendance function (resistance check, item check, etc).
	--
	-- Parameter: user_msg  -- User supplied message to appear at end of title.
	-- Parameter: sys_msg   -- System message to appear after date/time.
	-- Parameter: durSub    -- CT_RADurability_Shown[] subscript of the value to use.
	-- Parameter: minimum   -- Minimum value required for inclusion in the attendance.
	-- Parameter: checkMsg  -- Type of check (eg. "Fire resist", "Item resist").
	-- Parameter: statusNUm -- Status number to use (eg. EkRaidAttend_PlayerStatus_ITEM)
	--
	-- Returns: 1) taken -- true if attendance was taken, false if it was not.
	--          2) title -- name that the attendance was recorded under.
	--          3) newSave -- true if attendance name was not already in the list, false if it was.
	-- ------------------
	local name;
	local newSave;
	local main, rec, value;

	local this_zone, server_hour, server_minute, local_date;
	local title

	local attend_count;
	local temp;

	-- Get zone, date, time information.
	this_zone = GetRealZoneText();
	server_hour, server_minute = GetGameTime();
	local_date = date("*t");

	-- Generate attendance title (eg. "Molten Core 2006/06/10 11:00:00 13:00 Timed start.")
	-- Generate attendance title (eg. "Lord Kazzak 2006/06/10 23:00:00 01:00 Boss.")

	-- Note: Over time there have been 4 date/time formats used in the attendance titles.
	-- The first was "MM/DD HH:MMAM HH:MMAM" which was used prior to EkRaidAttend version 2.0.
	-- The second was "YYYY/MM/DD HH:MMAM HH:MMAM" which was used during testing of version 2.0.
	-- The third was "YYYY/MM/DD HH:MM:SSAM HH:MMAM" which is used by the release version of 2.0.
	-- The fourth was "YYYY/MM/DD HH:MM:SS HH:MM" which is used by the release version of 2.4.

	-- Start with zone name.
	title = this_zone;

	-- Add local date and time.
	title = title .. " " .. string.format("%04d/%02d/%02d %02d:%02d:%02d", local_date["year"], local_date["month"],
			local_date["day"], local_date["hour"], local_date["min"], local_date["sec"]);

	-- Add server time.
	title = title .. " " .. string.format("%02d:%02d", server_hour, server_minute) .. "";

	if ( sys_msg and sys_msg ~= "" ) then
		title = title .. " " .. sys_msg;
		title = title .. ".";
	end

	if ( user_msg and user_msg ~= "" ) then
		title = title .. " " .. user_msg;
	end

	-- Translate certain characters.
	title = string.gsub(title, "%[", "(");
	title = string.gsub(title, "%]", ")");
	title = string.gsub(title, "\"", "'");

	if (EkRaidAttend_Data[title] == nil) then
		newSave = true;  -- not in list yet.
	else
		newSave = false;  -- overwriting existing save
	end

	EkRaidAttend_Data[title] = {};

	if (EkRaidAttend_MainNameUse == 1 and EkRaidAttend_RecordMainName == 1 and IsInGuild()) then
		EkRaidAttend_GuildRoster();
		EkRaidAttend_GetGuildInfo();
	end

	attend_count = 0;
	for i=1,getn(CT_RADurability_Shown) do
		rec = CT_RADurability_Shown[i];
		name = rec[1];
		value = rec[durSub];

		main = nil;
		if (EkRaidAttend_MainNameUse == 1 and EkRaidAttend_RecordMainName == 1 and IsInGuild()) then
			-- Get name of main character for this player.
			local pos = EkRaidAttend_IsNameInGuild(name);
			if (pos > 0) then
				-- Name is in the guild.
				local guildRec = EkRaidAttend_GuildInfo[pos];
				main = guildRec["main"];
			end
		end

		if (value >= minimum) then
			if (main and EkRaidAttend_MainNameUse == 1 and EkRaidAttend_RecordMainName == 1 and main ~= name) then
				-- Remember name that was actually in the raid.
				EkRaidAttend_Data[title][main] = statusNum .. EkRaidAttend_StatusSep .. value .. EkRaidAttend_StatusSep .. name;
			else
				EkRaidAttend_Data[title][name] = statusNum .. EkRaidAttend_StatusSep .. value;
			end
			attend_count = attend_count + 1;
		end
	end

	-- Display summary of the attendance just taken.
--	EkRaidAttend_Print("------------------");
	if (attend_count == 1) then
		temp = "name";
	else
		temp = "names";
	end

	EkRaidAttend_Print(checkMsg .. " (" .. attend_count .. " " .. temp .. ") recorded as:");
	EkRaidAttend_Print("   " .. title);
--	EkRaidAttend_Print("------------------");

	return true, title, newSave;
end

-- ------------------------------------------------------------------
-- Miscellaneous
-- ------------------------------------------------------------------

function EkRaidAttend_Print(msg)
	-- ----------------
	-- Print a message.
	-- ----------------
	DEFAULT_CHAT_FRAME:AddMessage(EkRaidAttend_AddonName .. " " .. msg);
	return;
end


function EkRaidAttend_Print2(msg)
	-- ----------------
	-- Print a message.
	-- ----------------
	DEFAULT_CHAT_FRAME:AddMessage(msg);
	return;
end


function EkRaidAttend_TestPrint(msg)
	-- ----------------
	-- Print a message (in test mode only).
	-- ----------------
	if (EkRaidAttend_Test == 1) then
		DEFAULT_CHAT_FRAME:AddMessage(EkRaidAttend_AddonName .. " " .. msg);
	end
	return;
end


function EkRaidAttend_TableLen(table)
	-- ----------
	-- Determine length of a table whose elements are accessed via keys.
	-- ----------
	local count = 0;
	for index, value in table do
		count = count + 1;
	end
	return count;
end


function EkRaidAttend_IsEmpty(text)
	-- -----------
	-- Test if a string is empty or all blanks.
	-- -----------
	local count;
	local length = string.len(text);

	for i=1, length, 1 do
		if ( string.sub(text, i, i) ~= " " ) then
			return false;
		end
	end

	return true;
end


function EkRaidAttend_GetDate(year, month, day, hour, min, sec)
	-- ----------
	-- Returns date table for the specified numbers.
	-- ----------
	local tbl = {year = year, month = month, day = day, hour = hour, min = min, sec = sec};

	-- Determine correct daylight savings time flag.
	local date1 = date("*t", time(tbl));

	-- Assign correct dst value back to the table we're building.
	tbl.isdst = date1.isdst;

	-- Reconvert the table now that we have the correct dst flag, to fill in
	-- the other values we weren't passed as parameters.
	return date("*t", time(tbl));
end


function EkRaidAttend_GetGameTime()
	-- -----------
	-- Get game time (server time).
	--
	-- Returns: Local date("*t") array with hour & min replaced with the server hour & min.
	--
	--          The goal is to get a value that can be used in a date() call to format the
	--          time with locale's am/pm indicator.  The local date stored in the returned
	--          value should be ignored, as it may not be correct depending on the current time
	--          and the time zone you are in compared to the server's time zone.
	-- -----------

	-- Get locate date values.
	local local_date = date("*t");

	-- Get server's hour and min values.
	local server_hour, server_min = GetGameTime();

	-- Replace local date's hour and min with server values.
	local_date.hour = server_hour;
	local_date.min = server_min;

	-- Return time value.
	return time(local_date);
end


function EkRaidAttend_ShowDateTime()
	-- -----------
	-- Show current date/time.
	-- -----------
	local text;

	-- Server time is 09:33 PM.
	-- Local time is 11:33:00 PM, Thursday, January 31, 2005.

	text = "Server time is ".. date("%I:%M %p.", EkRaidAttend_GetGameTime());
	EkRaidAttend_Print(text);

	text = "Local time is " .. date("%I:%M:%S %p, %A %B %d, %Y.", time());
	EkRaidAttend_Print(text);
end


function EkRaidAttend_InRaid()
	-- -----------
	-- Test if we are currently in a raid.
	-- -----------
	local inRaid;
	if (EkRaidAttend_Test > 0) then
		-- In test mode. Pretend we are in a raid.
		inRaid = 1;
	else
		if (GetNumRaidMembers() > 0) then
			inRaid = 1;
		else
			inRaid = nil;
		end
	end
	return inRaid;
end


function EkRaidAttend_GuildRoster()
	-- --------------
	-- Request guild roster from server.
	-- --------------
	if (not IsInGuild()) then
		return;
	end
	-- Add 1 to show we are expecting another guild roster update event.
--	EkRaidAttend_GuildRosterUpdates = EkRaidAttend_GuildRosterUpdates + 1;
	GuildRoster();
end

function EkRaidAttend_SetGuildRosterShowOffline(offline)
	-- --------------
	-- Set whether to see the offline players in the guild or not.
	-- --------------
	if (not IsInGuild()) then
		return;
	end
	-- Add 1 to show we are expecting another guild roster update event.
	EkRaidAttend_GuildRosterUpdates = EkRaidAttend_GuildRosterUpdates + 1;
	SetGuildRosterShowOffline(offline);
end

function EkRaidAttend_GetRaidRosterInfo(i)
	-- -----------
	-- Get information about raid members.
	--
	-- NOTE: Sometimes the zone value returned by GetRaidRosterInfo() is nil.
	-- I've seen this happen when I've reloaded the UI while in the game.
	--
	-- According to http://www.wowwiki.com/API_GetRaidRosterInfo, there is
	-- a bug introduced by Blizzard in Feb 2005 which can result in the
	-- zone name being returned as nil.
	--
	-- I've seen it return my zone name as nil, and I've seen it return
	-- nil for most of the other people in my raid as well.
	--
	-- Update: 05/27/2006 I haven't seen the nil zone issue for some time now
	-- so I assume they've fixed it.
	-- -----------
	local name, rank, subgroup, level, class, fileName, zone, online, isDead = GetRaidRosterInfo(i);

	return name, rank, subgroup, level, class, fileName, zone, online, isDead;
end


function EkRaidAttend_GetGuildInfo(offline)
	-- --------------
	-- Get guild roster information.
	-- --------------
	if (not EkRaidAttend_GuildRosterFlag) then
		return;
	end

	EkRaidAttend_GuildRosterFlag = nil;

	local oldOffline = GetGuildRosterShowOffline();
	EkRaidAttend_SetGuildRosterShowOffline(offline);

	local num = GetNumGuildMembers();
	EkRaidAttend_GuildInfo = {};

	if (num > 0) then
		-- EkRaidAttend_GuildInfo[num] = {};
		local rec;
		local main;
		local name, rank, rankIndex, level, class, zone, group, note, officernote, online, status;
		for i=1, num do
			name, rank, rankIndex, level, class, zone, note, officernote, online, status = GetGuildRosterInfo(i);
			group = "no";

			if (name) then
				rec = {};
				rec["name"] = name;
				rec["lower"] = strlower(name);
				rec["rank"] = rank;
				rec["rankIndex"] = rankIndex;
				rec["class"] = class;
				rec["note"] = note;
				rec["officernote"] = officernote;
				rec["online"] = online;
				rec["level"] = level;

				main = nil;

				if (EkRaidAttend_MainNameUse == 1) then
					local pattern = EkRaidAttend_MainName_GetPattern();
					local pos1, pos2;
					if (EkRaidAttend_MainNameNote == 2) then
						-- Extract name of main character from the officer note.
						pos1, pos2, main = string.find(officernote, pattern);
					else
						-- Extract name of main character from the public note.
						pos1, pos2, main = string.find(note, pattern);
					end
				end

				-- If not using main names, or if one could not be found, then default to the character's name.
				if (main == nil or main == "") then
					main = name;
				end

				main = string.upper(strsub(main, 1, 1)) .. string.lower(strsub(main, 2));
				rec["main"] = main;  -- name of player's main character.

				table.insert(EkRaidAttend_GuildInfo, rec);
			end
		end
		-- Sort the table
		sort(EkRaidAttend_GuildInfo, function (a, b)
							if (a["lower"] < b["lower"]) then
								return true;
							else
								return false;
							end
						end)
	end

	EkRaidAttend_SetGuildRosterShowOffline(oldOffline);
end


function EkRaidAttend_IsNameInGuild(player)
	-- --------------
	-- Test if a player name is in the guild.
	-- Returns: a) If not found in guild list, returns 0.
	--          b) If found in guild list, returns subscript within EkRaidAttend_GuildInfo[].
	-- --------------
	local text = strlower(player);
	local textlen = strlen(text);
	local name, num, info;
	local left, right, mid;
	local findtext, rec, found;

	if (not IsInGuild()) then
		return 0;
	end

	EkRaidAttend_GetGuildInfo(1);

	info = EkRaidAttend_GuildInfo;
	num = getn(info);

	left = 1;
	right = getn(info);
	found = 0;

	while (left <= right) do
		mid = floor((left + right) / 2);
		rec = info[mid];

		if (rec["lower"] == text) then
			found = mid;
			break;
		end

		if (text < rec["lower"]) then
			right = mid - 1;
		else
			left  = mid + 1;
		end
	end

	return found;	
end

function EkRaidAttend_GetMainName(name)
	-- ----------
	-- Get main name of a character in the guild.
	--
	-- Returns: 1a) nil, if your are not in a guild, or the name is not in the guild roster.
	--          1b) the name of the character's main.
	--          2a) nil, if you are not in a guild.
	--          2b) 0, if name not found in guild roster
	--          2c) >0, if the name was found in the guild roster.
	-- ----------
	local main, pos, rec;

	if (IsInGuild()) then
		local pos;
		pos = EkRaidAttend_IsNameInGuild(name);
		if (pos ~= 0) then
			rec = EkRaidAttend_GuildInfo[pos];
			main = rec["main"];
		end
	end

	return main, pos;
end

function EkRaidAttend_MainName_Convert(text)
	-- ----------
	-- Convert special characters in the main name start/end strings.
	--
	-- Returns: Modified string usable in a string.find() pattern.
	-- ----------
	local special = {"^", "$", "(", ")", "%", ".", "[", "]", "*", "+", "-", "?"};
	local len = string.len(text);
	local result = "";
	for i = 1, len do
		char = string.sub(text, i, i);
		for j = 1, getn(special) do
			if (char == special[j]) then
				char = "%" .. char;
				break;
			end
		end
		result = result .. char;
	end
	return result;
end

function EkRaidAttend_MainName_GetPattern()
	-- ----------
	-- Create a main name pattern for use with string.find().
	--
	-- Returns: Pattern string.
	-- ----------
	local mainStart = EkRaidAttend_MainName_Convert(EkRaidAttend_MainNameStart);
	local mainEnd = EkRaidAttend_MainName_Convert(EkRaidAttend_MainNameEnd);
	local pattern = mainStart .. "%s-(%S+)%s-" .. mainEnd;
	return pattern;
end

function EkRaidAttend_Name_AutoComplete()
	-- --------------
	-- Automatically complete player name as user types it.
	-- --------------
	local text = strlower(this:GetText());
	local textlen = strlen(text);
	local name, num, info;
	local left, right, mid;
	local findtext, rec;
	local left, right, mid;

	if (not IsInGuild()) then
		return;
	end

	EkRaidAttend_GetGuildInfo(1);

	info = EkRaidAttend_GuildInfo;
	num = getn(info);

	findtext = "^" .. text;

	left = 1;
	right = getn(info);

	while (left <= right) do
		mid = floor((left + right) / 2);
		rec = info[mid];

		-- if (rec["lower"] == text) then
		if (strfind(rec["lower"], findtext)) then

			-- Update the name
			this:SetText(rec["name"]);
			this:HighlightText(textlen, -1);
			return;
		end

		if (text < rec["lower"]) then
			right = mid - 1;
		else
			left  = mid + 1;
		end
	end
end


function EkRaidAttend_EventPrint(force, event, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
	-- --------------
	-- Display event details when in test mode.
	-- --------------
	if (not event) then return; end

	if (EkRaidAttend_Test > 0 or force == 1) then
--[[
		EkRaidAttend_Print(event);
		if (arg1) then EkRaidAttend_Print("arg1=[" .. arg1 .. "] " .. type(arg1)); end
		if (arg2) then EkRaidAttend_Print("arg2=[" .. arg2 .. "] " .. type(arg2)); end
		if (arg3) then EkRaidAttend_Print("arg3=[" .. arg3 .. "] " .. type(arg3)); end
		if (arg4) then EkRaidAttend_Print("arg4=[" .. arg4 .. "] " .. type(arg4)); end
		if (arg5) then EkRaidAttend_Print("arg5=[" .. arg5 .. "] " .. type(arg5)); end
		if (arg6) then EkRaidAttend_Print("arg6=[" .. arg6 .. "] " .. type(arg6)); end
		if (arg7) then EkRaidAttend_Print("arg7=[" .. arg7 .. "] " .. type(arg7)); end
		if (arg8) then EkRaidAttend_Print("arg8=[" .. arg8 .. "] " .. type(arg8)); end
		if (arg9) then EkRaidAttend_Print("arg9=[" .. arg9 .. "] " .. type(arg9)); end
]]

		local text = event;
		if (arg1) then text = text .. ", arg1=[" .. arg1 .. "] " .. type(arg1); end
		if (arg2) then text = text .. ", arg2=[" .. arg2 .. "] " .. type(arg2); end
		if (arg3) then text = text .. ", arg3=[" .. arg3 .. "] " .. type(arg3); end
		if (arg4) then text = text .. ", arg4=[" .. arg4 .. "] " .. type(arg4); end
		if (arg5) then text = text .. ", arg5=[" .. arg5 .. "] " .. type(arg5); end
		if (arg6) then text = text .. ", arg6=[" .. arg6 .. "] " .. type(arg6); end
		if (arg7) then text = text .. ", arg7=[" .. arg7 .. "] " .. type(arg7); end
		if (arg8) then text = text .. ", arg8=[" .. arg8 .. "] " .. type(arg8); end
		if (arg9) then text = text .. ", arg9=[" .. arg9 .. "] " .. type(arg9); end
		EkRaidAttend_Print(text);
	end
end

-- *!*
-- -------------------------------------------------------------------------
-- EkRaidAttend_Frame
-- -------------------------------------------------------------------------

EkRaidAttend_Frame_SUBFRAMES = {
	"EkRaidAttend_MainFrame_",
	{"EkRaidAttend_OptionsFrame_", "EkRaidAttend_OptionsFrame2_", "EkRaidAttend_OptionsFrame3_", "EkRaidAttend_OptionsFrame4_"},
	{"EkRaidAttend_ListsFrame_", "EkRaidAttend_PlayersFrame_", "EkRaidAttend_NoteFrame_"},
};

EkRaidAttend_Frame_TabMain = 1;
EkRaidAttend_Frame_TabOptions = 2;
EkRaidAttend_Frame_TabLists = 3;

function EkRaidAttend_Frame_UnlockWindow(movable)
	-- --------------
	-- Make window movable/unmovable.
	-- --------------
	EkRaidAttend_MovableWindow = movable;
	HideUIPanel(EkRaidAttend_Frame_);
	if ( movable == 1 ) then
		EkRaidAttend_Frame_UISpecialFrame(1);
		EkRaidAttend_Frame_UIPanel(0);
		EkRaidAttend_Frame_MoveButton:Show();
	else
		EkRaidAttend_Frame_MoveButton:Hide();
		EkRaidAttend_Frame_UISpecialFrame(0);
		EkRaidAttend_Frame_UIPanel(1);
	end
	ShowUIPanel(EkRaidAttend_Frame_);
end

function EkRaidAttend_Frame_UIPanel(set)
	-- --------------
	-- Set or clear standard UI Panel settings for the window.
	-- (this allows the frame to act like a standard UI panel (shift right when you open another).
	-- --------------
	if (set == 1) then
		UIPanelWindows["EkRaidAttend_Frame_"] = { area = "left", pushable = 1, whileDead = 1 };
	else
		UIPanelWindows["EkRaidAttend_Frame_"] = nil;
	end
end

function EkRaidAttend_Frame_UISpecialFrame(set)
	-- --------------
	-- Set or clear UI Special Frame settings for the window.
	-- (this allows you to press ESC to close the frame).
	-- --------------
	if (set == 1) then
		tinsert(UISpecialFrames, "EkRaidAttend_Frame_");
	else
		for key, val in UISpecialFrames do
			if ( val == "EkRaidAttend_Frame_" ) then
				val = nil;
			end
		end
	end
end

function EkRaidAttend_Frame_ShowSubFrame(frameName)
	-- ----------
	-- Show/hide the sub frames.
	-- ----------
	EkRaidAttend_Frame_ShowSubFrameTable(frameName, EkRaidAttend_Frame_SUBFRAMES);
end

function EkRaidAttend_Frame_ShowSubFrameTable(frameName, frameNameTable)
	-- ----------
	-- Show/hide the sub frame names listed in a table.
	-- ----------
	local frame;
	for index, value in frameNameTable do
		if ( type(value) == "table" ) then
			EkRaidAttend_Frame_ShowSubFrameTable(frameName, value);
		else
			frame = getglobal(value);
			if ( frame ) then
				if ( value == frameName ) then
					frame:Show();
				else
					frame:Hide();
				end
			end
		end
	end
end

function EkRaidAttend_Frame_HideSubFrames()
	-- ----------
	-- Hide the sub frames.
	-- ----------
	EkRaidAttend_Frame_HideSubFrameTable(EkRaidAttend_Frame_SUBFRAMES);
end

function EkRaidAttend_Frame_HideSubFrameTable(frameNameTable)
	-- ----------
	-- Hide the sub frame names listed in a table.
	-- ----------
	local frame;
	for index, value in frameNameTable do
		if ( type(value) == "table" ) then
			EkRaidAttend_Frame_HideSubFrameTable(value);
		else
			frame = getglobal(value);
			if ( frame ) then
				frame:Hide();
			end
		end
	end
end

function EkRaidAttend_Frame_OnLoad()
	-- ----------
	-- Frame has been loaded.
	-- ----------
	local frame = getglobal("EkRaidAttend_Frame_");

	PanelTemplates_SetNumTabs(this, getn(EkRaidAttend_Frame_SUBFRAMES));

	-- Initial tab to be selected
	frame.selectedTab = EkRaidAttend_Frame_TabMain;

	PanelTemplates_UpdateTabs(this);
end

function EkRaidAttend_Frame_OnShow()
	-- ----------
	-- Show the frame.
	-- ----------
	local fname = "EkRaidAttend_Frame_";
	local frame = getglobal(fname);
	local tab = frame.selectedTab;

	if (tab == EkRaidAttend_Frame_TabLists) then
		if (EkRaidAttend_ListsFrame_Mode == 1) then
			fname = EkRaidAttend_Frame_SUBFRAMES[tab][2]; -- Players
		elseif (EkRaidAttend_ListsFrame_Mode == 2) then
			fname = EkRaidAttend_Frame_SUBFRAMES[tab][3]; -- Note
		else
			fname = EkRaidAttend_Frame_SUBFRAMES[tab][1]; -- Lists
		end
	elseif (tab == EkRaidAttend_Frame_TabOptions) then
		fname = EkRaidAttend_Frame_SUBFRAMES[tab][EkRaidAttend_OptionsFrame_Page];
	else
		fname = EkRaidAttend_Frame_SUBFRAMES[tab];
	end

	EkRaidAttend_Frame_ShowSubFrame(fname);
	PlaySound("igMainMenuOpen");
end

function EkRaidAttend_Frame_GetTab()
	-- ----------
	-- Get current tab number.
	-- ----------
	local frame = getglobal("EkRaidAttend_Frame_");
	local tab = frame.selectedTab;
	return tab;
end

function EkRaidAttend_Frame_Refresh()
	-- ----------
	-- Refresh the frame.
	-- (also called from EkRaidAttend.lua).
	-- ----------
	local frame = getglobal("EkRaidAttend_Frame_");
	local tab = frame.selectedTab;

	if ( tab == EkRaidAttend_Frame_TabMain ) then
		EkRaidAttend_MainFrame_OnShow();

	elseif ( tab == EkRaidAttend_Frame_TabOptions ) then
		EkRaidAttend_OptionsFrame_OnShow();

	elseif (tab == EkRaidAttend_Frame_TabLists) then
		if (EkRaidAttend_ListsFrame_Mode == 1) then
			EkRaidAttend_PlayersFrame_OnShow();
		elseif (EkRaidAttend_ListsFrame_Mode == 2) then
			EkRaidAttend_NoteFrame_OnShow();
		else
			EkRaidAttend_ListsFrame_OnShow();
		end

	end
end

function EkRaidAttend_Frame_OnHide()
	-- ----------
	-- Hide the frame.
	-- ----------
	PlaySound("igMainMenuClose");
	EkRaidAttend_Frame_HideSubFrames();
	this:StopMovingOrSizing();
end

function EkRaidAttend_Frame_Tab_OnClick()
	-- ----------
	-- User clicked a tab on the frame.
	-- ----------
	EkRaidAttend_ListsFrame_MenuNum = 1;
	EkRaidAttend_PlayersFrame_MenuNum = 1;
	PanelTemplates_Tab_OnClick(EkRaidAttend_Frame_);
	EkRaidAttend_Frame_OnShow();
end

function EkRaidAttend_Frame_GotoTab(tab)
	-- ----------
	-- Display one of the UI tab pages.
	-- ----------
	local frame = getglobal("EkRaidAttend_Frame_");

	PanelTemplates_SetTab(frame, tab);
	EkRaidAttend_ListsFrame_MenuNum = 1;
	EkRaidAttend_PlayersFrame_MenuNum = 1;
	EkRaidAttend_Frame_OnShow();
end

function EkRaidAttend_Frame_MenuButton_HideAll()
	-- ----------
	-- Hide all menu buttons.
	-- ----------
	EkRaidAttend_Frame_MenuButton1:Hide();
	EkRaidAttend_Frame_MenuButton2:Hide();
	EkRaidAttend_Frame_MenuButton3:Hide();
	EkRaidAttend_Frame_MenuButton4:Hide();
	EkRaidAttend_Frame_MenuButton5:Hide();
	EkRaidAttend_Frame_MenuButton6:Hide();
	EkRaidAttend_Frame_MenuButton7:Hide();
	EkRaidAttend_Frame_MenuButton8:Hide();
	EkRaidAttend_Frame_MenuButton9:Hide();
end

function EkRaidAttend_Frame_MenuButton_OnClick(buttonNum)
	-- ----------
	-- User clicked on a menu button.
	-- ----------
	local tab = EkRaidAttend_Frame_.selectedTab;

	if (tab == EkRaidAttend_Frame_TabLists) then
		local mode = EkRaidAttend_ListsFrame_Mode;
		if (mode == 0) then
			EkRaidAttend_ListsFrame_MenuButton_OnClick(buttonNum);
		elseif (mode == 1) then
			EkRaidAttend_PlayersFrame_MenuButton_OnClick(buttonNum);
		elseif (mode == 2) then
			EkRaidAttend_NoteFrame_MenuButton_OnClick(buttonNum);
		end
	end
end

function EkRaidAttend_Frame_MenuButton_OnEnter(buttonNum)
	-- ----------
	-- Mouse is over a menu button.
	-- ----------
	local tab = EkRaidAttend_Frame_.selectedTab;

	EkRaidAttend_Frame_MenuButton_Over = buttonNum;  -- Mouse is over this button.

	if (tab == EkRaidAttend_Frame_TabLists) then
		local mode = EkRaidAttend_ListsFrame_Mode;
		if (mode == 0) then
			EkRaidAttend_ListsFrame_MenuButton_OnEnter(buttonNum);
		elseif (mode == 1) then
			EkRaidAttend_PlayersFrame_MenuButton_OnEnter(buttonNum);
		elseif (mode == 2) then
			EkRaidAttend_NoteFrame_MenuButton_OnEnter(buttonNum);
		end
	end
end

function EkRaidAttend_Frame_MenuButton_OnLeave(buttonNum)
	-- ----------
	-- Mouse is leaving a menu button.
	--
	-- buttonNum -- may be nil
	-- ----------
	EkRaidAttend_Frame_MenuButton_Over = nil;  -- Mouse is no longer over this button.
	GameTooltip:Hide();
end

-- *!*
-- -------------------------------------------------------------------------
-- EkRaidAttend_MainFrame (the "main" tab)
-- -------------------------------------------------------------------------

function EkRaidAttend_MainFrame_OnShow()
	-- ----------
	-- Show the frame.
	-- ----------
	EkRaidAttend_MainFrame_TitleText:SetText("EkRaidAttend " .. EkRaidAttend_cVersion);

	EkRaidAttend_MainFrame_CommentEB_Update();
	EkRaidAttend_MainFrame_ClearCommentCB_Update();
	EkRaidAttend_MainFrame_TimedButton_Update();
	EkRaidAttend_MainFrame_TimerButton_Update();
	EkRaidAttend_MainFrame_TimerSetButton_Update();
	EkRaidAttend_MainFrame_TimedNextText_Update();
	EkRaidAttend_MainFrame_TimedLastText_Update();

	EkRaidAttend_Frame_MenuButton_HideAll();
end

function EkRaidAttend_MainFrame_ClearFocus()
	-- ----------
	-- Clear editbox highlights and focus.
	-- ----------
	local TimerEB = getglobal("EkRaidAttend_MainFrame_TimerEB");
	local CommentEB = getglobal("EkRaidAttend_MainFrame_CommentEB");

	TimerEB:ClearFocus();
	CommentEB:ClearFocus();
end

-- ----------
-- "Comment"
-- ----------
function EkRaidAttend_MainFrame_CommentEB_EditStart()
	-- ----------
	-- Start editing the comment value.
	-- ----------
	local CommentEB = getglobal("EkRaidAttend_MainFrame_CommentEB");

	if ( CommentEB.editing ) then
		return;
	end

	CommentEB:HighlightText();
	CommentEB.editing = 1;
end

function EkRaidAttend_MainFrame_CommentEB_EditStop(cancel)
	-- ----------
	-- User has stopped editing the comment value.
	-- ----------
	local CommentEB = getglobal("EkRaidAttend_MainFrame_CommentEB");

	if ( not CommentEB.editing ) then
		return;
	end

	local value = CommentEB:GetText();

	CommentEB:HighlightText(0, 0);
	CommentEB.editing = nil;

	if ( not cancel ) then
		-- Save new value.
		EkRaidAttend_Comment = value;
	else
		-- Restore original value.
		EkRaidAttend_MainFrame_CommentEB_Update();
	end
end

function EkRaidAttend_MainFrame_CommentEB_Update()
	-- ----------
	-- Update the comment editbox.
	-- ----------
	local CommentEB = getglobal("EkRaidAttend_MainFrame_CommentEB");

	CommentEB:SetText(EkRaidAttend_Comment);
end

function EkRaidAttend_MainFrame_ClearCommentCB_OnClick()
	-- ----------
	-- Toggle the "clear comment after attendance" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_MainFrame_ClearCommentCB");

	EkRaidAttend_MainFrame_ClearFocus();

	if ( CB:GetChecked() ) then
		EkRaidAttend_ClearComment = 1;
	else
		EkRaidAttend_ClearComment = 0;
	end
end

function EkRaidAttend_MainFrame_ClearCommentCB_Update()
	-- ----------
	-- Update the "clear comment after attendance" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_MainFrame_ClearCommentCB");

	CB:SetChecked(EkRaidAttend_ClearComment);
end

-- ----------
-- "Start/stop timed attendance"
-- ----------
function EkRaidAttend_MainFrame_TimedButton_OnClick()
	-- ----------
	-- User clicked the start/stop timed attendance button.
	-- ----------
	EkRaidAttend_MainFrame_ClearFocus();

	if ( EkRaidAttend_Status == 0 ) then
	        EkRaidAttend_TimedStart("");
	else
	        EkRaidAttend_TimedStop("");
	end

	EkRaidAttend_MainFrame_TimedButton_OnEnter();
end

function EkRaidAttend_MainFrame_TimedButton_Update()
	-- ----------
	-- Update the "Start/Stop timed attendance" button/text.
	-- ----------
	local frameTB = getglobal("EkRaidAttend_MainFrame_TimedButton");
	local frameTT = getglobal("EkRaidAttend_MainFrame_TimedText");

	if ( EkRaidAttend_Status == 0 ) then
		frameTB:SetText("Start");
		frameTT:SetText("Start timer and take attendance.");
	else
		frameTB:SetText("Stop");
		frameTT:SetText("Stop timer and take attendance.");
	end
end

function EkRaidAttend_MainFrame_TimedButton_OnEnter()
	-- ----------
	-- Pointer is over the "start/stop timed attendance" button.
	-- ----------
	if ( EkRaidAttend_Status == 0 ) then
		GameTooltip_AddNewbieTip("Start timed attendance", 1.0, 1.0, 1.0, "Starts the timer and take an attendance.", 1);
	else
		GameTooltip_AddNewbieTip("Stop timed attendance", 1.0, 1.0, 1.0, "Stops the timer and take an attendance.", 1);
	end
end

-- ----------
-- "Timer on/off"
-- ----------
function EkRaidAttend_MainFrame_TimerButton_OnClick()
	-- ----------
	-- User clicked the "Timer on/off" button.
	-- ----------
	EkRaidAttend_MainFrame_ClearFocus();

	if ( EkRaidAttend_Status == 0 ) then
	        EkRaidAttend_TimerOn();
	else
	        EkRaidAttend_TimerOff();
	end

	EkRaidAttend_MainFrame_TimerButton_OnEnter();
end

function EkRaidAttend_MainFrame_TimerButton_Update()
	-- ----------
	-- Update the "Timer on/off" button/text.
	-- ----------
	local frameTB = getglobal("EkRaidAttend_MainFrame_TimerButton");
	local frameTT = getglobal("EkRaidAttend_MainFrame_TimerText");

	if ( EkRaidAttend_Status == 0 ) then
		frameTB:SetText("Timer on");
		frameTT:SetText("Start timer (no attendance taken).");
	else
		frameTB:SetText("Timer off");
		frameTT:SetText("Stop timer (no attendance taken).");
	end
end

function EkRaidAttend_MainFrame_TimerButton_OnEnter()
	-- ----------
	-- Pointer is over the "Timer on/off" button.
	-- ----------
	if ( EkRaidAttend_Status == 0 ) then
		GameTooltip_AddNewbieTip("Turn timer on", 1.0, 1.0, 1.0, "Starts the timer without taking an attendance.", 1);
	else
		GameTooltip_AddNewbieTip("Turn timer off", 1.0, 1.0, 1.0, "Stops the timer without taking an attendance.", 1);
	end
end

-- ----------
-- "Edit/Set timer"
-- ----------
function EkRaidAttend_MainFrame_TimerSetButton_OnClick()
	-- ----------
	-- User clicked the "Edit timer" button.
	-- ----------
	local TimerEB = getglobal("EkRaidAttend_MainFrame_TimerEB");
	local TimerSetB = getglobal("EkRaidAttend_MainFrame_TimerSetButton");
	local TimerValueText = getglobal("EkRaidAttend_MainFrame_TimerValueText");
	local TimerSetText = getglobal("EkRaidAttend_MainFrame_TimerSetText");

	if ( not TimerEB.editing ) then
		EkRaidAttend_MainFrame_ClearFocus();

		TimerSetB:SetText("Set timer");
		TimerSetB:Show();

		TimerValueText:Hide();

		TimerSetText:Show();

		TimerEB:SetNumber(EkRaidAttend_Len);
		TimerEB:HighlightText();
		TimerEB:Show();
		TimerEB:SetFocus();
	else
		EkRaidAttend_MainFrame_TimerSetButton_Update();
	end
end

function EkRaidAttend_MainFrame_TimerEB_EditStart()
	-- ----------
	-- Start editing the timer value.
	-- ----------
	local TimerEB = getglobal("EkRaidAttend_MainFrame_TimerEB");

	if ( TimerEB.editing ) then
		return;
	end

	TimerEB.editing = 1;
	TimerEB:HighlightText();
end

function EkRaidAttend_MainFrame_TimerEB_EditStop(cancel)
	-- ----------
	-- User has stopped editing the timer value.
	-- ----------
	local TimerEB = getglobal("EkRaidAttend_MainFrame_TimerEB");

	if ( not TimerEB.editing ) then
		return;
	end

	local value = TimerEB:GetNumber();

	TimerEB.editing = nil;
	TimerEB:HighlightText(0, 0);

	if ( not cancel ) then
		if ( value < 1 ) then
			value = 1;
		elseif ( value > 600) then
			value = 600;
		end
		EkRaidAttend_TimerSet(value);
	end

	EkRaidAttend_MainFrame_TimerSetButton_Update();
end

function EkRaidAttend_MainFrame_TimerSetButton_Update()
	-- ----------
	-- Reset the "Edit/Set timer" button/text/editbox.
	-- ----------
	local TimerEB = getglobal("EkRaidAttend_MainFrame_TimerEB");
	local TimerSetB = getglobal("EkRaidAttend_MainFrame_TimerSetButton");
	local TimerValueText = getglobal("EkRaidAttend_MainFrame_TimerValueText");
	local TimerSetText = getglobal("EkRaidAttend_MainFrame_TimerSetText");

	TimerEB:Hide();

	TimerSetText:Hide();

	TimerValueText:SetText("Timer interval is " .. EkRaidAttend_Len .. " minutes.");
	TimerValueText:Show();

	TimerSetB:SetText("Edit timer");
	TimerSetB:Show();
end

-- ----------
-- "Next/last timed attendance"
-- ----------

function EkRaidAttend_MainFrame_TimedNextText_Update()
	-- ----------
	-- Update the "next timed attendance" text.
	-- ----------
	local frameTNT = getglobal("EkRaidAttend_MainFrame_TimedNextText");

	if ( EkRaidAttend_Status == 0 or not EkRaidAttend_InRaid() ) then
		frameTNT:SetText("");
	else
	        local nextTimed = "Next timed attendance is at " .. date("%I:%M %p", EkRaidAttend_AutoTime) .. " local time.";
		frameTNT:SetText(nextTimed);
	end
end

function EkRaidAttend_MainFrame_TimedLastText_Update()
	-- ----------
	-- Update the "last timed attendance" text.
	-- ----------
	local frameTNT = getglobal("EkRaidAttend_MainFrame_TimedLastText");

	if (not EkRaidAttend_LastTime) then
		-- Haven't done one yet.
		frameTNT:SetText("");
	else
	        local nextTimed = "Last timed attendance was at " .. date("%I:%M %p", EkRaidAttend_LastTime) .. " local time.";
		frameTNT:SetText(nextTimed);
	end
end

-- ----------
-- "Zone/Instant"
-- ----------

function EkRaidAttend_MainFrame_ZoneButton_OnClick()
	-- ----------
	-- User clicked the "Zone attendance" button.
	-- ----------
	EkRaidAttend_MainFrame_ClearFocus();
	EkRaidAttend_Zone("");
end

function EkRaidAttend_MainFrame_InstantButton_OnClick()
	-- ----------
	-- User clicked the "Instant attendance" button.
	-- ----------
	EkRaidAttend_MainFrame_ClearFocus();
	EkRaidAttend_Instant("")
end

-- *!*
-- -------------------------------------------------------------------------
-- EkRaidAttend_OptionsFrame (the "options" tab)
-- -------------------------------------------------------------------------

EkRaidAttend_OptionsFrame_Page = 1;

function EkRaidAttend_OptionsFrame_Bosses_OnLoad()
	-- ----------
	-- Options frame (bosses) is being loaded.
	-- ----------
	EkRaidAttend_OptionsFrame_BossList_UpdateBossIndexes();
end

function EkRaidAttend_OptionsFrame_OnShow()
	-- ----------
	-- Show the frame.
	-- ----------

	if (EkRaidAttend_OptionsFrame_Page == 1) then
		EkRaidAttend_OptionsFrame_TitleText:SetText("Options");
		EkRaidAttend_OptionsFrame_MovableCB_Update();
		EkRaidAttend_OptionsFrame_ShowVersionCB_Update();
		EkRaidAttend_OptionsFrame_ShowStatusCB_Update();
		EkRaidAttend_OptionsFrame_UnsavedReminderCB_Update();
		EkRaidAttend_OptionsFrame_UnsavedReminderEB_Update();
		EkRaidAttend_OptionsFrame_UnsavedReminderPromptCB_Update();
		EkRaidAttend_OptionsFrame_TimedReminderCB_Update();
		EkRaidAttend_OptionsFrame_TimedReminderEB_Update();
		EkRaidAttend_OptionsFrame_TimedReminderPromptCB_Update();

	elseif (EkRaidAttend_OptionsFrame_Page == 2) then
		EkRaidAttend_OptionsFrame2_TitleText:SetText("Options");
		EkRaidAttend_OptionsFrame_PlaySoundCB_Update();
		EkRaidAttend_OptionsFrame_ScreenshotCB_Update();
		EkRaidAttend_OptionsFrame_RaidScreenshotCB_Update();
		EkRaidAttend_OptionsFrame_ReloadCB_Update();
		EkRaidAttend_OptionsFrame_WaitListAttendCB_Update();
		EkRaidAttend_OptionsFrame_WaitListSeparateCB_Update();
		EkRaidAttend_OptionsFrame_SaveOfflineCB_Update();
		EkRaidAttend_OptionsFrame_ShowOnlineCB_Update();
		EkRaidAttend_OptionsFrame_ShowOfflineCB_Update();

	elseif (EkRaidAttend_OptionsFrame_Page == 3) then
		EkRaidAttend_OptionsFrame3_TitleText:SetText("Options");
		EkRaidAttend_OptionsFrame_MainNameUseCB_Update();
		EkRaidAttend_OptionsFrame_MainNameNoteDropDown_Update();
		EkRaidAttend_OptionsFrame_MainNameStartEB_Update();
		EkRaidAttend_OptionsFrame_MainNameEndEB_Update();
		EkRaidAttend_OptionsFrame_MainNameAttendCB_Update();

	else
		EkRaidAttend_OptionsFrame4_TitleText:SetText("Options");
		EkRaidAttend_OptionsFrame_BossCB_Update();
		EkRaidAttend_OptionsFrame_BossList_Update();
	end

	EkRaidAttend_OptionsFrame_ClearFocus();
	EkRaidAttend_Frame_MenuButton_HideAll();
end

function EkRaidAttend_OptionsFrame_ClearFocus()
	-- ----------
	-- Clear focus from edit boxes
	-- ----------
	local uReminderEB = getglobal("EkRaidAttend_OptionsFrame_UnsavedReminderEB");
	local tReminderEB = getglobal("EkRaidAttend_OptionsFrame_TimedReminderEB");
	local StartEB = getglobal("EkRaidAttend_OptionsFrame_MainNameStartEB");
	local EndEB = getglobal("EkRaidAttend_OptionsFrame_MainNameEndEB");

	uReminderEB:ClearFocus();
	tReminderEB:ClearFocus();
	StartEB:ClearFocus();
	EndEB:ClearFocus();
end

-- ----------
-- "Movable window"
-- ----------

function EkRaidAttend_OptionsFrame_MovableCB_OnClick()
	-- ----------
	-- Toggle the "movable window" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_MovableCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_MovableWindow = 1;
	else
		EkRaidAttend_MovableWindow = 0;
	end

	EkRaidAttend_Frame_UnlockWindow(EkRaidAttend_MovableWindow);

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_MovableCB_Update()
	-- ----------
	-- Update the "movable window" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_MovableCB");

	CB:SetChecked(EkRaidAttend_MovableWindow);
end

-- ----------
-- "Boss kill attendance"
-- ----------

function EkRaidAttend_OptionsFrame_BossCB_OnClick()
	-- ----------
	-- Toggle the "boss kill attendance" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_BossCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_BossKillAttend = 1;
	else
		EkRaidAttend_BossKillAttend = 0;
	end

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_BossCB_Update()
	-- ----------
	-- Update the "boss kill attendance" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_BossCB");

	CB:SetChecked(EkRaidAttend_BossKillAttend);
end

-- ----------
-- "Play sound when timed attendance taken"
-- ----------

function EkRaidAttend_OptionsFrame_PlaySoundCB_OnClick()
	-- ----------
	-- Toggle the "play sound when timed attendance taken" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_PlaySoundCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_PlayAttendSound = 1;
	else
		EkRaidAttend_PlayAttendSound = 0;
	end

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_PlaySoundCB_Update()
	-- ----------
	-- Update the "play sound when timed attendance taken" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_PlaySoundCB");

	CB:SetChecked(EkRaidAttend_PlayAttendSound);
end

-- ----------
-- "Take screenshot when attendance taken"
-- ----------

function EkRaidAttend_OptionsFrame_ScreenshotCB_OnClick()
	-- ----------
	-- Toggle the "screenshot" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_ScreenshotCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_TakeScreenshot = 2;
	else
		EkRaidAttend_TakeScreenshot = 0;
	end
	EkRaidAttend_OptionsFrame_ScreenshotCB_Update()
	EkRaidAttend_OptionsFrame_RaidScreenshotCB_Update()

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_ScreenshotCB_Update()
	-- ----------
	-- Update the "screenshot" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_ScreenshotCB");

	if (EkRaidAttend_TakeScreenshot == 0) then
		CB:SetChecked(0);
	else
		CB:SetChecked(1);
	end
end

-- ----------
-- "Show raid window for screenshot"
-- ----------

function EkRaidAttend_OptionsFrame_RaidScreenshotCB_OnClick()
	-- ----------
	-- Toggle the "raid window screenshot" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_ScreenshotCB");
	local CBraid = getglobal("EkRaidAttend_OptionsFrame_RaidScreenshotCB");

	if ( CBraid:GetChecked() ) then
		EkRaidAttend_TakeScreenshot = 2;
	else
		EkRaidAttend_TakeScreenshot = 1;
	end
	EkRaidAttend_OptionsFrame_ScreenshotCB_Update()
	EkRaidAttend_OptionsFrame_RaidScreenshotCB_Update()

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_RaidScreenshotCB_Update()
	-- ----------
	-- Update the "raid window screenshot" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_RaidScreenshotCB");

	if (EkRaidAttend_TakeScreenshot == 0) then
		CB:SetChecked(0);
	elseif (EkRaidAttend_TakeScreenshot == 1) then
		CB:SetChecked(0);
	else
		CB:SetChecked(1);
	end
end

-- ----------
-- "Reload UI when attendance taken"
-- ----------

function EkRaidAttend_OptionsFrame_ReloadCB_OnClick()
	-- ----------
	-- Toggle the "reload UI" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_ReloadCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_ReloadUI = 1;
	else
		EkRaidAttend_ReloadUI = 0;
	end

	-- Clear the "disabled prompt while in raid" flag for this option.
	EkRaidAttend_DisabledRaidPrompts[EkRaidAttend_PROMPT_RELOADUI_ATTEND] = nil;

	EkRaidAttend_OptionsFrame_ReloadCB_Update()

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_ReloadCB_Update()
	-- ----------
	-- Update the "reload UI" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_ReloadCB");

	if (EkRaidAttend_ReloadUI == 0) then
		CB:SetChecked(0);
	else
		CB:SetChecked(1);
	end
end

-- ----------
-- "Show addon information at login"
-- ----------

function EkRaidAttend_OptionsFrame_ShowVersionCB_OnClick()
	-- ----------
	-- Toggle the "Show addon information at login" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_ShowVersionCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_ShowVersionFlag = 1;
	else
		EkRaidAttend_ShowVersionFlag = 0;
	end
	EkRaidAttend_OptionsFrame_ShowVersionCB_Update()

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_ShowVersionCB_Update()
	-- ----------
	-- Update the "Show addon information at login" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_ShowVersionCB");

	if (EkRaidAttend_ShowVersionFlag == 0) then
		CB:SetChecked(0);
	else
		CB:SetChecked(1);
	end
end

-- ----------
-- "Show timed attendance status at login"
-- ----------

function EkRaidAttend_OptionsFrame_ShowStatusCB_OnClick()
	-- ----------
	-- Toggle the "Show timed attendance status at login" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_ShowStatusCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_ShowStatusFlag = 1;
	else
		EkRaidAttend_ShowStatusFlag = 0;
	end
	EkRaidAttend_OptionsFrame_ShowStatusCB_Update()

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_ShowStatusCB_Update()
	-- ----------
	-- Update the "Show timed attendance status at login" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_ShowStatusCB");

	if (EkRaidAttend_ShowStatusFlag == 0) then
		CB:SetChecked(0);
	else
		CB:SetChecked(1);
	end
end


-- ----------
-- "Record wait list when attendance is taken"
-- ----------

function EkRaidAttend_OptionsFrame_WaitListAttendCB_OnClick()
	-- ----------
	-- Toggle the "Record wait list when attendance is taken" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_WaitListAttendCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_WaitListAttend = 1;
		EkRaidAttend_WaitListSeparate = 1;
	else
		EkRaidAttend_WaitListAttend = 0;
		EkRaidAttend_WaitListSeparate = 0;
	end
	EkRaidAttend_OptionsFrame_WaitListAttendCB_Update()
	EkRaidAttend_OptionsFrame_WaitListSeparateCB_Update()

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_WaitListAttendCB_Update()
	-- ----------
	-- Update the "Record wait list when attendance is taken" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_WaitListAttendCB");

	if (EkRaidAttend_WaitListAttend == 0) then
		CB:SetChecked(0);
	else
		CB:SetChecked(1);
	end
end

-- ----------
-- "Create a separate wait list attendance"
-- ----------

function EkRaidAttend_OptionsFrame_WaitListSeparateCB_OnClick()
	-- ----------
	-- Toggle the "Create a separate wait list attendance" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_WaitListAttendCB");
	local CBsep = getglobal("EkRaidAttend_OptionsFrame_WaitListSeparateCB");

	if ( CBsep:GetChecked() ) then
		EkRaidAttend_WaitListSeparate = 1;
		EkRaidAttend_WaitListAttend = 1;
	else
		EkRaidAttend_WaitListSeparate = 0;
	end
	EkRaidAttend_OptionsFrame_WaitListAttendCB_Update()
	EkRaidAttend_OptionsFrame_WaitListSeparateCB_Update()

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_WaitListSeparateCB_Update()
	-- ----------
	-- Update the "Create a separate wait list attendance" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_WaitListSeparateCB");

	if (EkRaidAttend_WaitListSeparate == 0) then
		CB:SetChecked(0);
	else
		CB:SetChecked(1);
	end
end

-- ----------
-- "Unsaved attendance reminder"
-- ----------

function EkRaidAttend_OptionsFrame_UnsavedReminderCB_OnClick()
	-- ----------
	-- Toggle the "unsaved attendance reminder" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_UnsavedReminderCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_UnsavedReminderOn(false);
	else
		EkRaidAttend_UnsavedReminderOff(false);
	end
end

function EkRaidAttend_OptionsFrame_UnsavedReminderCB_Update()
	-- ----------
	-- Update the "unsaved attendance reminder" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_UnsavedReminderCB");

	if (EkRaidAttend_UnsavedReminderStatus == 0) then
		CB:SetChecked(0);
	else
		CB:SetChecked(1);
	end
end

function EkRaidAttend_OptionsFrame_UnsavedReminderEB_EditStart()
	-- ----------
	-- Start editing the reminder interval.
	-- ----------
	local ReminderEB = getglobal("EkRaidAttend_OptionsFrame_UnsavedReminderEB");

	if ( ReminderEB.editing ) then
		return;
	end

	ReminderEB.editing = 1;
	ReminderEB:HighlightText();
end

function EkRaidAttend_OptionsFrame_UnsavedReminderEB_EditStop(cancel)
	-- ----------
	-- User has stopped editing the reminder interval.
	-- ----------
	local ReminderEB = getglobal("EkRaidAttend_OptionsFrame_UnsavedReminderEB");

	if ( not ReminderEB.editing ) then
		return;
	end

	local value = ReminderEB:GetNumber();

	ReminderEB.editing = nil;
	ReminderEB:HighlightText(0, 0);

	if ( not cancel ) then
		if ( value < 1 ) then
			value = 1;
		elseif ( value > 600) then
			value = 600;
		end
		EkRaidAttend_UnsavedReminderSet(value, false);
	else
		EkRaidAttend_OptionsFrame_UnsavedReminderEB_Update();
	end
end

function EkRaidAttend_OptionsFrame_UnsavedReminderEB_Update()
	-- ----------
	-- Update the reminder interval.
	-- ----------
	local ReminderEB = getglobal("EkRaidAttend_OptionsFrame_UnsavedReminderEB");

	if ( not ReminderEB.editing ) then
		ReminderEB:SetNumber(EkRaidAttend_UnsavedReminderInterval);
	end
end

function EkRaidAttend_OptionsFrame_UnsavedReminderPromptCB_OnClick()
	-- ----------
	-- Toggle the "unsaved attendance reminder prompt" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_UnsavedReminderPromptCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_UnsavedReminderPrompt(false);
	else
		EkRaidAttend_UnsavedReminderOn(false);
	end
end

function EkRaidAttend_OptionsFrame_UnsavedReminderPromptCB_Update()
	-- ----------
	-- Update the "unsaved attendance reminder prompt" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_UnsavedReminderPromptCB");

	if (EkRaidAttend_UnsavedReminderStatus == 0) then
		CB:SetChecked(0);
	elseif (EkRaidAttend_UnsavedReminderStatus == 1) then
		CB:SetChecked(0);
	else
		CB:SetChecked(1);
	end
end

-- ----------
-- "Timed attendance reminder"
-- ----------

function EkRaidAttend_OptionsFrame_TimedReminderCB_OnClick()
	-- ----------
	-- Toggle the "Timed attendance reminder" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_TimedReminderCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_TimedReminderOn(false);
	else
		EkRaidAttend_TimedReminderOff(false);
	end
end

function EkRaidAttend_OptionsFrame_TimedReminderCB_Update()
	-- ----------
	-- Update the "Timed attendance reminder" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_TimedReminderCB");

	if (EkRaidAttend_TimedReminderStatus == 0) then
		CB:SetChecked(0);
	else
		CB:SetChecked(1);
	end
end

function EkRaidAttend_OptionsFrame_TimedReminderEB_EditStart()
	-- ----------
	-- Start editing the reminder interval.
	-- ----------
	local ReminderEB = getglobal("EkRaidAttend_OptionsFrame_TimedReminderEB");

	if ( ReminderEB.editing ) then
		return;
	end

	ReminderEB.editing = 1;
	ReminderEB:HighlightText();
end

function EkRaidAttend_OptionsFrame_TimedReminderEB_EditStop(cancel)
	-- ----------
	-- User has stopped editing the reminder interval.
	-- ----------
	local ReminderEB = getglobal("EkRaidAttend_OptionsFrame_TimedReminderEB");

	if ( not ReminderEB.editing ) then
		return;
	end

	local value = ReminderEB:GetNumber();

	ReminderEB.editing = nil;
	ReminderEB:HighlightText(0, 0);

	if ( not cancel ) then
		if ( value < 1 ) then
			value = 1;
		elseif ( value > 600) then
			value = 600;
		end
		EkRaidAttend_TimedReminderSet(value, false);
	else
		EkRaidAttend_OptionsFrame_TimedReminderEB_Update();
	end
end


function EkRaidAttend_OptionsFrame_TimedReminderEB_Update()
	-- ----------
	-- Update the reminder interval.
	-- ----------
	local ReminderEB = getglobal("EkRaidAttend_OptionsFrame_TimedReminderEB");

	if ( not ReminderEB.editing ) then
		ReminderEB:SetNumber(EkRaidAttend_TimedReminderInterval);
	end
end

function EkRaidAttend_OptionsFrame_TimedReminderPromptCB_OnClick()
	-- ----------
	-- Toggle the prompt to start timed attendance option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_TimedReminderPromptCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_TimedReminderPrompt(false);
	else
		EkRaidAttend_TimedReminderOn(false);
	end
end

function EkRaidAttend_OptionsFrame_TimedReminderPromptCB_Update()
	-- ----------
	-- Update the "Timed attendance reminder prompt" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_TimedReminderPromptCB");

	if (EkRaidAttend_TimedReminderStatus == 0) then
		CB:SetChecked(0);
	elseif (EkRaidAttend_TimedReminderStatus == 1) then
		CB:SetChecked(0);
	else
		CB:SetChecked(1);
	end
end

-- ----------
-- "Record offline players"
-- ----------

function EkRaidAttend_OptionsFrame_SaveOfflineCB_OnClick()
	-- ----------
	-- Toggle the "record offline names" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_SaveOfflineCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_SaveAttendNames = 2;
	else
		EkRaidAttend_SaveAttendNames = 1;
	end

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_SaveOfflineCB_Update()
	-- ----------
	-- Update the "record offline names" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_SaveOfflineCB");

	if (EkRaidAttend_SaveAttendNames == 2) then
		CB:SetChecked(1);
	else
		CB:SetChecked(0);
	end
end


-- ----------
-- "Show online names in chat"
-- ----------

function EkRaidAttend_OptionsFrame_ShowOnlineCB_OnClick()
	-- ----------
	-- Toggle the "Show online names in chat" option.
	-- ----------
	local onCB = getglobal("EkRaidAttend_OptionsFrame_ShowOnlineCB");
	local offCB = getglobal("EkRaidAttend_OptionsFrame_ShowOfflineCB");

	if ( offCB:GetChecked() ) then
		EkRaidAttend_ShowAttendNames = 2;
	else
		EkRaidAttend_ShowAttendNames = 0;
	end

	if ( onCB:GetChecked() ) then
		EkRaidAttend_ShowAttendNames = EkRaidAttend_ShowAttendNames + 1;
	end

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_ShowOnlineCB_Update()
	-- ----------
	-- Update the "Show online names in chat" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_ShowOnlineCB");

	if (EkRaidAttend_ShowAttendNames == 1 or EkRaidAttend_ShowAttendNames == 3) then
		CB:SetChecked(1);
	else
		CB:SetChecked(0);
	end
end


-- ----------
-- "Show offline names in chat"
-- ----------

function EkRaidAttend_OptionsFrame_ShowOfflineCB_OnClick()
	-- ----------
	-- Toggle the "Show offline names in chat" option.
	-- ----------
	local onCB = getglobal("EkRaidAttend_OptionsFrame_ShowOnlineCB");
	local offCB = getglobal("EkRaidAttend_OptionsFrame_ShowOfflineCB");

	if ( offCB:GetChecked() ) then
		EkRaidAttend_ShowAttendNames = 2;
	else
		EkRaidAttend_ShowAttendNames = 0;
	end

	if ( onCB:GetChecked() ) then
		EkRaidAttend_ShowAttendNames = EkRaidAttend_ShowAttendNames + 1;
	end

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_ShowOfflineCB_Update()
	-- ----------
	-- Update the "Show offline names in chat" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_ShowOfflineCB");

	if (EkRaidAttend_ShowAttendNames == 2 or EkRaidAttend_ShowAttendNames == 3) then
		CB:SetChecked(1);
	else
		CB:SetChecked(0);
	end
end


-- ----------
-- "Use main character names."
-- ----------

function EkRaidAttend_OptionsFrame_MainNameUseCB_OnClick()
	-- ----------
	-- Toggle the "use main character names" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_MainNameUseCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_MainNameUse = 1;
		EkRaidAttend_RecordMainName = 1;
	else
		EkRaidAttend_MainNameUse = 0;
		EkRaidAttend_RecordMainName = 0;
	end
	EkRaidAttend_OptionsFrame_MainNameAttendCB_Update()
	EkRaidAttend_OptionsFrame_MainNameUseCB_Update()

	EkRaidAttend_GuildRosterFlag = 1;

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_MainNameUseCB_Update()
	-- ----------
	-- Update the "use main character names" checkbox.
	-- ----------
	local useCB = getglobal("EkRaidAttend_OptionsFrame_MainNameUseCB");
	local DDframe = getglobal("EkRaidAttend_OptionsFrame_MainNameNoteDropDown");
	local DDbutton = getglobal("EkRaidAttend_OptionsFrame_MainNameNoteDropDownButton");
	local startEB = getglobal("EkRaidAttend_OptionsFrame_MainNameStartEB");
	local endEB = getglobal("EkRaidAttend_OptionsFrame_MainNameEndEB");
	local attendCB = getglobal("EkRaidAttend_OptionsFrame_MainNameAttendCB");

	if (EkRaidAttend_MainNameUse == 0) then
		useCB:SetChecked(0);
--		DDbutton:Disable();
		DDframe:Hide();
		startEB:Hide();
		endEB:Hide();
		attendCB:Disable();
	else
		useCB:SetChecked(1);
--		DDbutton:Enable();
		DDframe:Show();
		startEB:Show();
		endEB:Show();
		attendCB:Enable();
	end
end

-- ----------
-- "Main name is stored in"
-- ----------

EkRaidAttend_OptionsFrame_MainNameNoteDropDown_List = { "public note", "officer note" };

function EkRaidAttend_OptionsFrame_MainNameNoteDropDown_OnLoad()
	-- ----------
	-- Load the "Main name is in" dropdown menu.
	-- ----------
	local DD = getglobal("EkRaidAttend_OptionsFrame_MainNameNoteDropDown");

	local id;
	if ( EkRaidAttend_MainNameNote ) then
		id = EkRaidAttend_MainNameNote;
	else
		id = 1;
	end

	UIDropDownMenu_Initialize(DD, EkRaidAttend_OptionsFrame_MainNameNoteDropDown_Initialize);
	UIDropDownMenu_SetWidth(110);
	EkRaidAttend_OptionsFrame_MainNameNoteDropDown_Set(id);
end

function EkRaidAttend_OptionsFrame_MainNameNoteDropDown_Initialize()
	-- ----------
	-- Initialize the "Main name is in" dropdown menu.
	-- ----------
	local info;
	for key, val in EkRaidAttend_OptionsFrame_MainNameNoteDropDown_List do
		info = {};
		info.text = val;
		info.func = EkRaidAttend_OptionsFrame_MainNameNoteDropDown_OnClick;
		UIDropDownMenu_AddButton(info);
	end
end

function EkRaidAttend_OptionsFrame_MainNameNoteDropDown_Update()
	-- ----------
	-- Update the "Main name is in" dropdown menu.
	-- ----------
	EkRaidAttend_OptionsFrame_MainNameNoteDropDown_Set(EkRaidAttend_MainNameNote);
end

function EkRaidAttend_OptionsFrame_MainNameNoteDropDown_OnClick()
	-- ----------
	-- User has selected an item from the "Main name is stored in" dropdown menu.
	-- ----------
	EkRaidAttend_MainNameNote = this:GetID();
	EkRaidAttend_OptionsFrame_MainNameNoteDropDown_Set(this:GetID());

	EkRaidAttend_GuildRosterFlag = 1;

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_MainNameNoteDropDown_Set(id)
	-- ----------
	-- Set the current value of the "Main name is in" dropdown menu.
	-- ----------
	local DD = getglobal("EkRaidAttend_OptionsFrame_MainNameNoteDropDown");
	UIDropDownMenu_SetSelectedID(DD, id);
	UIDropDownMenu_SetText(EkRaidAttend_OptionsFrame_MainNameNoteDropDown_List[id], DD);
end

-- ----------
-- "Main name starts with"
-- ----------

function EkRaidAttend_OptionsFrame_MainNameStartEB_EditStart()
	-- ----------
	-- Start editing the character(s) that start the main name.
	-- ----------
	local EB = getglobal("EkRaidAttend_OptionsFrame_MainNameStartEB");

	if ( EB.editing ) then
		return;
	end

	EB.editing = 1;
	EB:HighlightText();
end

function EkRaidAttend_OptionsFrame_MainNameStartEB_EditStop(cancel)
	-- ----------
	-- User has stopped editing the character(s) that start the main name.
	-- ----------
	local EB = getglobal("EkRaidAttend_OptionsFrame_MainNameStartEB");

	if ( not EB.editing ) then
		return;
	end

	local value = EB:GetText();

	EB.editing = nil;
	EB:HighlightText(0, 0);

	if ( not cancel ) then
		EkRaidAttend_MainNameStart = value;
		EkRaidAttend_GuildRosterFlag = 1;
	else
		EkRaidAttend_OptionsFrame_MainNameStartEB_Update();
	end
end

function EkRaidAttend_OptionsFrame_MainNameStartEB_Update()
	-- ----------
	-- Update the character(s) that start the main name.
	-- ----------
	local EB = getglobal("EkRaidAttend_OptionsFrame_MainNameStartEB");

	if ( not EB.editing ) then
		EB:SetText(EkRaidAttend_MainNameStart);
	end
end

function EkRaidAttend_OptionsFrame_MainNameStartEB_OnTab(eb)
	eb:ClearFocus();
	if (not IsShiftKeyDown()) then
		EkRaidAttend_OptionsFrame_MainNameEndEB:SetFocus();
	end
end

-- ----------
-- "Main name ends with"
-- ----------

function EkRaidAttend_OptionsFrame_MainNameEndEB_EditStart()
	-- ----------
	-- Start editing the character(s) that end the main name.
	-- ----------
	local EB = getglobal("EkRaidAttend_OptionsFrame_MainNameEndEB");

	if ( EB.editing ) then
		return;
	end

	EB.editing = 1;
	EB:HighlightText();
end

function EkRaidAttend_OptionsFrame_MainNameEndEB_EditStop(cancel)
	-- ----------
	-- User has stopped editing the character(s) that end the main name.
	-- ----------
	local EB = getglobal("EkRaidAttend_OptionsFrame_MainNameEndEB");

	if ( not EB.editing ) then
		return;
	end

	local value = EB:GetText();

	EB.editing = nil;
	EB:HighlightText(0, 0);

	if ( not cancel ) then
		EkRaidAttend_MainNameEnd = value;
		EkRaidAttend_GuildRosterFlag = 1;
	else
		EkRaidAttend_OptionsFrame_MainNameEndEB_Update();
	end
end

function EkRaidAttend_OptionsFrame_MainNameEndEB_Update()
	-- ----------
	-- Update the character(s) that end the main name.
	-- ----------
	local EB = getglobal("EkRaidAttend_OptionsFrame_MainNameEndEB");

	if ( not EB.editing ) then
		EB:SetText(EkRaidAttend_MainNameEnd);
	end
end

function EkRaidAttend_OptionsFrame_MainNameEndEB_OnTab(eb)
	eb:ClearFocus();
	if (IsShiftKeyDown()) then
		EkRaidAttend_OptionsFrame_MainNameStartEB:SetFocus();
	end
end

-- ----------
-- "Record attendance using main character names."
-- ----------

function EkRaidAttend_OptionsFrame_MainNameAttendCB_OnClick()
	-- ----------
	-- Toggle the "record using main names" option.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_MainNameAttendCB");

	if ( CB:GetChecked() ) then
		EkRaidAttend_RecordMainName = 1;
	else
		EkRaidAttend_RecordMainName = 0;
	end
	EkRaidAttend_OptionsFrame_MainNameAttendCB_Update()

	EkRaidAttend_OptionsFrame_ClearFocus();
end

function EkRaidAttend_OptionsFrame_MainNameAttendCB_Update()
	-- ----------
	-- Update the "record using main names" checkbox.
	-- ----------
	local CB = getglobal("EkRaidAttend_OptionsFrame_MainNameAttendCB");

	if (EkRaidAttend_RecordMainName == 0) then
		CB:SetChecked(0);
	else
		CB:SetChecked(1);
	end
end

-- ----------
-- "Boss list"
-- ----------

EkRaidAttend_BossIndexes = {};

-- Referred to in XML and the ...BossList_Update() routine below.
EkRaidAttend_OptionsFrame_BossList_BossHeight = 26;

function EkRaidAttend_OptionsFrame_BossList_Update()
	-- ----------
	-- Update the boss list
	-- ----------
	local allName = "EkRaidAttend_OptionsFrame_BossList_HeaderAll";
	local detailName = "EkRaidAttend_OptionsFrame_BossList_Detail";
	local headerName = "EkRaidAttend_OptionsFrame_BossList_Header";
	local scrollFrame = EkRaidAttend_OptionsFrame_BossList_ScrollFrame;
	local numDisplayed = 13;
	local numBosses = getn(EkRaidAttend_BossIndexes);
	local bossOffset = FauxScrollFrame_GetOffset(scrollFrame);
	local bosses = EkRaidAttend_Bosses;
	local index, bossIndex, bossDetail, bossHeader;
	local name, collapsed;
	local checkbox;
	local boss;
	local count;

	bossHeader = getglobal(allName);
	if (numBosses == getn(bosses)) then
		-- All are expanded.
		bossHeader:SetNormalTexture("Interface\\Buttons\\UI-MinusButton-Up"); 
		bossHeader:SetText("Collapse all");
		bossHeader.index = 0;
		bossHeader.bossIndex = 0;
		bossHeader:Show();
	else
		-- Some are expanded.
		bossHeader:SetNormalTexture("Interface\\Buttons\\UI-PlusButton-Up");
		bossHeader:SetText("Expand all");
		bossHeader.index = 0;
		bossHeader.bossIndex = 0;
		bossHeader:Show();
	end

	if (bossOffset > 0 and numBosses <= numDisplayed) then
		local scrollBar = getglobal(scrollFrame:GetName().."ScrollBar");
		scrollBar:SetValue(0);
		FauxScrollFrame_SetOffset(scrollFrame, 0);
		bossOffset = 0;
	end

	-- Update scroll frame
	FauxScrollFrame_Update(scrollFrame, numBosses, numDisplayed, EkRaidAttend_OptionsFrame_BossList_BossHeight)

	local scrollBar = getglobal(scrollFrame:GetName().."ScrollBar");
	scrollBar:SetValue(scrollBar:GetValue());

	for i=1, numDisplayed do
		bossDetail = getglobal(detailName .. i);
		bossHeader = getglobal(headerName .. i);

		index = bossOffset + i;
		if ( index <= numBosses ) then

			bossIndex = EkRaidAttend_BossIndexes[index];
			boss = bosses[bossIndex];

			name = boss["name"];

			if (boss["header"] == 1) then
				-- Count number of bosses under this header, and how many are enabled.
				local blen = getn(bosses);
				local b = bossIndex + 1;
				local t = 0;
				local e = 0;
				while (b <= blen) do
					if (bosses[b]["header"] == 1) then
						break;
					end
					if (bosses[b]["enabled"] == 1) then
						e = e + 1;
					end
					t = t + 1;
					b = b + 1;
				end
					
				collapsed = boss["collapsed"];
				bossHeader:SetText(name .. " (" .. e .. "/" .. t .. ")");
				if ( collapsed ) then
					bossHeader:SetNormalTexture("Interface\\Buttons\\UI-PlusButton-Up");
				else
					bossHeader:SetNormalTexture("Interface\\Buttons\\UI-MinusButton-Up"); 
				end
				bossHeader.index = index;
				bossHeader.bossIndex = bossIndex;

				bossDetail:Hide();
				bossHeader:Show();
			else
				getglobal(detailName .. i .. "BossName"):SetText(name);

				checkbox = getglobal(detailName .. i .. "BossCheckButton");
				checkbox:SetChecked(boss["enabled"]);
				checkbox:Enable();

				bossDetail.index = index;
				bossDetail.bossIndex = bossIndex;

				bossDetail:Show();
				bossHeader:Hide();
			end
		else
			bossHeader:Hide();
			bossDetail:Hide();
		end
	end
end

function EkRaidAttend_OptionsFrame_BossList_BossCheckButton_OnClick()
	-- ----------
	-- User clicked on a boss list detail check box.
	-- ----------
	local config = EkRaidAttend_BossConfig;
	local bosses = EkRaidAttend_Bosses;
	local bossDetail = this:GetParent();
	local bossIndex = bossDetail.bossIndex;
	local boss = bosses[bossIndex];
	local name = boss["name"];

	if (not config[name]) then
		config[name] = {};
	end
	if (this:GetChecked()) then
		boss["enabled"] = 1;
		config[name]["enabled"] = 1;
	else
		boss["enabled"] = 0;
		config[name]["enabled"] = 0;
	end

	-- Update the display.
	EkRaidAttend_OptionsFrame_BossList_Update();
end

function EkRaidAttend_OptionsFrame_BossList_BossHeader_OnClick()
	-- ----------
	-- User clicked on a boss list header.
	-- ----------
	local config = EkRaidAttend_BossConfig;
	local bosses = EkRaidAttend_Bosses;
	local bossHeader = this;
	local bossIndex = bossHeader.bossIndex;
	local collapsed;
	local b, blen, boss, name;

	if (bossIndex == 0) then
		-- The special "All" header.
		local numBosses = getn(EkRaidAttend_BossIndexes);
		if (numBosses == getn(EkRaidAttend_Bosses)) then
			-- All are expanded, so collapse them all.
			collapsed = 1;
		else
			-- Some are expanded, so expand them all.
			collapsed = nil;
		end

		-- Alter all items.
		blen = getn(bosses);
		for b=1, blen do
			boss = bosses[b];
			name = boss["name"];
			boss["collapsed"] = collapsed;
		end
	else
		-- Normal header.
		boss = bosses[bossIndex];
		name = boss["name"];

		if (boss["collapsed"]) then
			collapsed = nil;
		else
			collapsed = 1;
		end
		boss["collapsed"] = collapsed;

		-- Alter the detail items below this header.
		blen = getn(bosses);
		b = bossIndex + 1;
		while (b <= blen) do
			boss = bosses[b];
			if (boss["header"] == 1) then
				break;
			end
			name = boss["name"];
			boss["collapsed"] = collapsed;
			b = b + 1;
		end
	end

	EkRaidAttend_OptionsFrame_BossList_UpdateBossIndexes();

	-- Update the display.
	EkRaidAttend_OptionsFrame_BossList_Update();
end

function EkRaidAttend_OptionsFrame_BossList_UpdateBossIndexes()
	-- ----------
	-- Update boss indexes array.
	-- ----------
	local bosses = EkRaidAttend_Bosses;
	local count, boss;

	EkRaidAttend_BossIndexes = {};

	count = 0;
	for b=1, getn(bosses) do
		boss = bosses[b];
		if (boss["collapsed"] == nil or boss["header"] == 1) then
			table.insert(EkRaidAttend_BossIndexes, b);
			count = count + 1;
		end
	end

	return count;
end

function EkRaidAttend_OptionsFrame_BossList_Config()
	-- ----------
	-- Configure boss settings based on saved user config.
	-- ----------
	local bosses = EkRaidAttend_Bosses;
	local config = EkRaidAttend_BossConfig;
	local boss, name;

	for b=1, getn(bosses) do
		boss = bosses[b];
		name = boss["name"];

		-- Start out with all headings collapsed.
		boss["collapsed"] = 1;

		if (boss["header"] == 1) then
			-- Headers are always enabled.
			boss["enabled"] = 1;
		else
			if (config[name]) then
				-- Get user configuration.
				boss["enabled"] = config[name]["enabled"];
			else
				-- Default to the value assigned in the hard coded table.
				-- If key is missing, then default to enabled mode.
				if (not boss["enabled"]) then
					boss["enabled"] = 1;
				end
			end
		end
	end

	-- Remove old bosses and settings from user config table.
	for k,v in config do
		local found = nil;
		for b=1,getn(bosses) do
			boss = bosses[b];
			if (boss["name"] == k) then
				found = 1;
				break;
			end
		end
		if (not found) then
			config[k] = nil;
		end
	end

	EkRaidAttend_OptionsFrame_BossList_UpdateBossIndexes();
end

function EkRaidAttend_OptionsFrame_BossList_EnableDisableAll_OnClick(enabled)
	-- ----------
	-- Enable/disable all bosses.
	-- ----------
	local bosses = EkRaidAttend_Bosses;
	local config = EkRaidAttend_BossConfig;
	local boss, name;

	for b=1, getn(bosses) do
		boss = bosses[b];
		name = boss["name"];
		if (boss["header"] == 1) then
			boss["enabled"] = 1;
		else
			boss["enabled"] = enabled;

			if (not config[name]) then
				config[name] = {};
			end
			config[name]["enabled"] = enabled;
		end
	end

	-- Update the display.
	EkRaidAttend_OptionsFrame_BossList_Update();
end


function EkRaidAttend_BossList_Lookup(name)
	-- ----------
	-- Lookup boss name in list.
	--
	-- Returns: 1) if found, returns the EkRaidAttend_Bosses[] subscript for the boss.
	--          2) if not found, returns nil.
	-- ----------

	-- Scan the table of boss names for a match.
	local lowername = string.lower(name);
	for i=1, getn(EkRaidAttend_Bosses) do
		local boss = EkRaidAttend_Bosses[i];
		if (boss["header"] == 0) then
			if (string.lower(boss["name"]) == lowername) then
				return i;
			end
		end
	end

	return nil;
end


function EkRaidAttend_BossList_IsEnabled(name)
	-- ----------
	-- Is the specified boss enabled?
	--
	-- Returns true if enabled, false if not (or name not found).
	-- ----------
	local i = EkRaidAttend_BossList_Lookup(name);

	if (i) then
		local boss = EkRaidAttend_Bosses[i];
		if (boss["enabled"] == 1) then
			return true;
		end
	end
	return false;
end


-- *!*
-- -------------------------------------------------------------------------
-- EkRaidAttend_ListsFrame (the "Lists" tab: attendance lists)
-- -------------------------------------------------------------------------

EkRaidAttend_ListsFrame_MenuNum = 1;
EkRaidAttend_ListsFrame_Order = "time";
EkRaidAttend_ListsFrame_Ascend = nil;  -- nil=Descending, 1=Ascending
EkRaidAttend_ListsFrame_List = {};
EkRaidAttend_ListsFrame_Mode = 0;   -- 0==Lists, 1=Players, 2=Notepad
EkRaidAttend_ListsFrame_RaidsToDisplay = 15;
EkRaidAttend_ListsFrame_Height = 16;
EkRaidAttend_ListsFrame_Selected = {};

function EkRaidAttend_ListsFrame_OnShow()
	-- ----------
	-- Show the frame.
	-- ----------
	local msg;

	EkRaidAttend_ListsFrame_TitleText:SetText("Attendance lists");

	msg = getglobal("EkRaidAttend_ListsFrame_Message");
	msg:SetTextColor(1, 1, 1);

	EkRaidAttend_ListsFrame_ShowMenu();
	EkRaidAttend_ListsFrame_ListUpdate();
end

function EkRaidAttend_ListsFrame_ListInit()
	-- ----------
	-- Initialize the array to be displayed.
	-- ----------
	local index, value, count;
	local list = {};
	local rec;

	count = 0;
	for index, value in EkRaidAttend_Data do
		count = count + 1;

		rec = EkRaidAttend_ListsFrame_ListInitRec(index);
		rec["issaved"] = 1;  -- nil == not written to disk yet, 1 == has been written to disk

		list[count] = rec;
	end
	EkRaidAttend_ListsFrame_List = list;
	EkRaidAttend_ListsFrame_Sort(EkRaidAttend_ListsFrame_Order);
end

function EkRaidAttend_ListsFrame_ListInitRec(index)
	-- ----------
	-- Convert the index name into a record array.
	-- ----------
        local pos1, pos2, cName, cDate, cMMDD;

	local cLocal24, cLocalHour24;
	local cLocal12, cLocalHour12, cLocalMin, cLocalSec, cLocalAmPm;
	local nLocalHour12, nLocalMin, nLocalSec, nLocalHour24;

	local cServer24, cServerHour24;
	local cServer12, cServerHour12, cServerMin, cServerAmPm;
	local nServerHour12, nServerMin, nServerHour24;

	local nLocalYear, nLocalMonth, nLocalDay;

	local local_date, server_date;
	local local_time, server_time;

	local cComment;
	local rec;


	-- There have been 4 formats used for the date and time so far.
	-- Test for all of them for backwards compatabilty.
	-- (oldest format is listed first)
	-- 1. MM/DD HH:MMAM HH:MMAM
	-- 2. YYYY/MM/DD HH:MMAM HH:MMAM
	-- 3. YYYY/MM/DD HH:MM:SSAM HH:MMAM
	-- 4. YYYY/MM/DD HH:MM:SS HH:MM


	-- (4 digit year, 24 hour clock)
	-- YYYY/MM/DD HH:MM:SS HH:MM
        pos1, pos2, cName, cDate, cLocal24, cServer24, cComment = string.find(index, "^(.-)%s*(%d%d%d%d/%d%d/%d%d)%s*(%d%d:%d%d:%d%d)%s*(%d%d:%d%d)%s*(.*)$");

	if (not cLocal24) then
		-- (4 digit year, 12 hour clock without seconds)
		-- YYYY/MM/DD HH:MMAM HH:MMAM
	        pos1, pos2, cName, cDate, cLocal12, cServer12, cComment = string.find(index, "^(.-)%s*(%d%d%d%d/%d%d/%d%d)%s*(%d%d:%d%d%u%u)%s*(%d%d:%d%d%u%u)%s*(.*)$");

		if (cLocal12) then
			-- Fill in the missing seconds (assume 0 seconds).
			cLocal12 = strsub(cLocal12, 1, 5) .. ":00" .. strsub(cLocal12, 6);
		else
			-- (4 digit year, 12 hour clock with seconds)
			-- YYYY/MM/DD HH:MM:SSAM HH:MMAM
		        pos1, pos2, cName, cDate, cLocal12, cServer12, cComment = string.find(index, "^(.-)%s*(%d%d%d%d/%d%d/%d%d)%s*(%d%d:%d%d:%d%d%u%u)%s*(%d%d:%d%d%u%u)%s*(.*)$");
		end
	end

	if (not cDate) then
		-- (No year, 12 hour clock without seconds. This was only used during 2005.)
		-- MM/DD HH:MMAM HH:MMAM
	        pos1, pos2, cName, cDate, cLocal12, cServer12, cComment = string.find(index, "^(.-)%s*(%d%d/%d%d)%s*(%d%d:%d%d%u%u)%s*(%d%d:%d%d%u%u)%s*(.*)$");

		if (cLocal12) then
			cLocal12 = strsub(cLocal12, 1, 5) .. ":00" .. strsub(cLocal12, 6);
		end

		if (cDate) then
			cDate = "2005/" .. cDate;
		end
	end

	rec = {};
	rec["index"] = index;

	if (cName and cDate and ((cLocal12 and cServer12) or (cLocal24 and cServer24)) and cComment) then
		-- -----
		-- Break down the date.
		-- -----
		pos1, pos2, cMMDD = string.find(cDate, "^%d%d%d%d/(%d%d/%d%d)$");
		if (not cMMDD) then
			cMMDD = cDate;
		end

		nLocalYear = tonumber(string.sub(cDate, 1, 4));
		nLocalMonth = tonumber(string.sub(cDate, 6, 7));
		nLocalDay = tonumber(string.sub(cDate, 9, 10));

		-- -----
		-- Break down the time.
		-- -----
		if (cLocal24) then
			-- -----
			-- 24 hour times
			-- -----
		        pos1, pos2, cLocalHour24, cLocalMin, cLocalSec = string.find(cLocal24, "^(%d%d):(%d%d):(%d%d)$");
		        pos1, pos2, cServerHour24, cServerMin = string.find(cServer24, "^(%d%d):(%d%d)$");

			nLocalHour24 = tonumber(cLocalHour24);
			nLocalMin = tonumber(cLocalMin);
			nLocalSec = tonumber(cLocalSec);

			nServerHour24 = tonumber(cServerHour24);
			nServerMin = tonumber(cServerMin);
		else
			-- -----
			-- 12 hour times
			-- -----
		        pos1, pos2, cLocalHour12, cLocalMin, cLocalSec, cLocalAmPm = string.find(cLocal12, "^(%d%d):(%d%d):(%d%d)(%u%u)$");
		        pos1, pos2, cServerHour12, cServerMin, cServerAmPm = string.find(cServer12, "^(%d%d):(%d%d)(%u%u)$");

			nLocalHour12 = tonumber(cLocalHour12);
			nLocalMin = tonumber(cLocalMin);
			nLocalSec = tonumber(cLocalSec);

			nLocalHour24 = nLocalHour12;
			if (cLocalAmPm == "PM") then
				if (nLocalHour12 <= 11) then
					nLocalHour24 = nLocalHour24 + 12;
				end
			end

			nServerHour12 = tonumber(cServerHour12);
			nServerMin = tonumber(cServerMin);

			nServerHour24 = nServerHour12;
			if (cServerAmPm == "PM") then
				if (nServerHour12 <= 11) then
					nServerHour24 = nServerHour24 + 12;
				end
			end
		end

		-- Convert local date numbers into array.
		local_date = EkRaidAttend_GetDate(nLocalYear, nLocalMonth, nLocalDay, nLocalHour24, nLocalMin, nLocalSec);

		-- Convert server date numbers into array (using local values for most of them).
		server_date = EkRaidAttend_GetDate(nLocalYear, nLocalMonth, nLocalDay, nServerHour24, nServerMin, nLocalSec);

		-- Conver date arrays into time() values.
		local_time = time(local_date);
		server_time = time(server_date);

		rec["name"] = cName;
		rec["comment"] = cComment;

		rec.local_time = local_time;
		rec.server_time = server_time;
		rec.time24 = cDate .. " " .. string.format("%02d:%02d:%02d", nLocalHour24, nLocalMin, nLocalSec);

-- (these were in use prior to version 2.4)
--		rec["date"] = cDate;
--		rec["time"] = cMMDD .. " " .. strsub(cLocal12, 1, 5) .. " " .. strsub(cLocal12, 9);
--		rec["mmdd"] = cMMDD;
--		rec["local12"] = cLocal12;
--		rec["local24"] = string.format("%02d:%02d:%02d", nLocalHour24, nLocalMin, nLocalSec);
--		rec["server12"] = cServer12;
--		rec["server24"] = string.format("%02d:%02d", nServerHour24, nServerMin);
	else
		rec["line"] = true;
		rec["name"] = index;
		rec["comment"] = "";

		rec.local_time = time();
		rec.server_time = EkRaidAttend_GetGameTime();
		rec.time24 = "";

-- (these were in use prior to version 2.4)
--		rec["date"] = "";
--		rec["time"] = "";
--		rec["mmdd"] = "";
--		rec["local12"] = "";
--		rec["local24"] = "":
--		rec["server12"] = "";
--		rec["server24"] = "";
	end

	return rec;
end

function EkRaidAttend_ListsFrame_UnsavedCount()
	-- ----------
	-- Returns number of unsaved attendance lists.
	-- ----------
	local list = EkRaidAttend_ListsFrame_List;
	local len, count;

	len = getn(list);
	count = 0;
	for i=1, len do
		rec = list[i];
		if (not rec["issaved"]) then
			count = count + 1;
		end
	end

	return count;
end

function EkRaidAttend_ListsFrame_SelToTemp()
	-- ----------
	-- Convert current selection array (containing numeric subscripts)
	-- into a temporary selection array (containing index strings).
	-- ----------
	local list = EkRaidAttend_ListsFrame_List;
	local sel = EkRaidAttend_ListsFrame_Selected;
	local sel2;
	local sub, len;

	sel2 = {};  -- temp selection array.
	len = getn(sel);
	for i=1, len do
		sub = sel[i];
		table.insert(sel2, list[sub]["index"]);
	end

	EkRaidAttend_ListsFrame_SelectedTemp = sel2;
end

function EkRaidAttend_ListsFrame_TempToSel()
	-- ----------
	-- Convert temporary selection array (containing index strings)
	-- into a new current selection array (containing numeric subscripts).
	-- ----------
	local list = EkRaidAttend_ListsFrame_List;
	local sel = EkRaidAttend_ListsFrame_Selected;
	local sel2 = EkRaidAttend_ListsFrame_SelectedTemp;
	local sub, len, len2, count, index;

	len = getn(list);
	len2 = getn(sel2);
	sel = {};  -- start a new selection set
	if (len2 > 0) then
		count = 0;
		for i=1, len do
			index = list[i]["index"];
			-- Look up the index string in the temp selection array.
			for j=1, len2 do
				if (index == sel2[j]) then
					table.insert(sel, i);
					count = count + 1;
					break;
				end
			end
			-- Check if we've converted them all yet.
			if (count == len2) then
				break;
			end
		end
	end
	EkRaidAttend_ListsFrame_Selected = sel;
end

function EkRaidAttend_ListsFrame_Sort(sortType)
	-- ----------
	-- Sort the list of attendances.
	--
	-- Param: sortType == "name", "comment", or "time".
	-- ----------
	local list = EkRaidAttend_ListsFrame_List;
	local ch, chNum;

	EkRaidAttend_ListsFrame_SelToTemp();

	for i=1,3 do
		ch = getglobal("EkRaidAttend_ListsFrame_ColumnHeader" .. i);
		ch:SetTextColor(1.0, 1.0, 1.0);
	end

	if (sortType == "name") then
		sort(list, EkRaidAttend_ListsFrame_SortByName);
		chNum = 1;
	elseif (sortType == "comment") then
		sort(list, EkRaidAttend_ListsFrame_SortByComment);
		chNum = 3;
	else
		sortType = "time";
		sort(list, EkRaidAttend_ListsFrame_SortByTime);
		chNum = 2;
	end

	ch = getglobal("EkRaidAttend_ListsFrame_ColumnHeader" .. chNum);
	ch:SetTextColor(1.0, 0.82, 0.0);

	EkRaidAttend_ListsFrame_TempToSel();

	EkRaidAttend_ListsFrame_Order = sortType;
end

function EkRaidAttend_ListsFrame_SortByName(val1, val2)
	-- ----------
	-- Sort the list of attendances by boss/zone name.
	-- ----------
	local order, low1, low2;

	low1 = string.lower(val1["name"]);
	low2 = string.lower(val2["name"]);

	if ( low1 < low2 ) then
		order = -1;
	elseif ( low1 > low2 ) then
		order = 1;
	else
		if ( val1.local_time < val2.local_time ) then
			order = 1;
		elseif ( val1.local_time > val2.local_time ) then
			order = -1;
		else
			if ( val1.server_time < val2.server_time ) then
				order = 1;
			elseif ( val1.server_time > val2.server_time ) then
				order = -1;
			else
				low1 = string.lower(val1["comment"]);
				low2 = string.lower(val2["comment"]);

				if ( low1 < low2 ) then
					order = -1;
				elseif ( low1 > low2 ) then
					order = 1;
				else
					order = 0;
				end
			end
		end
	end

	if (EkRaidAttend_ListsFrame_Ascend) then
		if (order < 0) then
			return true;
		else
			return false;
		end
	else
		if (order > 0) then
			return true;
		else
			return false;
		end
	end
end

function EkRaidAttend_ListsFrame_SortByTime(val1, val2)
	-- ----------
	-- Sort the list of attendances by local date/time.
	-- ----------
	local order, low1, low2;

	if ( val1.local_time < val2.local_time ) then
		order = -1;
	elseif ( val1.local_time > val2.local_time ) then
		order = 1;
	else
		if ( val1.server_time < val2.server_time ) then
			order = -1;
		elseif ( val1.server_time > val2.server_time ) then
			order = 1;
		else
			low1 = string.lower(val1["name"]);
			low2 = string.lower(val2["name"]);

			if ( low1 < low2 ) then
				order = -1;
			elseif ( low1 > low2 ) then
				order = 1;
			else
				low1 = string.lower(val1["comment"]);
				low2 = string.lower(val2["comment"]);

				if ( low1 < low2 ) then
					order = -1;
				elseif ( low1 > low2 ) then
					order = 1;
				else
					order = 0;
				end
			end
		end
	end

	if (EkRaidAttend_ListsFrame_Ascend) then
		if (order < 0) then
			return true;
		else
			return false;
		end
	else
		if (order > 0) then
			return true;
		else
			return false;
		end
	end
end

function EkRaidAttend_ListsFrame_SortByComment(val1, val2)
	-- ----------
	-- Sort the list of attendances by comment.
	-- ----------
	local order, low1, low2;

	low1 = string.lower(val1["comment"]);
	low2 = string.lower(val2["comment"]);

	if ( low1 < low2 ) then
		order = -1;
	elseif ( low1 > low2 ) then
		order = 1;
	else
		if ( val1.local_time < val2.local_time ) then
			order = 1;
		elseif ( val1.local_time > val2.local_time ) then
			order = -1;
		else
			if ( val1.server_time < val2.server_time ) then
				order = 1;
			elseif ( val1.server_time > val2.server_time ) then
				order = -1;
			else
				low1 = string.lower(val1["name"]);
				low2 = string.lower(val2["name"]);
	
				if ( low1 < low2 ) then
					order = -1;
				elseif ( low1 > low2 ) then
					order = 1;
				else
					order = 0;
				end
			end
		end
	end

	if (EkRaidAttend_ListsFrame_Ascend) then
		if (order < 0) then
			return true;
		else
			return false;
		end
	else
		if (order > 0) then
			return true;
		else
			return false;
		end
	end
end

function EkRaidAttend_ListsFrame_ListUpdate()
	-- ----------
	-- Update the displayed attendances.
	-- ----------
	local cName, cTime, cComment;
	local fsLine, fsName, fsTime, fsComment;
	local button;
	local list = EkRaidAttend_ListsFrame_List;
	local rec;
	local NumRaids = getn(list);
	local RaidOffset = FauxScrollFrame_GetOffset(EkRaidAttend_ListsFrame_ListScrollFrame);
	local RaidIndex;
	local len, pos, msg;
	local sel = EkRaidAttend_ListsFrame_Selected;

	local showScrollBar = nil;
	if ( NumRaids > EkRaidAttend_ListsFrame_RaidsToDisplay ) then
		showScrollBar = 1;
	end

	msg = "Total lists = " .. NumRaids .. ".";
	if (getn(sel) > 0) then
		msg = msg .. "    Total selected = " .. getn(sel) .. ".";
	end
	EkRaidAttend_ListsFrame_Totals:SetText(msg);

	for i=1, EkRaidAttend_ListsFrame_RaidsToDisplay, 1 do
		RaidIndex = RaidOffset + i;
		button = getglobal("EkRaidAttend_ListsFrame_Button"..i);
		button.RaidIndex = RaidIndex;

		if ( showScrollBar ) then
			button:SetWidth(298);
		else
			button:SetWidth(330);
		end

		if (RaidIndex > 0 and RaidIndex <= NumRaids) then
			rec = list[RaidIndex];

			cName = rec["name"];
			cTime = date("%m/%d", rec.local_time) .. " " .. date("%I:%M %p", rec.local_time);
			cComment = rec["comment"];

			fsLine = getglobal("EkRaidAttend_ListsFrame_Button"..i.."Line");
			fsName = getglobal("EkRaidAttend_ListsFrame_Button"..i.."Name");
			fsTime = getglobal("EkRaidAttend_ListsFrame_Button"..i.."Time");
			fsComment = getglobal("EkRaidAttend_ListsFrame_Button"..i.."Comment");

			if ( rec["line"] ) then
				fsName:Hide();
				fsTime:Hide();
				fsComment:Hide();

				fsLine:SetText(cName);
				fsLine:Show();

				-- If need scrollbar resize columns
				if ( showScrollBar ) then
					fsLine:SetWidth(270);
				else
					fsLine:SetWidth(300);
				end
			else
				fsLine:Hide();

				fsName:SetText(cName);
				fsTime:SetText(cTime);
				fsComment:SetText(cComment);

				fsName:Show();
				fsTime:Show();
				fsComment:Show();

				-- If need scrollbar resize columns
				if ( showScrollBar ) then
					fsComment:SetWidth(100);
				else
					fsComment:SetWidth(120);
				end
			end

			-- Highlight the correct raid
			sel = EkRaidAttend_ListsFrame_Selected;
			len = getn(sel);
			pos = 0;
			for i=1, len, 1 do
				if ( sel[i] == RaidIndex ) then
					pos = i;
					break;
				end
			end
			if ( pos > 0 ) then
				button:LockHighlight();
			else
				button:UnlockHighlight();
			end

			button:Show();
		else
			button:Hide();
		end
	end

	-- ScrollFrame update
	FauxScrollFrame_Update(EkRaidAttend_ListsFrame_ListScrollFrame, NumRaids, EkRaidAttend_ListsFrame_RaidsToDisplay, EkRaidAttend_ListsFrame_Height);

	local scrollFrame = getglobal("EkRaidAttend_ListsFrame_ListScrollFrame");
	local scrollBar = getglobal(scrollFrame:GetName().."ScrollBar");
	scrollBar:SetValue(scrollBar:GetValue());
end

function EkRaidAttend_ListsFrame_Column_SetWidth(width, frame)
	-- ----------
	-- Set width of a column.
	-- ----------
	if ( not frame ) then
		frame = this;
	end
	frame:SetWidth(width);
	getglobal(frame:GetName().."Middle"):SetWidth(width - 9);
end

function EkRaidAttend_ListsFrame_Column_Click(sortType)
	-- ----------
	-- User clicked on a column heading.
	-- ----------
	if ( sortType ) then
		if (EkRaidAttend_ListsFrame_Ascend) then
			EkRaidAttend_ListsFrame_Ascend = nil;
		else
			EkRaidAttend_ListsFrame_Ascend = 1;
		end

		EkRaidAttend_ListsFrame_Sort(sortType);
		EkRaidAttend_ListsFrame_ListUpdate();
	end
	PlaySound("igMainMenuOptionCheckBoxOn");
end

function EkRaidAttend_ListsFrame_Button_OnDoubleClick(button)
	-- ----------
	-- User double clicked on a raid.
	-- ----------
	local sel = EkRaidAttend_ListsFrame_Selected; -- Table of selected subscripts
	local sub = this.RaidIndex; -- Subscript stored in this button

	if ( button == "LeftButton" ) then
		-- Create new selection table consisting of the attendance the user clicked on.
		sel = { sub };
		EkRaidAttend_ListsFrame_Selected = sel;

		EkRaidAttend_ListsFrame_ShowPlayers();
	end
end

function EkRaidAttend_ListsFrame_Button_OnClick(button)
	-- ----------
	-- User clicked on a raid.
	-- ----------
	local sel = EkRaidAttend_ListsFrame_Selected; -- Table of selected subscripts
	local sub = this.RaidIndex; -- Subscript stored in this button
	local sub1, sub2, sub3, pos, len;

	if ( button == "LeftButton" ) then

		if ( getn(sel) == 0 ) then
			-- Select a single item. Cancels any existing selection.
			sel = { sub };

		elseif ( IsShiftKeyDown() ) then
			-- -----
			-- Select all items between the start and end points.
			-- -----
			sub1 = sel[1];
			sub2 = sel[getn(sel)];
			if ( sub < sub1 ) then
				sub1 = sub;
			else
				sub2 = sub;
			end
			sel = {};
			len = sub2 - sub1 + 1;
			sub3 = sub1;
			for i=1, len, 1 do
				sel[i] = sub3;
				sub3 = sub3 + 1;
			end

		elseif ( IsControlKeyDown() ) then
			-- -----
			-- User control clicked an item.
			-- If already selected, unselect it,
			-- otherwise select it and add it to the selection list.
			-- -----
			len = getn(sel);
			pos = 0;
			for i=1, len, 1 do
				if ( sel[i] == sub ) then
					-- Already in the table, so remove it.
					pos = i;
					table.remove(sel, i);
					break;
				elseif ( sel[i] > sub ) then
					-- Not in table, so insert it at proper spot.
					pos = i;
					table.insert(sel, i, sub);
					break;
				end
			end
			-- If it still is not in the table, then add it to the end.
			if ( pos == 0 ) then
				table.insert(sel, sub);
			end
		else
			-- Select a single item. Cancels any existing selection.
			sel = { sub };
		end

		EkRaidAttend_ListsFrame_Selected = sel;
		EkRaidAttend_ListsFrame_ListUpdate();

		EkRaidAttend_ListsFrame_MenuNum = 1;  -- SaveFrame main menu
		EkRaidAttend_ListsFrame_ShowMenu();
	end
end

function EkRaidAttend_ListsFrame_Button_OnEnter()
	-- ----------
	-- User moved pointer over an attendance item.
	-- ----------
	local sel = EkRaidAttend_ListsFrame_Selected; -- Table of selected subscripts
	local sub = this.RaidIndex; -- Subscript stored in this button

	local xp = "LEFT";
	local yp = "BOTTOM";
	local xthis, ythis = this:GetCenter();
	local xui, yui = UIParent:GetCenter();
	if (xthis < xui) then
		xp = "RIGHT";
	end
	if (ythis < yui) then
--		yp = "TOP";
		yp = "";
		if (xthis < xui) then
			xp = "RIGHT";
		else
			xp = "LEFT";
		end
	end
	GameTooltip:SetOwner(this, "ANCHOR_" .. yp .. xp);

	local rec = EkRaidAttend_ListsFrame_List[sub];
	local text, white, msg;

	local index = rec["index"];
	local list = EkRaidAttend_Data[index];
	local numPlayers = EkRaidAttend_TableLen(list);

	white = "|c00FFFFFF";
	if ( rec["line"] ) then
	        text = white .. "Name/Comment:|r " .. rec["name"] .. "\n";
	else
		text = white .. "Zone/Boss:|r " .. rec["name"] .. "\n";
	        text = text .. white .. "Comment:|r " .. rec["comment"] .. "\n";
	        text = text .. white .. "Local Date:|r " .. date("%Y/%m/%d", rec.local_time) .. "\n";
	        text = text .. white .. "Local Time:|r " .. date("%I:%M:%S %p", rec.local_time) .. "\n";
	        text = text .. white .. "Server Time:|r " .. date("%I:%M %p", rec.server_time) .. "\n";
		if (EkRaidAttend_Test == 1) then
		        text = text .. white .. "Local24:|r " .. date("%H:%M:%S", rec.local_time) .. "\n";
		        text = text .. white .. "Server24:|r " .. date("%H:%M", rec.server_time) .. "\n";
		        text = text .. white .. "Time24:|r " .. rec.time24 .. "\n";
		end
	end
        text = text .. white .. "Players:|r " .. numPlayers .. "\n";
	if (rec["issaved"]) then
		msg = "Saved";
	else
		msg = "Not saved";
	end
        text = text .. white .. "Status:|r " .. msg .. "\n";
        text = text .. "\n";
        text = text .. white .. "Click:|r " .. "Select item." .. "\n";
        text = text .. white .. "Ctrl Click:|r " .. "Toggle select." .. "\n";
        text = text .. white .. "Shift Click:|r " .. "Select range." .. "\n";
        text = text .. white .. "Double Click:|r " .. "View players." .. "\n";

	local r,g,b, alpha;
	r = nil;
	g = nil;
	b = nil;
	alpha = nil;
	GameTooltip:SetText(text, r, g, b, alpha, 1);

	GameTooltip:Show();
end

function EkRaidAttend_ListsFrame_SelectAll()
	-- ----------
	-- Select all lists.
	-- ----------
	local sel = {};

	for i=1, getn(EkRaidAttend_ListsFrame_List) do
		sel[i] = i;
	end

	EkRaidAttend_ListsFrame_Selected = sel;
end

function EkRaidAttend_ListsFrame_ShowMenu()
	-- ----------
	-- Show current menu
	-- ----------
	local menu = EkRaidAttend_ListsFrame_MenuNum;
	local sel  = EkRaidAttend_ListsFrame_Selected;
	local list = EkRaidAttend_ListsFrame_List;

	local mbut1 = getglobal("EkRaidAttend_Frame_MenuButton1");
	local mbut2 = getglobal("EkRaidAttend_Frame_MenuButton2");
	local mbut3 = getglobal("EkRaidAttend_Frame_MenuButton3");
	local mbut4 = getglobal("EkRaidAttend_Frame_MenuButton4");
	local mbut5 = getglobal("EkRaidAttend_Frame_MenuButton5");
	local mbut6 = getglobal("EkRaidAttend_Frame_MenuButton6");
	local mbut7 = getglobal("EkRaidAttend_Frame_MenuButton7");
	local mbut8 = getglobal("EkRaidAttend_Frame_MenuButton8");
	local mbut9 = getglobal("EkRaidAttend_Frame_MenuButton9");

	local msg = getglobal("EkRaidAttend_ListsFrame_Message");

	-- -----
	-- EkRaidAttend_ListsFrame menus
	-- 
	-- 1 == Attendance list: main menu
	-- 2 == Attendance list: Yes/No to delete attendances from list.
	-- 3 == Attendance list: Yes/No to delete all attendances from list.
	-- -----

	if (menu == 1) then
		msg:SetText("");
		msg:Hide();

		mbut1:SetText("View players");
		if ( getn(sel) == 1 ) then
			mbut1:Enable();
		else
			mbut1:Disable();
		end
		mbut1:Show();

		if (getn(list) == 0 or getn(sel) ~= getn(list)) then
			mbut2:SetText("Select all");
		else
			mbut2:SetText("Unselect all");
		end
		if ( getn(list) > 0 ) then
			mbut2:Enable();
		else
			mbut2:Disable();
		end
		mbut2:Show();

		mbut3:SetText("Delete");
		if ( getn(sel) > 0 ) then
			mbut3:Enable();
		else
			mbut3:Disable();
		end
		mbut3:Show();

		mbut4:SetText("Copy");
		if ( getn(sel) > 0 ) then
			mbut4:Enable();
		else
			mbut4:Disable();
		end
		mbut4:Show();

		mbut5:SetText("Append");
		if ( getn(sel) > 0 ) then
			mbut5:Enable();
		else
			mbut5:Disable();
		end
		mbut5:Show();

		mbut6:SetText("Notepad");
		mbut6:Enable();
		mbut6:Show();

		mbut7:SetText("Intersection");
		if ( getn(sel) > 1 ) then
			mbut7:Enable();
		else
			mbut7:Disable();
		end
		mbut7:Show();

		mbut8:SetText("");
		mbut8:Disable();
		mbut8:Show();

		mbut9:SetText("");
		mbut9:Disable();
		mbut9:Show();

	elseif (menu == 2) then
		msg:SetJustifyH("CENTER");
		if ( getn(sel) > 1 ) then
			msg:SetText("Delete the " .. getn(sel) .. " selected attendances?");
		else
			msg:SetText("Delete the selected attendance?");
		end
		msg:Show();

		mbut1:SetText("Yes");
		mbut1:Enable();
		mbut1:Show();

		mbut2:Hide();

		mbut3:SetText("No");
		mbut3:Enable();
		mbut3:Show();

		mbut4:Hide();
		mbut5:Hide();
		mbut6:Hide();

		mbut7:Hide();
		mbut8:Hide();
		mbut9:Hide();

	elseif (menu == 3) then
		msg:SetJustifyH("CENTER");
		msg:SetText("Are you sure you want to delete ALL lists?");
		msg:Show();

		mbut1:SetText("Yes");
		mbut1:Enable();
		mbut1:Show();

		mbut2:Hide();

		mbut3:SetText("No");
		mbut3:Enable();
		mbut3:Show();

		mbut4:Hide();
		mbut5:Hide();
		mbut6:Hide();

		mbut7:Hide();
		mbut8:Hide();
		mbut9:Hide();
	end

	if (EkRaidAttend_Frame_MenuButton_Over) then
		EkRaidAttend_Frame_MenuButton_OnEnter(EkRaidAttend_Frame_MenuButton_Over);
	else
		EkRaidAttend_Frame_MenuButton_OnLeave();
	end
end

function EkRaidAttend_ListsFrame_MenuButton_OnClick(butNum)
	-- ----------
	-- User clicked on a menu button in the current menu.
	-- ----------
	local menu = EkRaidAttend_ListsFrame_MenuNum;
	local name = "EkRaidAttend_ListsFrame_Menu" .. menu .. "_OnClick";
	local func = getglobal(name);
	if (func) then
		func(butNum);
	end
end

function EkRaidAttend_ListsFrame_MenuButton_OnEnter(butNum)
	-- ----------
	-- Mouse is over a menu button in the current menu.
	-- ----------
	local menu = EkRaidAttend_ListsFrame_MenuNum;
	local name = "EkRaidAttend_ListsFrame_Menu" .. menu .. "_OnEnter";
	local func = getglobal(name);
	if (func) then
		func(butNum);
	end
end

function EkRaidAttend_ListsFrame_Menu1_OnClick(butNum)
	-- ----------
	-- User clicked on a menu button in menu 1.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Switch to players view.
		-- -----
		EkRaidAttend_ListsFrame_ShowPlayers();

	elseif (butNum == 2) then
		-- -----
		-- Select/Unselect all players.
		-- -----
		if (getn(EkRaidAttend_ListsFrame_Selected) ~= getn(EkRaidAttend_ListsFrame_List)) then
			-- Select all lists.
			EkRaidAttend_ListsFrame_SelectAll();
		else
			-- Unselect all lists.
			EkRaidAttend_ListsFrame_Selected = {};
		end
		EkRaidAttend_ListsFrame_ListUpdate();

		EkRaidAttend_ListsFrame_MenuNum = 1;  -- ListsFrame main menu
		EkRaidAttend_ListsFrame_ShowMenu();

	elseif (butNum == 3) then
		-- -----
		-- "Delete attendance from list" button was clicked.
		-- -----
		EkRaidAttend_ListsFrame_MenuNum = 2;  -- Yes/No menu to delete attendance from list
		EkRaidAttend_ListsFrame_ShowMenu();

	elseif (butNum == 4) then
		-- ----------
		-- Copy player names to the notepad.
		-- ----------
		EkRaidAttend_ListsFrame_UpdateNotepad(1);

	elseif (butNum == 5) then
		-- ----------
		-- Append player names to the notepad.
		-- ----------
		EkRaidAttend_ListsFrame_UpdateNotepad(2);

	elseif (butNum == 6) then
		-- ----------
		-- Open the notepad.
		-- ----------
		EkRaidAttend_GuildRoster();

		EkRaidAttend_ListsFrame_:Hide();
		EkRaidAttend_ListsFrame_Mode = 2;
		EkRaidAttend_NoteFrame_Mode = 1;
		EkRaidAttend_NoteFrame_:Show();

	elseif (butNum == 7) then
		-- ----------
		-- Copy intersection of player names to the notepad.
		-- ----------
		EkRaidAttend_ListsFrame_Intersect();

	end
end

function EkRaidAttend_ListsFrame_Menu1_OnEnter(butNum)
	-- ----------
	-- Mouse is over a menu button in menu 1.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Switch to players view.
		-- -----
		GameTooltip_AddNewbieTip("View players", 1.0, 1.0, 1.0, "Displays the players that are in the selected line's attendance.", 1);

	elseif (butNum == 2) then
		-- -----
		-- Select all attendance lists.
		-- -----
		local white;
		white = "|c00FFFFFF";
		GameTooltip_AddNewbieTip("Select/Unselect all", 1.0, 1.0, 1.0, "Selects/Unselects all attendance lists.\n\n".. white .. "To select attendances:\n\nClick:|r Select the attendance on the line you click on.\n\n" .. white .. "Control click:|r The attendance on the clicked line will be added to, or removed from, the group of selected attendances.\n\n" .. white .. "Shift click:|r Select all attendances between the clicked line and a previously selected line.\n", 1);

	elseif (butNum == 3) then
		-- -----
		-- "Delete attendance from list" button was clicked.
		-- -----
		GameTooltip_AddNewbieTip("Delete attendance", 1.0, 1.0, 1.0, "Deletes the selected attendance(s).", 1);

	elseif (butNum == 4) then
		-- -----
		-- Copy player names to the notepad.
		-- -----
		GameTooltip_AddNewbieTip("Copy to notepad", 1.0, 1.0, 1.0, "Copies the player names in the selected attendance list(s) to the notepad, replacing anything currently in the notepad.", 1);

	elseif (butNum == 5) then
		-- -----
		-- Append player names to the notepad.
		-- -----
		GameTooltip_AddNewbieTip("Append to notepad", 1.0, 1.0, 1.0, "Appends the player names in the selected attendance list(s) to the text currently in the notepad.", 1);

	elseif (butNum == 6) then
		-- -----
		-- Open the notepad.
		-- -----
		GameTooltip_AddNewbieTip("Open the notepad", 1.0, 1.0, 1.0, "Opens the notepad to show you the player names that you have copied or appended. You can use the notepad to then copy those names to the Windows clipboard.", 1);

	elseif (butNum == 7) then
		-- -----
		-- Copy player names to the notepad.
		-- -----
		GameTooltip_AddNewbieTip("Copy intersection to notepad", 1.0, 1.0, 1.0, "Copies the intersection of the player names in the selected attendance lists to the notepad, replacing anything currently in the notepad.\n\nOnly the names that appear in ALL of the selected attendance lists will be copied to the notepad.\n\nWait lists (if selected) will be combined with main attendance lists (if selected) before any names are compared.", 1);

	else
		GameTooltip:Hide();
	end
end

function EkRaidAttend_ListsFrame_Menu2_OnClick(butNum)
	-- ----------
	-- User clicked on a menu button in menu 2.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Confirm deletion of attendance from list.
		-- -----
		if (getn(EkRaidAttend_ListsFrame_Selected) == getn(EkRaidAttend_ListsFrame_List)) then
			-- User is trying to delete all attendance lists.
			EkRaidAttend_ListsFrame_MenuNum = 3;  -- "Are you sure?"
			EkRaidAttend_ListsFrame_ShowMenu();
		else
			EkRaidAttend_ListsFrame_DeleteAttendances();
			EkRaidAttend_ListsFrame_ListUpdate();

			EkRaidAttend_ListsFrame_MenuNum = 1;  -- SaveFrame main menu
			EkRaidAttend_ListsFrame_ShowMenu();
		end

	elseif (butNum == 3) then
		-- -----
		-- Deny deletion of attendance from list.
		-- -----
		EkRaidAttend_ListsFrame_MenuNum = 1;  -- SaveFrame main menu
		EkRaidAttend_ListsFrame_ShowMenu();

	end
end

function EkRaidAttend_ListsFrame_Menu2_OnEnter(butNum)
	-- ----------
	-- Mouse is over a menu button in menu 2.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Confirm deletion of attendance from list.
		-- -----
		GameTooltip_AddNewbieTip("Delete: Yes", 1.0, 1.0, 1.0, "Deletes the selected attendance(s). Click on the 'No' button if you do not want to delete them.", 1);

	elseif (butNum == 3) then
		-- -----
		-- Deny deletion of attendance from list.
		-- -----
		GameTooltip_AddNewbieTip("Delete: No", 1.0, 1.0, 1.0, "Do not delete the selected attendance(s).", 1);

	else
		GameTooltip:Hide();
	end
end

function EkRaidAttend_ListsFrame_Menu3_OnClick(butNum)
	-- ----------
	-- User clicked on a menu button in menu 3.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Confirm deletion of all attendances from list.
		-- -----
		EkRaidAttend_ListsFrame_DeleteAllAttendances();

		EkRaidAttend_ListsFrame_ListUpdate();

		EkRaidAttend_ListsFrame_MenuNum = 1;  -- SaveFrame main menu
		EkRaidAttend_ListsFrame_ShowMenu();

	elseif (butNum == 3) then
		-- -----
		-- Deny deletion of all raids from list.
		-- -----
		EkRaidAttend_ListsFrame_MenuNum = 1;  -- SaveFrame main menu
		EkRaidAttend_ListsFrame_ShowMenu();

	end
end

function EkRaidAttend_ListsFrame_Menu3_OnEnter(butNum)
	-- ----------
	-- Mouse is over a menu button in menu 3.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Confirm deletion of all attendances from list.
		-- -----
		GameTooltip_AddNewbieTip("Delete all: Yes", 1.0, 1.0, 1.0, "Deletes ALL of the attendances. Click on the 'No' button if you do not want to delete them.", 1);

	elseif (butNum == 3) then
		-- -----
		-- Deny deletion of all attendances from list.
		-- -----
		GameTooltip_AddNewbieTip("Delete all: No", 1.0, 1.0, 1.0, "Do not delete ALL of the attendance lists.", 1);

	else
		GameTooltip:Hide();
	end
end

function EkRaidAttend_ListsFrame_UpdateNotepad(mode)  -- 1==Copy, 2==Append
	-- ----------
	-- Copy or append player names to the notepad.
	-- ----------
	local name, index, names;
	local sel = EkRaidAttend_ListsFrame_Selected;
	local list = EkRaidAttend_ListsFrame_List;
	local sub, text, count, len;
	local raidindex, plist;
	local nlist;

	if (mode == 2) then
		-- Appending.
		msg = "Appended";

		-- Get the current text in the notepad.
		text = EkRaidAttend_NoteFrame_BodyEditBox:GetText();

		-- Before adding a name, ensure the last line ends with a newline character.
		len = strlen(text);
		if (len > 0) then
			if (strsub(text, len, len) ~= "\n") then
				text = text .. "\n";
			end
		end
	else
		-- Copying.
		msg = "Copied";

		-- Start out with an empty notepad.
		text = "";
	end

	-- Add the selected names
	nlist = {};
	count = 0;
	for i=1, getn(sel), 1 do
		sub = sel[i];
		raidindex = list[sub]["index"];
		plist = EkRaidAttend_Data[raidindex];

		-- Append to a temporary array so we can sort them.
		for index, value in plist do
			table.insert(nlist, index);
		end
	end

	-- Sort the names
	sort(nlist, EkRaidAttend_ListsFrame_SortTempByName);

	-- Add the names to the notepad text.
	for j=1, getn(nlist) do
		text = text .. nlist[j] .. "\n";
		count = count + 1;
	end

	if (count == 1) then
		EkRaidAttend_Print(msg .. " 1 name to the notepad.");
	else
		EkRaidAttend_Print(msg .. " " .. count .. " names to the notepad.");
	end

	EkRaidAttend_NoteFrame_BodyEditBox:SetText(text);
--	EkRaidAttend_NoteFrame_ScrollFrame:UpdateScrollChildRect();
end

function EkRaidAttend_ListsFrame_SortTempByName(val1, val2)
	-- ----------
	-- Compare two elements of temp array for the sort function
	-- ----------
	local order, low1, low2;

	low1 = string.lower(val1);
	low2 = string.lower(val2);

	if ( low1 < low2 ) then
		order = -1;
	elseif ( low1 > low2 ) then
		order = 1;
	else
		order = 0;
	end

	if (order < 0) then
		return true;
	else
		return false;
	end
end

function EkRaidAttend_ListsFrame_Intersect()
	-- ----------
	-- Go through the attendance names and create a single list
	-- of player names that exist in each one of the attendances.
	--
	-- If a name from one attendance is not in another attendance,
	-- then that name does not make the final list.
	--
	-- A main attendance list and its corresponding wait list are
	-- treated as a single list (assuming both have been selected).
	-- ----------
	local name, index, names;
	local sel = EkRaidAttend_ListsFrame_Selected;
	local list = EkRaidAttend_ListsFrame_List;
	local sub, text, count, len;
	local raidindex, plist;
	local nlist, alist, flist;
	local numAttend, nextindex, mainindex, prvsindex, pos1, pos2, numLists, curAttend;

	-- Add the selected attendance names
	alist = {};
	count = 0;
	for i=1, getn(sel), 1 do
		sub = sel[i];
		raidindex = list[sub]["index"];
		table.insert(alist, raidindex);
	end

	-- Sort the attendance names so that wait list attendance names
	-- will follow immediately after their main attendance list.
	sort(alist, EkRaidAttend_ListsFrame_SortTempByName);

	nlist = {};
	numAttend = getn(alist)
	curAttend = 1;
	numLists = 0;
	prvsindex = nil;
	while (curAttend <= numAttend) do
		raidindex = alist[curAttend];
		plist = EkRaidAttend_Data[raidindex];

		-- Add name to list and count how many attendance lists it has appeared in.
		for index, value in plist do
			if (nlist[index]) then
				nlist[index] = nlist[index] + 1;
			else
				nlist[index] = 1;
			end
		end

		-- Extract main attendance name (if this is a wait list).
		pos1, pos2, mainindex = string.find(raidindex, "^(.-) Wait list%..*");
		if (mainindex) then
			-- ---
			-- This is a wait list.
			-- ---
			if (prvsindex) then
				-- There was a previous attendance.
				-- Is this wait list for the same attendance as the previous one?
				if (mainindex == strsub(prvsindex, 1, strlen(mainindex))) then
					-- This wait list is for the same attendance as the previous one.
					-- Don't update numLists.
				else
					-- This wait list is NOT for the same attendance as the previous one.
					numLists = numLists + 1;
				end
			else
				-- No previous attendance.
				numLists = numLists + 1;
			end
			prvsindex = raidindex;
		else
			-- ---
			-- This is not a wait list.
			-- ---
			if (prvsindex) then
				-- There was a previous attendance.
				-- Was the previous attendance list a wait list?
				pos1, pos2, mainindex = string.find(prvsindex, "^(.-) Wait list%..*");
				if (mainindex) then
					-- The previous attendance was a wait list.
					-- Is this attendance list for the same attendance as the previous one?
					if (strsub(raidindex, 1, strlen(mainindex)) == mainindex) then
						-- This attendance list is for the same attendance as the previous one.
						-- Don't update numLists.
					else
						-- This attendance list is NOT for the same attendance as the previous one.
						numLists = numLists + 1;
					end
				else
					-- Previous attendance was not a wait list. Assume it was for a different attendance.
					numLists = numLists + 1;
				end
			else
				-- No previous attendance.
				numLists = numLists + 1;
			end
			prvsindex = raidindex;
		end
		curAttend = curAttend + 1;
	end

	-- Create a final array containing the names of those people that were in all of the lists.
	-- Also create a list of those that were not in each of the lists.
	flist = {};
	glist = {};
	for index, value in nlist do
		if (value == numLists) then
			table.insert(flist, index);
		else
			table.insert(glist, index);
		end
	end

	-- Sort the names in the final list.
	sort(flist, EkRaidAttend_ListsFrame_SortTempByName);
	sort(glist, EkRaidAttend_ListsFrame_SortTempByName);


	if (getn(glist) > 0) then
		EkRaidAttend_Print("The following " .. getn(glist) .. " names were not in all of the selected attendances(" .. numLists .. "). The number in brackets is how many of the selected lists they were in.");
		local text = "";
		for j = 1, getn(glist) do
			local name = glist[j];
			if (j > 1) then
				text = text .. ", ";
			end
			text = text .. name .. "(" .. nlist[name] .. ")";
		end
		text = text .. ".";
		EkRaidAttend_Print(text);
	end


	-- Add the names to the notepad text.
	text = "";
	count = 0;
	for j=1, getn(flist) do
		text = text .. flist[j] .. "\n";
		count = count + 1;
	end

	if (count == 1) then
		EkRaidAttend_Print("Copied 1 name to the notepad.");
	else
		EkRaidAttend_Print("Copied " .. count .. " names to the notepad.");
	end

	EkRaidAttend_NoteFrame_BodyEditBox:SetText(text);
--	EkRaidAttend_NoteFrame_ScrollFrame:UpdateScrollChildRect();
end

function EkRaidAttend_ListsFrame_ShowPlayers()
	-- ----------
	-- Switch to the players frame.
	-- ----------
	local sel = EkRaidAttend_ListsFrame_Selected;
	local list = EkRaidAttend_ListsFrame_List;
	local subtitle = getglobal("EkRaidAttend_PlayersFrame_SubTitle");
	local sub;

	sub = sel[1];
	subtitle:SetText(list[sub]["index"])
	EkRaidAttend_PlayersFrame_RaidIndex = list[sub]["index"];
	EkRaidAttend_PlayersFrame_SaveIndex = sub;

	EkRaidAttend_ListsFrame_Mode = 1;

	FauxScrollFrame_SetOffset(EkRaidAttend_PlayersFrame_ListScrollFrame, 0);
	EkRaidAttend_PlayersFrame_ListScrollFrameScrollBar:SetValue(0);

	EkRaidAttend_PlayersFrame_ListInit();

	EkRaidAttend_PlayersFrame_MenuNum = 1;  -- PlayersFrame main menu
	EkRaidAttend_ListsFrame_:Hide();
	EkRaidAttend_PlayersFrame_:Show();
end

function EkRaidAttend_ListsFrame_DeleteAttendances()
	-- ----------
	-- Delete selected attendances.
	-- ----------
	local sel = EkRaidAttend_ListsFrame_Selected;
	local list = EkRaidAttend_ListsFrame_List;
	local index;
	local sub;
	local len = getn(sel);

	if (len == getn(list)) then
		EkRaidAttend_ListsFrame_DeleteAllAttendances();
		return;
	end

	for i=1, len, 1 do
		sub = sel[i];
		index = list[sub]["index"];
		EkRaidAttend_Data[index] = nil;

		if (len <= 5) then
			EkRaidAttend_Print("Deleted attendance list: " .. index);
		end
	end
	if (len > 5) then
		EkRaidAttend_Print("Deleted " .. len .. " attendance lists.");
	end

	for i=getn(sel), 1, -1 do
		sub = sel[i];

		table.remove(list, sub);
	end

	EkRaidAttend_ListsFrame_Selected = {};

end

function EkRaidAttend_ListsFrame_DeleteAllAttendances()
	-- ----------
	-- Delete all attendances.
	-- ----------
	EkRaidAttend_Data = {};
	EkRaidAttend_ListsFrame_List = {};
	EkRaidAttend_ListsFrame_Selected = {};

	EkRaidAttend_Print("All attendance lists have been deleted.");
end

-- *!*
-- -------------------------------------------------------------------------
-- EkRaidAttend_PlayersFrame (the "saved" tab: players in an attendance list)
-- -------------------------------------------------------------------------

EkRaidAttend_PlayersFrame_MenuNum = 1;
EkRaidAttend_PlayersFrame_Order = "name";
EkRaidAttend_PlayersFrame_Ascend = 1;  -- nil=Descending, 1=Ascending
EkRaidAttend_PlayersFrame_List = {};
EkRaidAttend_PlayersFrame_NumToDisplay = 15;
EkRaidAttend_PlayersFrame_Height = 16;
EkRaidAttend_PlayersFrame_Selected = {};
EkRaidAttend_PlayersFrame_RaidIndex = nil;  -- Index of raid list being viewed: EkRaidAttend_Data[]
EkRaidAttend_PlayersFrame_SaveIndex = nil;  -- Subscript of raid list being viewed: EkRaidAttend_ListsFrame_List[]

function EkRaidAttend_PlayersFrame_OnShow()
	-- ----------
	-- Show players frame.
	-- ----------
	local msg;

	EkRaidAttend_PlayersFrame_TitleText:SetText("Players in attendance list");

	msg = getglobal("EkRaidAttend_PlayersFrame_Message");
	msg:SetTextColor(1, 1, 1);

	EkRaidAttend_PlayersFrame_ShowMenu();
	EkRaidAttend_PlayersFrame_ListUpdate();
end

function EkRaidAttend_PlayersFrame_ListInit()
	-- ----------
	-- Initialize the array to be displayed.
	-- ----------
	local raidindex = EkRaidAttend_PlayersFrame_RaidIndex;
	local index, value, count;
	local list = {};
	local plist = EkRaidAttend_Data[raidindex];
	local rec;

	EkRaidAttend_PlayersFrame_Selected = {};

	count = 0;
	for index, value in plist do
		count = count + 1;

		rec = EkRaidAttend_PlayersFrame_ListInitRec(index, value);

		list[count] = rec;
	end

	EkRaidAttend_PlayersFrame_List = list;
	EkRaidAttend_PlayersFrame_Sort(EkRaidAttend_PlayersFrame_Order);
end

function EkRaidAttend_PlayersFrame_ListInitRec(index, status)
	-- ----------
	-- Convert the index name into a record array.
	-- ----------
	local rec;
	local cstatus;
	local pos1, pos2, val1, val2, val3;
	local nstatus, cstatus, value, name2;

	rec = {};

	rec["index"] = index;
	rec["name"] = index;  -- 'recorded as' name

	if (type(status) == "string") then
		-- There have been four string formats used so far.
		-- Format 1 is widely in use, and will continue to be used.
		-- Format 2 was only used by me during testing, and should no longer be used.
		-- Format 3 will be used starting with the release version of EkRaidAttend 2.0.
		-- Format 4 will be used starting with the release version of EkRaidAttend 2.0.
		--
		-- 1) nValue1
		-- 2) nValue1cValue2
		-- 3) nValue1<separator>Value2
		-- 4) nValue1<separator>Value2<separator>Value3

		-- Check for the 3 value format
		pos1, pos2, val1, val2, val3 = string.find(status, "^(%d+)" .. EkRaidAttend_StatusSep .. "(.-)" .. EkRaidAttend_StatusSep .. "(.+)$");
		if (not (val1 and val2 and val3)) then
			-- There are two possible 2-value formats.
			val3 = nil;
			pos1, pos2, val1, val2 = string.find(status, "^(%d+)" .. EkRaidAttend_StatusSep .. "(.+)$");
			if (not (val1 and val2)) then
				pos1, pos2, val1, val2 = string.find(status, "^(%d+)(.+)$");
				if (not (val1 and val2)) then
					val2 = nil;
					val1 = nil;
				end
			end
		end
	else
		-- Status value is a number.
		val1 = "" .. status;
		val2 = nil;
		val3 = nil;
	end

	-- Establish status number.
	if (not val1) then
		nstatus = EkRaidAttend_PlayerStatus_UNKNOWN;
	else
		nstatus = tonumber(val1);
	end

	rec["status"] = status;
	rec["nstatus"] = nstatus;

	value = nil;
	name2 = index;  -- Default to 'recorded as' name.

	-- cstatus is used for sorting and is displayed in the list.
	if (nstatus == EkRaidAttend_PlayerStatus_OFFLINE) then
		-- -----
		-- Player was offline
		-- -----
		-- 1 or 2 value format.
		-- 1=status, 2='played as' name
		if (val2) then
			name2 = val2;
		end
		cstatus = "Offline";

	elseif (nstatus == EkRaidAttend_PlayerStatus_ONLINE) then
		-- -----
		-- Player was online
		-- -----
		-- 1 or 2 value format.
		-- 1=status, 2='played as' name
		if (val2) then
			name2 = val2;
		end
		cstatus = "Online";

	elseif (nstatus == EkRaidAttend_PlayerStatus_ADDED) then
		-- -----
		-- Player was added
		-- -----
		-- 1 value format.
		-- 1=status
		cstatus = "Added";

	elseif (nstatus == EkRaidAttend_PlayerStatus_WAITLIST) then
		-- -----
		-- Player was on the wait list.
		-- -----
		-- 1 or 2 value format.
		-- 1=status, 2='played as' name
		if (val2) then
			name2 = val2;
		end
		cstatus = "Wait list";

	elseif (nstatus == EkRaidAttend_PlayerStatus_RESIST) then
		-- -----
		-- Resist check.
		-- -----
		-- 2, or 3 value format.
		-- 1=status, 2=number, 3='played as' name
		if (val2) then
			value = tonumber(val2);
		else
			value = 0;
		end
		if (val3) then
			name2 = val3;
		end
		cstatus = "" .. value;

	elseif (nstatus == EkRaidAttend_PlayerStatus_ITEM) then
		-- -----
		-- Item check.
		-- -----
		-- 2, or 3 value format.
		-- 1=status, 2=number, 3='played as' name
		if (val2) then
			value = tonumber(val2);
		else
			value = 0;
		end
		if (val3) then
			name2 = val3;
		end
		cstatus = "" .. value;

	elseif (nstatus == EkRaidAttend_PlayerStatus_DURABILITY) then
		-- -----
		-- Durability check.
		-- -----
		-- 2, or 3 value format.
		-- 1=status, 2=number, 3='played as' name
		if (val2) then
			value = tonumber(val2);
		else
			value = 0;
		end
		if (val3) then
			name2 = val3;
		end
		cstatus = "" .. value;
	else
		cstatus = "Unknown";
	end

	rec["cstatus"] = cstatus;
	rec["name2"] = name2;
	rec["value"] = value;  -- May be nil

	return rec;
end

function EkRaidAttend_PlayersFrame_SelToTemp()
	-- ----------
	-- Convert current selection array (containing numeric subscripts)
	-- into a temporary selection array (containing index strings).
	-- ----------
	local list = EkRaidAttend_PlayersFrame_List;
	local sel = EkRaidAttend_PlayersFrame_Selected;
	local sel2;
	local sub, len;

	sel2 = {};  -- temp selection array.
	len = getn(sel);
	for i=1, len do
		sub = sel[i];
		table.insert(sel2, list[sub]["index"]);
	end

	EkRaidAttend_PlayersFrame_SelectedTemp = sel2;
end

function EkRaidAttend_PlayersFrame_TempToSel()
	-- ----------
	-- Convert temporary selection array (containing index strings)
	-- into a new current selection array (containing numeric subscripts).
	-- ----------
	local list = EkRaidAttend_PlayersFrame_List;
	local sel = EkRaidAttend_PlayersFrame_Selected;
	local sel2 = EkRaidAttend_PlayersFrame_SelectedTemp;
	local sub, len, len2, count, index;

	len = getn(list);
	len2 = getn(sel2);
	sel = {};  -- start a new selection set
	if (len2 > 0) then
		count = 0;
		for i=1, len do
			index = list[i]["index"];
			-- Look up the index string in the temp selection array.
			for j=1, len2 do
				if (index == sel2[j]) then
					table.insert(sel, i);
					count = count + 1;
					break;
				end
			end
			-- Check if we've converted them all yet.
			if (count == len2) then
				break;
			end
		end
	end
	EkRaidAttend_PlayersFrame_Selected = sel;
end

function  EkRaidAttend_PlayersFrame_Sort(sortType)
	-- --------
	-- Sort attendance list.
	--
	-- Param: sortType == "name", "status".
	-- --------
	local list = EkRaidAttend_PlayersFrame_List;
	local ch, chNum;

	EkRaidAttend_PlayersFrame_SelToTemp();

	for i=1,3 do
		ch = getglobal("EkRaidAttend_PlayersFrame_ColumnHeader" .. i);
		ch:SetTextColor(1.0, 1.0, 1.0);
	end

	if (sortType == "status") then
		sort(list, EkRaidAttend_PlayersFrame_SortByStatus);
		chNum = 3;
	elseif (sortType == "actual") then
		sort(list, EkRaidAttend_PlayersFrame_SortByActual);
		chNum = 2;
	else
		sortType = "name";
		sort(list, EkRaidAttend_PlayersFrame_SortByName);
		chNum = 1;
	end

	ch = getglobal("EkRaidAttend_PlayersFrame_ColumnHeader" .. chNum);
	ch:SetTextColor(1.0, 0.82, 0.0);

	EkRaidAttend_PlayersFrame_TempToSel();

	EkRaidAttend_PlayersFrame_Order = sortType;
end

function EkRaidAttend_PlayersFrame_SortByName(val1, val2)
	-- ----------
	-- Sort the list of players by recorded as name.
	-- ----------
	local order, low1, low2;

	low1 = string.lower(val1["name"]);
	low2 = string.lower(val2["name"]);

	if ( low1 < low2 ) then
		order = -1;
	elseif ( low1 > low2 ) then
		order = 1;
	else
		low1 = string.lower(val1["name2"]);
		low2 = string.lower(val2["name2"]);

		if ( low1 < low2 ) then
			order = -1;
		elseif ( low1 > low2 ) then
			order = 1;
		else
			order = 0;
		end
	end

	if (EkRaidAttend_PlayersFrame_Ascend) then
		if (order < 0) then
			return true;
		else
			return false;
		end
	else
		if (order > 0) then
			return true;
		else
			return false;
		end
	end
end

function EkRaidAttend_PlayersFrame_SortByActual(val1, val2)
	-- ----------
	-- Sort the list of players by actual played as name.
	-- ----------
	local order, low1, low2;

	low1 = string.lower(val1["name2"]);
	low2 = string.lower(val2["name2"]);

	if ( low1 < low2 ) then
		order = -1;
	elseif ( low1 > low2 ) then
		order = 1;
	else
		order = 0;
	end

	if (EkRaidAttend_PlayersFrame_Ascend) then
		if (order < 0) then
			return true;
		else
			return false;
		end
	else
		if (order > 0) then
			return true;
		else
			return false;
		end
	end
end

function EkRaidAttend_PlayersFrame_SortByStatus(val1, val2)
	-- ----------
	-- Sort the list of players by status.
	-- ----------
	local order, low1, low2;

	low1 = string.lower(val1["cstatus"]);
	low2 = string.lower(val2["cstatus"]);

	if ( low1 < low2 ) then
		order = -1;
	elseif ( low1 > low2 ) then
		order = 1;
	else
		low1 = string.lower(val1["name2"]);
		low2 = string.lower(val2["name2"]);

		if ( low1 < low2 ) then
			order = -1;
		elseif ( low1 > low2 ) then
			order = 1;
		else
			order = 0;
		end
	end

	if (EkRaidAttend_PlayersFrame_Ascend) then
		if (order < 0) then
			return true;
		else
			return false;
		end
	else
		if (order > 0) then
			return true;
		else
			return false;
		end
	end
end

function EkRaidAttend_PlayersFrame_ListUpdate()
	-- ----------
	-- Update the displayed players.
	-- ----------
	local fsName, fsStatus, fsActual;
	local button;
	local list = EkRaidAttend_PlayersFrame_List;
	local rec;
	local NumPlayers = getn(list);
	local PlayerOffset = FauxScrollFrame_GetOffset(EkRaidAttend_PlayersFrame_ListScrollFrame);
	local PlayerIndex;
	local len, pos, msg;
	local sel = EkRaidAttend_PlayersFrame_Selected;

	local showScrollBar = nil;
	if ( NumPlayers > EkRaidAttend_PlayersFrame_NumToDisplay ) then
		showScrollBar = 1;
	end

	msg = "Total players = " .. NumPlayers .. ".";
	if (getn(sel) > 0) then
		msg = msg .. "    Total selected = " .. getn(sel) .. ".";
	end
	EkRaidAttend_PlayersFrame_Totals:SetText(msg);

	for i=1, EkRaidAttend_PlayersFrame_NumToDisplay, 1 do
		PlayerIndex = PlayerOffset + i;
		button = getglobal("EkRaidAttend_PlayersFrame_Button"..i);
		button.PlayerIndex = PlayerIndex;

		if ( showScrollBar ) then
			button:SetWidth(298);
		else
			button:SetWidth(330);
		end

		if (PlayerIndex > 0 and PlayerIndex <= NumPlayers) then
			rec = list[PlayerIndex];

			fsName = getglobal("EkRaidAttend_PlayersFrame_Button"..i.."Name");
			fsName:SetText(rec["name"]);
			fsName:Show();

			if (rec["name"] ~= rec["name2"]) then
				fsName:SetTextColor(1.0, 0.82, 0.0);
			else
				fsName:SetTextColor(1.0, 1.0, 1.0);
			end

			fsActual = getglobal("EkRaidAttend_PlayersFrame_Button"..i.."Actual");
			fsActual:SetText(rec["name2"]);
			fsActual:Show();

			fsStatus = getglobal("EkRaidAttend_PlayersFrame_Button"..i.."Status");
			fsStatus:SetText(rec["cstatus"]);
			fsStatus:Show();

			-- If need scrollbar resize columns
			if ( showScrollBar ) then
				fsStatus:SetWidth(65);
			else
				fsStatus:SetWidth(85);
			end

			-- Highlight the correct raid
			len = getn(sel);
			pos = 0;
			for i=1, len, 1 do
				if ( sel[i] == PlayerIndex ) then
					pos = i;
					break;
				end
			end
			if ( pos > 0 ) then
				button:LockHighlight();
			else
				button:UnlockHighlight();
			end

			button:Show();
		else
			button:Hide();
		end
	end

	-- ScrollFrame update
	FauxScrollFrame_Update(EkRaidAttend_PlayersFrame_ListScrollFrame, NumPlayers, EkRaidAttend_PlayersFrame_NumToDisplay, EkRaidAttend_PlayersFrame_Height );

	local scrollFrame = getglobal("EkRaidAttend_PlayersFrame_ListScrollFrame");
	local scrollBar = getglobal(scrollFrame:GetName().."ScrollBar");
	scrollBar:SetValue(scrollBar:GetValue());
end

function EkRaidAttend_PlayersFrame_Column_SetWidth(width, frame)
	-- ----------
	-- Set width of a column.
	-- ----------
	if ( not frame ) then
		frame = this;
	end
	frame:SetWidth(width);
	getglobal(frame:GetName().."Middle"):SetWidth(width - 9);
end

function EkRaidAttend_PlayersFrame_Column_Click(sortType)
	-- ----------
	-- User clicked on a column heading.
	-- ----------
	if ( sortType ) then
		if (EkRaidAttend_PlayersFrame_Ascend) then
			EkRaidAttend_PlayersFrame_Ascend = nil;
		else
			EkRaidAttend_PlayersFrame_Ascend = 1;
		end

		EkRaidAttend_PlayersFrame_Sort(sortType);
		EkRaidAttend_PlayersFrame_ListUpdate();
	end
	PlaySound("igMainMenuOptionCheckBoxOn");
end

function EkRaidAttend_PlayersFrame_Button_OnDoubleClick(button)
	-- ----------
	-- User double clicked on a player.
	-- ----------
	local sel = EkRaidAttend_PlayersFrame_Selected; -- Table of selected subscripts
	local sub = this.PlayerIndex; -- Subscript stored in this button

	if ( button == "LeftButton" ) then
		-- Create new selection table consisting of the player the user clicked on.
		sel = { sub };
		EkRaidAttend_PlayersFrame_Selected = sel;

		-- Append player to the notepad.
		EkRaidAttend_PlayersFrame_UpdateNotepad(2);
	end
end

function EkRaidAttend_PlayersFrame_Button_OnClick(button)
	-- ----------
	-- User clicked on a player.
	-- ----------
	local sel = EkRaidAttend_PlayersFrame_Selected; -- Table of selected subscripts
	local sub = this.PlayerIndex; -- Subscript stored in this button
	local sub1, sub2, sub3, pos, len;

	if ( button == "LeftButton" ) then

		if ( getn(sel) == 0 ) then
			-- Select a single item. Cancels any existing selection.
			sel = { sub };

		elseif ( IsShiftKeyDown() ) then
			-- -----
			-- Select all items between the start and end points.
			-- -----
			sub1 = sel[1];
			sub2 = sel[getn(sel)];
			if ( sub < sub1 ) then
				sub1 = sub;
			else
				sub2 = sub;
			end
			sel = {};
			len = sub2 - sub1 + 1;
			sub3 = sub1;
			for i=1, len, 1 do
				sel[i] = sub3;
				sub3 = sub3 + 1;
			end

		elseif ( IsControlKeyDown() ) then
			-- -----
			-- User control clicked an item.
			-- If already selected, unselect it,
			-- otherwise select it and add it to the selection list.
			-- -----
			len = getn(sel);
			pos = 0;
			for i=1, len, 1 do
				if ( sel[i] == sub ) then
					-- Already in the table, so remove it.
					pos = i;
					table.remove(sel, i);
					break;
				elseif ( sel[i] > sub ) then
					-- Not in table, so insert it at proper spot.
					pos = i;
					table.insert(sel, i, sub);
					break;
				end
			end
			-- If it still is not in the table, then add it to the end.
			if ( pos == 0 ) then
				table.insert(sel, sub);
			end
		else
			-- Select a single item. Cancels any existing selection.
			sel = { sub };
		end

		EkRaidAttend_PlayersFrame_Selected = sel;
		EkRaidAttend_PlayersFrame_ListUpdate();

		EkRaidAttend_PlayersFrame_MenuNum = 1;  -- PlayersFrame main menu
		EkRaidAttend_PlayersFrame_ShowMenu();
	end
end

function EkRaidAttend_PlayersFrame_Button_OnEnter()
	-- ----------
	-- User moved pointer over a player item.
	-- ----------
	local sel = EkRaidAttend_PlayersFrame_Selected; -- Table of selected subscripts
	local sub = this.PlayerIndex; -- Subscript stored in this button

	local xp = "LEFT";
	local yp = "BOTTOM";
	local xthis, ythis = this:GetCenter();
	local xui, yui = UIParent:GetCenter();
	if (xthis < xui) then
		xp = "RIGHT";
	end
	if (ythis < yui) then
--		yp = "TOP";
		yp = "";
		if (xthis < xui) then
			xp = "RIGHT";
		else
			xp = "LEFT";
		end
	end
	GameTooltip:SetOwner(this, "ANCHOR_" .. yp .. xp);

	local text, white, msg;
	local status, cstatus, nstatus;

	local list = EkRaidAttend_PlayersFrame_List;
	local rec = list[sub];

	white = "|c00FFFFFF";

        text = white .. "Recorded as:|r " .. rec["name"] .. "\n";
        text = text .. white .. "Played as:|r " .. rec["name2"] .. "\n";
        text = text .. "\n";

	nstatus = rec["nstatus"];
	if (nstatus == EkRaidAttend_PlayerStatus_OFFLINE) then
		cstatus = "Player was offline.";

	elseif (nstatus == EkRaidAttend_PlayerStatus_ONLINE) then
		cstatus = "Player was online.";

	elseif (nstatus == EkRaidAttend_PlayerStatus_ADDED) then
		cstatus = "Player was manually added.";

	elseif (nstatus == EkRaidAttend_PlayerStatus_WAITLIST) then
		cstatus = "Player was on the wait list.";

	elseif (nstatus == EkRaidAttend_PlayerStatus_RESIST) then
		if (rec["value"]) then
		        text = text .. white .. "Resistance:|r " .. rec["value"] .. "\n";
		        text = text .. "\n";
		end
		cstatus = "Met or exceeded the minimum resistance. Refer to the attendance title for the specific resistance and minimum.";

	elseif (nstatus == EkRaidAttend_PlayerStatus_ITEM) then
		if (rec["value"]) then
		        text = text .. white .. "Quantity:|r " .. rec["value"] .. "\n";
		        text = text .. "\n";
		end
		cstatus = "Met or exceeded the minimum quantity. Refer to the attendance title for the specific item and minimum.";

	elseif (nstatus == EkRaidAttend_PlayerStatus_DURABILITY) then
		if (rec["value"]) then
		        text = text .. white .. "Durability:|r " .. rec["value"] .. "\n";
		        text = text .. "\n";
		end
		cstatus = "Met or exceeded the minimum durability. Refer to the attendance title for the specific durability minimum.";

	else
		cstatus = "Unknown.";
	end

	if (EkRaidAttend_Test == 1) then
	        text = text .. white .. "Status:|r " .. rec["status"] .. "\n";
	end
	if (cstatus) then
	        text = text .. white .. "Status:|r " .. cstatus .. "\n";
	end
        text = text .. "\n";
        text = text .. white .. "Click:|r " .. "Select item." .. "\n";
        text = text .. white .. "Ctrl Click:|r " .. "Toggle select." .. "\n";
        text = text .. white .. "Shift Click:|r " .. "Select range." .. "\n";
        text = text .. white .. "Double Click:|r " .. "Append." .. "\n";

	local r,g,b, alpha;
	r = nil;
	g = nil;
	b = nil;
	alpha = nil;
	GameTooltip:SetText(text, r, g, b, alpha, 1);

	GameTooltip:Show();
end

function EkRaidAttend_PlayersFrame_SelectAll()
	-- ----------
	-- Select all players.
	-- ----------
	local sel = {};

	for i=1, getn(EkRaidAttend_PlayersFrame_List) do
		sel[i] = i;
	end

	EkRaidAttend_PlayersFrame_Selected = sel;
end

function EkRaidAttend_PlayersFrame_ShowMenu()
	-- ----------
	-- Show current menu
	-- ----------
	local menu = EkRaidAttend_PlayersFrame_MenuNum;
	local sel  = EkRaidAttend_PlayersFrame_Selected;
	local list = EkRaidAttend_PlayersFrame_List;
	local sub;

	local mbut1 = getglobal("EkRaidAttend_Frame_MenuButton1");
	local mbut2 = getglobal("EkRaidAttend_Frame_MenuButton2");
	local mbut3 = getglobal("EkRaidAttend_Frame_MenuButton3");
	local mbut4 = getglobal("EkRaidAttend_Frame_MenuButton4");
	local mbut5 = getglobal("EkRaidAttend_Frame_MenuButton5");
	local mbut6 = getglobal("EkRaidAttend_Frame_MenuButton6");
	local mbut7 = getglobal("EkRaidAttend_Frame_MenuButton7");
	local mbut8 = getglobal("EkRaidAttend_Frame_MenuButton8");
	local mbut9 = getglobal("EkRaidAttend_Frame_MenuButton9");

	local msg = getglobal("EkRaidAttend_PlayersFrame_Message");
	local eb  = getglobal("EkRaidAttend_PlayersFrame_EB");

	local name;

	-- -----
	-- EkRaidAttend_PlayersFrame menus
	-- 
	-- 1 == Player list: main menu
	-- 2 == Player list: Yes/No to remove player from list.
	-- 3 == Player list: Ok/Cancel addition of player.
	-- 4 == Player list: Yes/No to remove all players from list.
	-- -----

	if (menu == 1) then
		eb:Hide();

		msg:Hide();

		mbut1:SetText("Back");
		mbut1:Enable();
		mbut1:Show();

		if (getn(list) == 0 or getn(sel) ~= getn(list)) then
			mbut2:SetText("Select all");
		else
			mbut2:SetText("Unselect all");
		end
		if ( getn(list) > 0 ) then
			mbut2:Enable();
		else
			mbut2:Disable();
		end
		mbut2:Show();

		mbut3:SetText("Remove");
		if ( getn(sel) > 0 ) then
			mbut3:Enable();
		else
			mbut3:Disable();
		end
		mbut3:Show();

		mbut4:SetText("Copy");
		if ( getn(sel) > 0 ) then
			mbut4:Enable();
		else
			mbut4:Disable();
		end
		mbut4:Show();

		mbut5:SetText("Append");
		if ( getn(sel) > 0 ) then
			mbut5:Enable();
		else
			mbut5:Disable();
		end
		mbut5:Show();

		mbut6:SetText("Notepad");
		mbut6:Enable();
		mbut6:Show();

		mbut7:SetText("");
		mbut7:Disable();
		mbut7:Show();

		mbut8:SetText("Edit");
		if ( getn(sel) == 1 ) then
			mbut8:Enable();
		else
			mbut8:Disable();
		end
		mbut8:Show();

		mbut9:SetText("Add");
		mbut9:Enable();
		mbut9:Show();

	elseif (menu == 2) then
		eb:Hide();

		msg:SetJustifyH("CENTER");
		if ( getn(sel) > 1 ) then
			msg:SetText("Remove the " .. getn(sel) .. " selected players?");
		else
			sub = sel[1];
			name = EkRaidAttend_PlayersFrame_List[sub]["name"];
			msg:SetText("Remove " .. name .. "?");
		end
		msg:Show();

		mbut1:SetText("Yes");
		mbut1:Enable();
		mbut1:Show();

		mbut2:Hide();

		mbut3:SetText("No");
		mbut3:Enable();
		mbut3:Show();

		mbut4:Hide();
		mbut5:Hide();
		mbut6:Hide();
		mbut7:Hide();
		mbut8:Hide();
		mbut9:Hide();

	elseif (menu == 3) then
		eb:SetWidth(150);
		eb:SetText("");
		eb:HighlightText();
		eb.ekmode = 0;  -- add
		eb:Show();

		msg:SetText("Player name to add:");
		msg:SetJustifyH("LEFT");
		msg:Show();

		mbut1:SetText("Ok");
		mbut1:Disable();
		mbut1:Show();

		mbut2:Hide();

		mbut3:SetText("Cancel");
		mbut3:Enable();
		mbut3:Show();

		mbut4:Hide();
		mbut5:Hide();
		mbut6:Hide();
		mbut7:Hide();
		mbut8:Hide();
		mbut9:Hide();

		eb:SetFocus();

	elseif (menu == 4) then
		msg:SetJustifyH("CENTER");
		msg:SetText("Are you sure you want to remove ALL players?");
		msg:Show();

		mbut1:SetText("Yes");
		mbut1:Enable();
		mbut1:Show();

		mbut2:Hide();

		mbut3:SetText("No");
		mbut3:Enable();
		mbut3:Show();

		mbut4:Hide();
		mbut5:Hide();
		mbut6:Hide();
		mbut7:Hide();
		mbut8:Hide();
		mbut9:Hide();

	elseif (menu == 5) then
		eb:SetWidth(150);

		sub = sel[1];
		name = list[sub]["name"];

		eb:SetText(name);
		eb:HighlightText();
		eb.ekmode = 1;  -- edit
		eb:Show();

		msg:SetText("Edit recorded name:");
		msg:SetJustifyH("LEFT");
		msg:Show();

		mbut1:SetText("Ok");
		mbut1:Enable();
		mbut1:Show();

		mbut2:Hide();

		mbut3:SetText("Cancel");
		mbut3:Enable();
		mbut3:Show();

		mbut4:Hide();
		mbut5:Hide();
		mbut6:Hide();
		mbut7:Hide();
		mbut8:Hide();
		mbut9:Hide();

		eb:SetFocus();

	end

	if (EkRaidAttend_Frame_MenuButton_Over) then
		EkRaidAttend_Frame_MenuButton_OnEnter(EkRaidAttend_Frame_MenuButton_Over);
	else
		EkRaidAttend_Frame_MenuButton_OnLeave();
	end
end

function EkRaidAttend_PlayersFrame_MenuButton_OnClick(butNum)
	-- ----------
	-- User clicked on a menu button in the current menu.
	-- ----------
	local menu = EkRaidAttend_PlayersFrame_MenuNum;
	local name = "EkRaidAttend_PlayersFrame_Menu" .. menu .. "_OnClick";
	local func = getglobal(name);
	if (func) then
		func(butNum);
	end
end

function EkRaidAttend_PlayersFrame_MenuButton_OnEnter(butNum)
	-- ----------
	-- Mouse is over a menu button in the current menu.
	-- ----------
	local menu = EkRaidAttend_PlayersFrame_MenuNum;
	local name = "EkRaidAttend_PlayersFrame_Menu" .. menu .. "_OnEnter";
	local func = getglobal(name);
	if (func) then
		func(butNum);
	end
end

function EkRaidAttend_PlayersFrame_Menu1_OnClick(butNum)
	-- ----------
	-- User clicked on a menu button in menu 1.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Switch to attendances view.
		-- -----
		EkRaidAttend_PlayersFrame_GotoListView();

	elseif (butNum == 2) then
		-- ----------
		-- Select/Unselect all players.
		-- ----------
		if (getn(EkRaidAttend_PlayersFrame_Selected) ~= getn(EkRaidAttend_PlayersFrame_List)) then
			-- Select all players.
			EkRaidAttend_PlayersFrame_SelectAll();
		else
			-- Unselect all players.
			EkRaidAttend_PlayersFrame_Selected = {};
		end
		EkRaidAttend_PlayersFrame_ListUpdate();

		EkRaidAttend_PlayersFrame_MenuNum = 1;  -- PlayersFrame main menu
		EkRaidAttend_PlayersFrame_ShowMenu();

	elseif (butNum == 3) then
		-- -----
		-- Remove player from list.
		-- -----
		EkRaidAttend_PlayersFrame_MenuNum = 2;  -- Yes/No menu to remove player from list.
		EkRaidAttend_PlayersFrame_ShowMenu();

	elseif (butNum == 4) then
		-- ----------
		-- Copy player names to the notepad.
		-- ----------
		EkRaidAttend_PlayersFrame_UpdateNotepad(1);

	elseif (butNum == 5) then
		-- ----------
		-- Append player names to the notepad.
		-- ----------
		EkRaidAttend_PlayersFrame_UpdateNotepad(2);

	elseif (butNum == 6) then
		-- ----------
		-- Open the notepad.
		-- ----------
		EkRaidAttend_GuildRoster();

		EkRaidAttend_PlayersFrame_:Hide();
		EkRaidAttend_ListsFrame_Mode = 2;
		EkRaidAttend_NoteFrame_Mode = 2;
		EkRaidAttend_NoteFrame_:Show();

	elseif (butNum == 8) then
		-- -----
		-- Edit player in the list.
		-- -----
		EkRaidAttend_PlayersFrame_MenuNum = 5;  -- Ok/cancel menu to edit player in list
		EkRaidAttend_PlayersFrame_ShowMenu();

	elseif (butNum == 9) then
		-- -----
		-- Add player to the list.
		-- -----
		EkRaidAttend_PlayersFrame_MenuNum = 3;  -- Ok/cancel menu to add player to list
		EkRaidAttend_PlayersFrame_ShowMenu();
	end
end

function EkRaidAttend_PlayersFrame_Menu1_OnEnter(butNum)
	-- ----------
	-- Mouse is over a menu button in menu 1.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Switch to attendances view.
		-- -----
		GameTooltip_AddNewbieTip("Back", 1.0, 1.0, 1.0, "Goes back to the attendance lists window.", 1);

	elseif (butNum == 2) then
		-- -----
		-- Select all players.
		-- -----
		local white;
		white = "|c00FFFFFF";
		GameTooltip_AddNewbieTip("Select/Unselect all", 1.0, 1.0, 1.0, "Selects/Unselects all players in the attendance list.\n\n".. white .. "To select players:\n\nClick:|r Select the player on the line you click on.\n\n" .. white .. "Control click:|r The player on the clicked line will be added to, or removed from, the group of selected players.\n\n" .. white .. "Shift click:|r Select all players between the clicked line and a previously selected line.\n", 1);

	elseif (butNum == 3) then
		-- -----
		-- Remove player from list.
		-- -----
		local white;
		white = "|c00FFFFFF";
		GameTooltip_AddNewbieTip("Remove player", 1.0, 1.0, 1.0, "Removes the selected player(s) from this attendance list.", 1);

	elseif (butNum == 4) then
		-- -----
		-- Copy player names to the notepad.
		-- -----
		GameTooltip_AddNewbieTip("Copy to notepad", 1.0, 1.0, 1.0, "Copies the selected player name(s) to the notepad, replacing anything currently in the notepad.", 1);

	elseif (butNum == 5) then
		-- -----
		-- Append player names to the notepad.
		-- -----
		GameTooltip_AddNewbieTip("Append to notepad", 1.0, 1.0, 1.0, "Appends the selected player name(s) to the text currently in the notepad.", 1);

	elseif (butNum == 6) then
		-- -----
		-- Open the notepad.
		-- -----
		GameTooltip_AddNewbieTip("Open the notepad", 1.0, 1.0, 1.0, "Opens the notepad to show you the player names that you have copied or appended. You can use the notepad to then copy those names to the Windows clipboard.", 1);

	elseif (butNum == 8) then
		-- -----
		-- Edit player in the list.
		-- -----
		GameTooltip_AddNewbieTip("Edit player", 1.0, 1.0, 1.0, "Change a player's name in the attendance list.", 1);

	elseif (butNum == 9) then
		-- -----
		-- Add player to the list.
		-- -----
		GameTooltip_AddNewbieTip("Add player", 1.0, 1.0, 1.0, "Adds a player to the attendance list.", 1);

	else
		GameTooltip:Hide();
	end
end

function EkRaidAttend_PlayersFrame_Menu2_OnClick(butNum)
	-- ----------
	-- User clicked on a menu button in menu 2.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Confirm deletion of player from list.
		-- -----
		if (getn(EkRaidAttend_PlayersFrame_Selected) == getn(EkRaidAttend_PlayersFrame_List)) then
			-- User is trying to remove all players.
			EkRaidAttend_PlayersFrame_MenuNum = 4;  -- "Are you sure?"
			EkRaidAttend_PlayersFrame_ShowMenu();
		else
			EkRaidAttend_PlayersFrame_RemovePlayers();

			EkRaidAttend_PlayersFrame_MenuNum = 1;  -- Player list main menu
			EkRaidAttend_PlayersFrame_ShowMenu();
		end

	elseif (butNum == 3) then
		-- -----
		-- Deny deletion of player from list.
		-- -----
		EkRaidAttend_PlayersFrame_MenuNum = 1;  -- Player list main menu
		EkRaidAttend_PlayersFrame_ShowMenu();

	end
end

function EkRaidAttend_PlayersFrame_Menu2_OnEnter(butNum)
	-- ----------
	-- Mouse is over a menu button in menu 2.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Confirm deletion of player from list.
		-- -----
		GameTooltip_AddNewbieTip("Remove: Yes", 1.0, 1.0, 1.0, "Removes the selected player(s) from this attendance list. Click on the 'No' button if you do not want to remove them.", 1);

	elseif (butNum == 3) then
		-- -----
		-- Deny deletion of player from list.
		-- -----
		GameTooltip_AddNewbieTip("Remove: No", 1.0, 1.0, 1.0, "Do not remove the player from this attendance list.", 1);

	else
		GameTooltip:Hide();
	end
end

function EkRaidAttend_PlayersFrame_Menu3_OnClick(butNum)
	-- ----------
	-- User clicked on a menu button in menu 3.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Ok addition of player.
		-- -----
		EkRaidAttend_PlayersFrame_Confirm_AddPlayer();

	elseif (butNum == 3) then
		-- -----
		-- Cancel addition of player.
		-- -----
		EkRaidAttend_PlayersFrame_MenuNum = 1;  -- Player list main menu
		EkRaidAttend_PlayersFrame_ShowMenu();

	end
end

function EkRaidAttend_PlayersFrame_Menu3_OnEnter(butNum)
	-- ----------
	-- Mouse is over a menu button in menu 3.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Ok addition of player.
		-- -----
		GameTooltip_AddNewbieTip("Add: Ok", 1.0, 1.0, 1.0, "Adds the player to this attendance list.", 1);

	elseif (butNum == 3) then
		-- -----
		-- Cancel addition of player.
		-- -----
		GameTooltip_AddNewbieTip("Add: Cancel", 1.0, 1.0, 1.0, "Do not add the player to this attendance list.", 1);

	else
		GameTooltip:Hide();
	end
end

function EkRaidAttend_PlayersFrame_Menu4_OnClick(butNum)
	-- ----------
	-- User clicked on a menu button in menu 4.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Confirm deletion of all players from list.
		-- -----
		EkRaidAttend_PlayersFrame_RemovePlayers();

		EkRaidAttend_PlayersFrame_MenuNum = 1;  -- Player list main menu
		EkRaidAttend_PlayersFrame_ShowMenu();

	elseif (butNum == 3) then
		-- -----
		-- Deny deletion of all players from list.
		-- -----
		EkRaidAttend_PlayersFrame_MenuNum = 1;  -- Player list main menu
		EkRaidAttend_PlayersFrame_ShowMenu();

	end
end

function EkRaidAttend_PlayersFrame_Menu4_OnEnter(butNum)
	-- ----------
	-- Mouse is over a menu button in menu 4.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Confirm deletion of all players from list.
		-- -----
		GameTooltip_AddNewbieTip("Remove all: Yes", 1.0, 1.0, 1.0, "Removes ALL of the players from this attendance list. Click on the 'No' button if you do not want to remove them.", 1);

	elseif (butNum == 3) then
		-- -----
		-- Deny deletion of all players from list.
		-- -----
		GameTooltip_AddNewbieTip("Remove all: No", 1.0, 1.0, 1.0, "Do not remove ALL of the players from this attendance list.", 1);

	else
		GameTooltip:Hide();
	end
end

function EkRaidAttend_PlayersFrame_Menu5_OnClick(butNum)
	-- ----------
	-- User clicked on a menu button in menu 5.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Ok edit of player.
		-- -----
		EkRaidAttend_PlayersFrame_Confirm_EditPlayer();

	elseif (butNum == 3) then
		-- -----
		-- Cancel edit of player.
		-- -----
		EkRaidAttend_PlayersFrame_MenuNum = 1;  -- Player list main menu
		EkRaidAttend_PlayersFrame_ShowMenu();

	end
end

function EkRaidAttend_PlayersFrame_Menu5_OnEnter(butNum)
	-- ----------
	-- Mouse is over a menu button in menu 5.
	-- ----------
	if (butNum == 1) then
		-- -----
		-- Ok edit of player.
		-- -----
		GameTooltip_AddNewbieTip("Edit: Ok", 1.0, 1.0, 1.0, "Changes the player's name in the attendance list.", 1);

	elseif (butNum == 3) then
		-- -----
		-- Cancel edit of player.
		-- -----
		GameTooltip_AddNewbieTip("Edit: Cancel", 1.0, 1.0, 1.0, "Do not change the player's name in this attendance list.", 1);

	else
		GameTooltip:Hide();
	end
end

function EkRaidAttend_PlayersFrame_GotoListView()
	-- -----
	-- Switch to attendance lists view.
	-- -----
	EkRaidAttend_ListsFrame_Mode = 0;  -- Attendance list
	EkRaidAttend_ListsFrame_MenuNum = 1;  -- Attendance list main menu
	EkRaidAttend_PlayersFrame_:Hide();
	EkRaidAttend_ListsFrame_:Show();
end

function EkRaidAttend_PlayersFrame_Confirm_AddPlayer()
	-- ----------
	-- Ok addition of player.
	-- ----------
	EkRaidAttend_PlayersFrame_AddPlayer();

	EkRaidAttend_PlayersFrame_MenuNum = 1;  -- Player list main menu
	EkRaidAttend_PlayersFrame_ShowMenu();
end

function EkRaidAttend_PlayersFrame_Confirm_EditPlayer()
	-- ----------
	-- Ok edit of player.
	-- ----------
	EkRaidAttend_PlayersFrame_EditPlayer();

	EkRaidAttend_PlayersFrame_MenuNum = 1;  -- Player list main menu
	EkRaidAttend_PlayersFrame_ShowMenu();
end

function EkRaidAttend_PlayersFrame_UpdateNotepad(mode)  -- 1=copy, 2=append
	-- ----------
	-- Copy or append player names to the notepad.
	-- ----------
	local name, index, names;
	local sel = EkRaidAttend_PlayersFrame_Selected;
	local list = EkRaidAttend_PlayersFrame_List;
	local sub, text, count, len;
	local msg;

	if (mode == 2) then
		-- Appending.
		msg = "Appended";

		-- Get the current text in the notepad.
		text = EkRaidAttend_NoteFrame_BodyEditBox:GetText();

		-- Before adding a name, ensure the last line ends with a newline character.
		len = strlen(text);
		if (len > 0) then
			if (strsub(text, len, len) ~= "\n") then
				text = text .. "\n";
			end
		end
	else
		-- Copying.
		msg = "Copied";

		-- Start out with an empty notepad.
		text = "";
	end

	-- Add the selected names
	count = 0;
	names = "";
	for i=1, getn(sel), 1 do
		sub = sel[i];
		index = list[sub]["index"];
		name = list[sub]["name"];
		text = text .. name .. "\n";
		if ( names ~= "" ) then
			names = names .. ", ";
		end
		names = names .. name;
		count = count + 1;
	end

	if (count == getn(list)) then
		EkRaidAttend_Print(msg .. " all " .. count .. " of the names to the notepad.");
	else
		EkRaidAttend_Print(msg .. " " .. count .. " of the " .. getn(list) .. " names to the notepad: " .. names .. ".");
	end

	EkRaidAttend_NoteFrame_BodyEditBox:SetText(text);
--	EkRaidAttend_NoteFrame_ScrollFrame:UpdateScrollChildRect();
end

function EkRaidAttend_PlayersFrame_RemovePlayers()
	-- -----
	-- Remove selected players from list.
	-- -----
	local name, index;
	local raidindex = EkRaidAttend_PlayersFrame_RaidIndex;
	local saveindex = EkRaidAttend_PlayersFrame_SaveIndex;
	local sel = EkRaidAttend_PlayersFrame_Selected;
	local list = EkRaidAttend_PlayersFrame_List;
	local sub, text, count;
	local subtitle = getglobal("EkRaidAttend_PlayersFrame_SubTitle");

	text = "";
	count = 0;

	for i=1, getn(sel), 1 do
		sub = sel[i];
		index = list[sub]["index"];
		name = list[sub]["name"];
		if ( text ~= "" ) then
			text = text .. ", ";
		end
		text = text .. name;
		EkRaidAttend_Data[raidindex][index] = nil;
		count = count + 1;
	end

	if ( count == 1 ) then
		EkRaidAttend_Print("Removed " .. text .. " from attendance list: " .. subtitle:GetText());
	else
		EkRaidAttend_Print("Removed " .. count .. " players (" .. text .. ") from attendance list: " .. subtitle:GetText());
	end

	for i=getn(sel), 1, -1 do
		sub = sel[i];
		table.remove(list, sub);
	end

	-- This list needs to be rewritten to disk now that we've removed someone.
	if (EkRaidAttend_ListsFrame_List[saveindex]["issaved"]) then
		EkRaidAttend_ListsFrame_List[saveindex]["issaved"] = nil;
	end

	EkRaidAttend_PlayersFrame_Selected = {};
	EkRaidAttend_PlayersFrame_ListUpdate();
end

function EkRaidAttend_PlayersFrame_AddPlayer()
	-- -----
	-- Add player to list.
	-- -----
	local name;
	local eb = getglobal("EkRaidAttend_PlayersFrame_EB");
	local raidindex = EkRaidAttend_PlayersFrame_RaidIndex;
	local saveindex = EkRaidAttend_PlayersFrame_SaveIndex;
	local subtitle = getglobal("EkRaidAttend_PlayersFrame_SubTitle");
	local status;

	status = EkRaidAttend_PlayerStatus_ADDED;

	name = string.upper(string.sub(eb:GetText(), 1, 1)) .. string.lower(string.sub(eb:GetText(), 2));
	EkRaidAttend_Data[raidindex][name] = status;
	EkRaidAttend_Print("Added " .. name .. " to attendance list: " .. subtitle:GetText());

	-- Add new save entry to the PlayersFrame list.
	local list = EkRaidAttend_PlayersFrame_List;
	local rec = EkRaidAttend_PlayersFrame_ListInitRec(name, status);
	table.insert(list, rec);
	EkRaidAttend_PlayersFrame_Selected = {};
	EkRaidAttend_PlayersFrame_Selected[1] = getn(list);

	-- This list needs to be rewritten to disk now that we've removed someone.
	if (EkRaidAttend_ListsFrame_List[saveindex]["issaved"]) then
		EkRaidAttend_ListsFrame_List[saveindex]["issaved"] = nil;
	end

	EkRaidAttend_PlayersFrame_Sort(EkRaidAttend_PlayersFrame_Order);
	EkRaidAttend_PlayersFrame_ListUpdate();
end

function EkRaidAttend_PlayersFrame_EditPlayer()
	-- -----
	-- Edit player in list.
	-- -----
	local name;
	local eb = getglobal("EkRaidAttend_PlayersFrame_EB");
	local raidindex = EkRaidAttend_PlayersFrame_RaidIndex;
	local saveindex = EkRaidAttend_PlayersFrame_SaveIndex;
	local subtitle = getglobal("EkRaidAttend_PlayersFrame_SubTitle");
	local newStatus, oldStatus;
	local list = EkRaidAttend_PlayersFrame_List;
	local sel = EkRaidAttend_PlayersFrame_Selected;
	local sub;

	sub = sel[1];
	oldname = list[sub]["name"];
	name = string.upper(string.sub(eb:GetText(), 1, 1)) .. string.lower(string.sub(eb:GetText(), 2));

	-- If name hasn't changed, then don't need to do anything.
	if (oldname == name) then
		return;
	end

	-- Remove old name
	oldStatus = EkRaidAttend_Data[raidindex][oldname];
	EkRaidAttend_Data[raidindex][oldname] = nil;

	-- Add new name
	newStatus = oldStatus;
	EkRaidAttend_Data[raidindex][name] = newStatus;

	EkRaidAttend_Print("Changed " .. oldname .. " to " .. name .. " in attendance list: " .. subtitle:GetText());

	-- Remove old entry from the PlayersFrame list.
	sub = sel[1];
	table.remove(list, sub);

	-- Add new save entry to the PlayersFrame list.
	local rec = EkRaidAttend_PlayersFrame_ListInitRec(name, newStatus);
	table.insert(list, rec);
	sel[1] = getn(list);

	-- This list needs to be rewritten to disk now that we've removed someone.
	if (EkRaidAttend_ListsFrame_List[saveindex]["issaved"]) then
		EkRaidAttend_ListsFrame_List[saveindex]["issaved"] = nil;
	end

	EkRaidAttend_PlayersFrame_Sort(EkRaidAttend_PlayersFrame_Order);
	EkRaidAttend_PlayersFrame_ListUpdate();
end

function EkRaidAttend_PlayersFrame_EB_EditStart()
	-- ----------
	-- Start editing the player name.
	-- ----------
	local eb = getglobal("EkRaidAttend_PlayersFrame_EB");

	if ( eb.editing ) then
		return;
	end

	eb.editing = 1;
	eb:HighlightText();
	eb:SetFocus();
end

function EkRaidAttend_PlayersFrame_EB_EditStop(cancel)
	-- ----------
	-- User has stopped editing the player name.
	-- ----------
	local eb = getglobal("EkRaidAttend_PlayersFrame_EB");
	local value;

	if ( not eb.editing ) then
		return;
	end

	value = eb:GetText();

	eb:HighlightText(0, 0);
	eb.editing = nil;

	if ( cancel ) then
		EkRaidAttend_PlayersFrame_MenuNum = 1;  -- PlayersFrame main menu
		EkRaidAttend_PlayersFrame_ShowMenu();
	end
end

function EkRaidAttend_PlayersFrame_EB_Valid()
	-- ----------
	-- Validate the player named being edited.
	-- ----------
	local eb   = getglobal("EkRaidAttend_PlayersFrame_EB");
	local text = string.lower(eb:GetText());
	local raidindex = EkRaidAttend_PlayersFrame_RaidIndex;
	local plist = EkRaidAttend_Data[raidindex];
	local result, valid, msg;
	local status = getglobal("EkRaidAttend_PlayersFrame_EBStatus");
	local list = EkRaidAttend_PlayersFrame_List;
	local sel = EkRaidAttend_PlayersFrame_Selected;
	local rec;

	result = 0;

	-- Don't allow a blank name.
	if ( EkRaidAttend_IsEmpty(text) ) then
		result = 1;  -- Name is blank.
	end

	if (result == 0) then
		-- Make sure name is not already in the list.
		for i=1,getn(list) do
			rec = list[i];
			if ( string.lower(rec["name"]) == text ) then
				if (eb.ekmode == 0) then  -- adding...
					result = 2;  -- Name already in attendance list.
					break;
				else
					if (sel[1] ~= i) then
						result = 2;  -- Name already in attendance list.
						break;
					end
				end
			end
		end
	end
	
	if (result == 0) then
		if (EkRaidAttend_IsNameInGuild(text) == 0) then
			if (IsInGuild()) then
				result = 3;  -- Name is not in guild.
			end
		end
	end

	msg = nil;
	valid = false;

	if (result == 0) then
		valid = true;
	elseif (result == 1) then
--		msg = "This name is required";
	elseif (result == 2) then
		msg = "Already in the list";
	elseif (result == 3) then
		msg = "Not in the guild";
		valid = true;
	end

	if (msg) then
		status:SetText(msg);
		status:Show();
	else
		status:Hide();
	end

	return valid;
end

function EkRaidAttend_PlayersFrame_EB_Changed()
	-- ----------
	-- The editbox contents have changd.
	-- ----------
	local mbut1 = getglobal("EkRaidAttend_Frame_MenuButton1");

	if ( EkRaidAttend_PlayersFrame_EB_Valid() ) then
		mbut1:Enable();
	else
		mbut1:Disable();
	end
end

-- *!*
-- -------------------------------------------------------------------------
-- EkRaidAttend_NoteFrame (the "lists" tab: player name notepad)
-- -------------------------------------------------------------------------

EkRaidAttend_NoteFrame_Mode = 1;  -- 1==Called from ListsFrame, 2==Called from PlayersFrame
EkRaidAttend_NoteFrame_MenuNum = 1;

function EkRaidAttend_NoteFrame_OnShow()
	-- ----------
	-- Show note frame.
	-- ----------
	EkRaidAttend_NoteFrame_ShowMenu();
	EkRaidAttend_NoteFrame_BodyEditBox:SetFocus();
end

function EkRaidAttend_NoteFrame_ShowMenu()
	-- ----------
	-- Show current menu
	-- ----------
	local mbut1 = getglobal("EkRaidAttend_Frame_MenuButton1");
	local mbut2 = getglobal("EkRaidAttend_Frame_MenuButton2");
	local mbut3 = getglobal("EkRaidAttend_Frame_MenuButton3");
	local mbut4 = getglobal("EkRaidAttend_Frame_MenuButton4");
	local mbut5 = getglobal("EkRaidAttend_Frame_MenuButton5");
	local mbut6 = getglobal("EkRaidAttend_Frame_MenuButton6");
	local mbut7 = getglobal("EkRaidAttend_Frame_MenuButton7");
	local mbut8 = getglobal("EkRaidAttend_Frame_MenuButton8");
	local mbut9 = getglobal("EkRaidAttend_Frame_MenuButton9");

	mbut1:SetText("Back");
	mbut1:Enable();
	mbut1:Show();

	mbut2:SetText("Select all");
	mbut2:Enable();
	mbut2:Show();

	mbut3:SetText("Delete all");
	mbut3:Enable();
	mbut3:Show();

	mbut4:SetText("Merge");
	mbut4:Enable();
	mbut4:Show();

	mbut5:SetText("Sort");
	mbut5:Enable();
	mbut5:Show();

	mbut6:SetText("Guild only");
	if (IsInGuild()) then
		mbut6:Enable();
	else
		mbut6:Disable();
	end
	mbut6:Show();

	mbut7:SetText("");
	mbut7:Disable();
	mbut7:Show();

	mbut8:SetText("");
	mbut8:Disable();
	mbut8:Show();

	mbut9:SetText("Main names");
	if (IsInGuild()) then
		mbut9:Enable();
	else
		mbut9:Disable();
	end
	mbut9:Show();

	if (EkRaidAttend_Frame_MenuButton_Over) then
		EkRaidAttend_Frame_MenuButton_OnEnter(EkRaidAttend_Frame_MenuButton_Over);
	else
		EkRaidAttend_Frame_MenuButton_OnLeave();
	end
end

function EkRaidAttend_NoteFrame_MenuButton_OnClick(butNum)
	-- ----------
	-- User clicked on a menu button in the current menu.
	-- ----------
	local menu = EkRaidAttend_NoteFrame_MenuNum;
	local name = "EkRaidAttend_NoteFrame_Menu" .. menu .. "_OnClick";
	local func = getglobal(name);
	if (func) then
		func(butNum);
	end
end

function EkRaidAttend_NoteFrame_MenuButton_OnEnter(butNum)
	-- ----------
	-- Mouse is over a menu button in the current menu.
	-- ----------
	local menu = EkRaidAttend_NoteFrame_MenuNum;
	local name = "EkRaidAttend_NoteFrame_Menu" .. menu .. "_OnEnter";
	local func = getglobal(name);
	if (func) then
		func(butNum);
	end
end

function EkRaidAttend_NoteFrame_Menu1_OnClick(butNum)
	-- ----------
	-- User clicked on a menu button in menu 1.
	-- ----------
	if (butNum == 1) then
		-- ----------
		-- Close the notepad and return to previous window.
		-- ----------
		EkRaidAttend_NoteFrame_Back();

	elseif (butNum == 2) then
		-- ----------
		-- Select all text.
		-- ----------
		EkRaidAttend_NoteFrame_SelectAllText()

	elseif (butNum == 3) then
		-- ----------
		-- Delete all text.
		-- ----------
		EkRaidAttend_NoteFrame_BodyEditBox:SetText("");
		EkRaidAttend_NoteFrame_BodyEditBox:HighlightText(0,0);
		EkRaidAttend_NoteFrame_BodyEditBox:SetFocus();

	elseif (butNum == 4) then
		-- Remove duplicate lines
		EkRaidAttend_NoteFrame_Merge();

	elseif (butNum == 5) then
		-- Sort text.
		EkRaidAttend_NoteFrame_Sort();

	elseif (butNum == 6) then
		-- Guild names only
		EkRaidAttend_NoteFrame_GuildOnly();

	elseif (butNum == 9) then
		-- Convert to main names.
		EkRaidAttend_NoteFrame_MainNames();
	end
end

function EkRaidAttend_NoteFrame_Menu1_OnEnter(butNum)
	-- ----------
	-- Mouse is over a menu button in menu 1.
	-- ----------
	if (butNum == 1) then
		GameTooltip_AddNewbieTip("Back", 1.0, 1.0, 1.0, "Closes the notepad and goes back to the previous window.", 1);

	elseif (butNum == 2) then
		GameTooltip_AddNewbieTip("Selects all text", 1.0, 1.0, 1.0, "Selects all of the text in the notepad.\n\nYou can also select text by holding down the left mouse button and moving the mouse, or by holding the shift key down and using the arrow keys.\n", 1);

	elseif (butNum == 3) then
		GameTooltip_AddNewbieTip("Delete all", 1.0, 1.0, 1.0, "Deletes all of the text in the notepad.", 1);

	elseif (butNum == 4) then
		GameTooltip_AddNewbieTip("Merge", 1.0, 1.0, 1.0, "Removes duplicate lines of text.", 1);

	elseif (butNum == 5) then
		GameTooltip_AddNewbieTip("Sort", 1.0, 1.0, 1.0, "Sorts the lines of text in the notepad.", 1);

	elseif (butNum == 6) then
		GameTooltip_AddNewbieTip("Guild only", 1.0, 1.0, 1.0, "Removes all lines of text which are not the names of people in the guild.", 1);

	elseif (butNum == 9) then
		GameTooltip_AddNewbieTip("Main names", 1.0, 1.0, 1.0, "Changes alternate character names to main character names. This does not affect names that are not in the guild.\n\nChanging an alternate name to a main name requires use of the [main] name format in a player's guild note.  If a player does not have a [main] name in their guild note, then they are assumed to be the main character.", 1);
	end
end

function EkRaidAttend_NoteFrame_Back()
	-- ----------
	-- Close the notepad and return to previous window.
	-- ----------
	EkRaidAttend_NoteFrame_:Hide();

	if (EkRaidAttend_NoteFrame_Mode == 2) then
		EkRaidAttend_ListsFrame_Mode = 1;
		EkRaidAttend_PlayersFrame_:Show();

		EkRaidAttend_PlayersFrame_MenuNum = 1;  -- Player list main menu
		EkRaidAttend_PlayersFrame_ShowMenu();
	else
		EkRaidAttend_ListsFrame_Mode = 0;
		EkRaidAttend_ListsFrame_:Show();

		EkRaidAttend_ListsFrame_MenuNum = 1;  -- Attendance list main menu
		EkRaidAttend_ListsFrame_ShowMenu();
	end
end

function EkRaidAttend_NoteFrame_SelectAllText()
	-- ----------
	-- Select all text in the notepad.
	-- ----------
	local len;
	len = EkRaidAttend_NoteFrame_BodyEditBox:GetNumLetters();
	EkRaidAttend_NoteFrame_BodyEditBox:HighlightText(0,len);
	EkRaidAttend_NoteFrame_BodyEditBox:SetFocus();
end

function EkRaidAttend_NoteFrame_Sort()
	-- ----------
	-- Sort the lines in the notepad.
	-- ----------
	local text, len;

	-- Get the current text in the notepad.
	text = EkRaidAttend_NoteFrame_BodyEditBox:GetText();

	len = strlen(text);
	if (len > 0) then
		-- Convert it into an array
		local aData = {};

		local pos, pos1, pos2, eot, line;

		pos = 1;
		eot = nil;
		while (not eot) do
			pos1, pos2, line = string.find(text, "(.-)\n", pos);
			if (not pos1) then
				pos1, pos2, line = string.find(text, "(.+)", pos);
				if (not pos1) then
					eot = 1;
				end
			end
			if (pos1) then
				table.insert(aData, line);
				pos = pos2 + 1;
			end
		end

		-- Sort the array
		sort(aData, function (a, b)
				if (string.lower(a) < string.lower(b)) then
					return true;
				else
					return false;
				end
			end);

		-- Convert array back into lines of text.
		text = "";
		for i=1, getn(aData) do
			text = text .. aData[i] .. "\n";
		end
	end

	EkRaidAttend_NoteFrame_BodyEditBox:SetText(text);
--	EkRaidAttend_NoteFrame_ScrollFrame:UpdateScrollChildRect();
end


function EkRaidAttend_NoteFrame_Merge()
	-- ----------
	-- Remove duplicate lines.
	-- ----------
	local text, len;

	-- Get the current text in the notepad.
	text = EkRaidAttend_NoteFrame_BodyEditBox:GetText();

	len = strlen(text);
	if (len > 0) then
		-- Convert it into an array
		local aData = {};

		local pos, pos1, pos2, eot, line;

		pos = 1;
		eot = nil;
		while (not eot) do
			pos1, pos2, line = string.find(text, "(.-)\n", pos);
			if (not pos1) then
				pos1, pos2, line = string.find(text, "(.+)", pos);
				if (not pos1) then
					eot = 1;
				end
			end
			if (pos1) then
				table.insert(aData, line);
				pos = pos2 + 1;
			end
		end

		-- Remove duplicate lines.
		local aUnique = {};
		local aDuplicate = {};
		local numDuplicates = 0;

		for i=1, getn(aData) do
			line = string.lower(aData[i]);
			local found = nil;
			for j=1, getn(aUnique) do
				if (string.lower(aUnique[j]) == line) then
					found = 1;
					break;
				end
			end
			if (not found) then
				table.insert(aUnique, aData[i]);
			else
				-- This is a duplicate line.
				found = nil;
				for j=1, getn(aDuplicate) do
					if (string.lower(aDuplicate[j][1]) == line) then
						found = j;
						break;
					end
				end
				if (not found) then
					table.insert(aDuplicate, {aData[i], 1});
				else
					-- Count how many duplicates we found.
					aDuplicate[found][2] = aDuplicate[found][2] + 1;
				end
				numDuplicates = numDuplicates + 1;
			end
		end

		-- Convert array back into lines of text.
		text = "";
		for i=1, getn(aUnique) do
			text = text .. aUnique[i] .. "\n";
		end

		-- Display which duplicate lines were removed.
		if (getn(aDuplicate) > 0) then
			EkRaidAttend_Print("Removed " .. numDuplicates .. " duplicate lines from the notepad.");
--[[
			local i = 1;
			while i <= getn(aDuplicate) do
				local text = "   ";
				local j = 1;
				while j <= 3 and i <= getn(aDuplicate) do
					if (j > 1) then
						text = text .. ", ";
					end
					text = text .. aDuplicate[i][1] .. " (" .. aDuplicate[i][2] .. ")";
					i = i + 1;
					j = j + 1;
				end
				if (i > getn(aDuplicate)) then
					text = text .. ".";
				else
					text = text .. ",";
				end
				EkRaidAttend_Print(text);
			end
]]
		else
			EkRaidAttend_Print("No duplicate lines were found.");
		end
	end

	EkRaidAttend_NoteFrame_BodyEditBox:SetText(text);
--	EkRaidAttend_NoteFrame_ScrollFrame:UpdateScrollChildRect();
end


function EkRaidAttend_NoteFrame_GuildOnly()
	-- ----------
	-- Remove names of people who are not in the guild.
	-- ----------
	if (not IsInGuild()) then
		return;
	end

	local text, len;

	-- Get the current text in the notepad.
	text = EkRaidAttend_NoteFrame_BodyEditBox:GetText();

	len = strlen(text);
	if (len > 0) then
		-- Convert it into an array
		local aData = {};
		local aRemoved = {};

		local pos, pos1, pos2, eot, line;

		pos = 1;
		eot = nil;
		while (not eot) do
			pos1, pos2, line = string.find(text, "(.-)\n", pos);
			if (not pos1) then
				pos1, pos2, line = string.find(text, "(.+)", pos);
				if (not pos1) then
					eot = 1;
				end
			end
			if (pos1) then
				local posInGuild = EkRaidAttend_IsNameInGuild(line);
				if (posInGuild > 0) then
					-- Name is in the guild.
					local guildRec = EkRaidAttend_GuildInfo[posInGuild];
					table.insert(aData, guildRec["name"]);
				else
					table.insert(aRemoved, line);
				end
				pos = pos2 + 1;
			end
		end

		-- Convert array back into lines of text.
		text = "";
		for i=1, getn(aData) do
			text = text .. aData[i] .. "\n";
		end

		-- Display the lines that were removed.
		if (getn(aRemoved) > 0) then
			local text = "Removed " .. getn(aRemoved) .. " player names that are not in the guild from the notepad: ";

			for i = 1, getn(aRemoved) do
				if (i > 1) then
					text = text .. ", ";
				end
				text = text .. aRemoved[i];
			end
			text = text .. ".";
			EkRaidAttend_Print(text);
		else
			EkRaidAttend_Print("No names were found that are not in the guild.");
		end
	end

	EkRaidAttend_NoteFrame_BodyEditBox:SetText(text);
--	EkRaidAttend_NoteFrame_ScrollFrame:UpdateScrollChildRect();
end


function EkRaidAttend_NoteFrame_MainNames()
	-- ----------
	-- Convert player names into the name of their main character (if player is in the guild).
	-- ----------
	if (not IsInGuild()) then
		return;
	end

	local text, len;

	-- Get the current text in the notepad.
	text = EkRaidAttend_NoteFrame_BodyEditBox:GetText();

	len = strlen(text);
	if (len > 0) then
		-- Convert it into an array
		local aData = {};
		local aChanged = {};

		local pos, pos1, pos2, eot, line;

		pos = 1;
		eot = nil;
		while (not eot) do
			pos1, pos2, line = string.find(text, "(.-)\n", pos);
			if (not pos1) then
				pos1, pos2, line = string.find(text, "(.+)", pos);
				if (not pos1) then
					eot = 1;
				end
			end
			if (pos1) then
				local posInGuild = EkRaidAttend_IsNameInGuild(line);
				if (posInGuild > 0) then
					-- Name is in the guild.
					local guildRec = EkRaidAttend_GuildInfo[posInGuild];
					local main = guildRec["main"];
					table.insert(aData, main);
					if (string.lower(line) ~= string.lower(main)) then
						table.insert(aChanged, {line, main});
					end
				else
					-- Preserver the original line
					table.insert(aData, line);
				end
				pos = pos2 + 1;
			end
		end

		-- Convert array back into lines of text.
		text = "";
		for i=1, getn(aData) do
			text = text .. aData[i] .. "\n";
		end

		-- Display which names were changed.
		if (getn(aChanged) > 0) then
			EkRaidAttend_Print("The following " .. getn(aChanged) .. " names were changed in the notepad:");
			for i = 1, getn(aChanged) do
				EkRaidAttend_Print(aChanged[i][1] .. " was changed to " .. aChanged[i][2]);
			end
		else
			EkRaidAttend_Print("No names were changed.");
		end
	end

	EkRaidAttend_NoteFrame_BodyEditBox:SetText(text);
--	EkRaidAttend_NoteFrame_ScrollFrame:UpdateScrollChildRect();
end


-- *!*
-- -------------------------------------------------------------------------
-- EkRaidAttend_PromptFrame
-- -------------------------------------------------------------------------

EkRaidAttend_PromptFrame_Mode = "";

function EkRaidAttend_PromptFrame_OnShow()
	-- ----------
	-- Called when prompt frame is shown.
	-- ----------
	local frame = getglobal("EkRaidAttend_PromptFrame_");
	local header = getglobal("EkRaidAttend_PromptFrame_HeaderText");
	local info = getglobal("EkRaidAttend_PromptFrame_Info");
	local timer = getglobal("EkRaidAttend_PromptFrame_Timer");
	local button1 = getglobal("EkRaidAttend_PromptFrame_Button1");
	local button2 = getglobal("EkRaidAttend_PromptFrame_Button2");
	local disableText = getglobal("EkRaidAttend_PromptFrame_DisableText");
	local disableCB = getglobal("EkRaidAttend_PromptFrame_DisableCB");
	local disableRaidText = getglobal("EkRaidAttend_PromptFrame_DisableRaidText");
	local disableRaidCB = getglobal("EkRaidAttend_PromptFrame_DisableRaidCB");

	local height = 170;

	EkRaidAttend_PromptTimer = 9999;  -- 9999 == infinite timer
	EkRaidAttend_PromptDelay = nil;

	PlaySound("UChatScrollButton");

	timer:SetText("");
	disableText:SetText("Disable this prompt.");
	disableText:Hide();
	disableCB:Hide();
	disableCB:SetChecked(0);
	if (EkRaidAttend_InRaid()) then
		disableRaidText:SetText("Do not prompt again while in this raid.");
	else
		disableRaidText:SetText("Do not prompt again until I join a raid.");
	end
	disableRaidText:Hide();
	disableRaidCB:Hide();
	disableRaidCB:SetChecked(0);

	if (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_RELOADUI_UNSAVED) then
		header:SetText("EkRaidAttend");
		info:SetText("There are unsaved attendances.\n" .. "|c00FFFFFF" .. "Do you want to reload the UI now?|r");
		button1:SetText("Reload UI");
		button2:SetText("Close");
		disableText:Show();
		disableCB:Show();
		disableRaidText:Show();
		disableRaidCB:Show();
--		EkRaidAttend_PromptTimer = 15;
		frame:SetHeight(height);
		frame:Show();

	elseif (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_TIMED_REMIND) then
		header:SetText("EkRaidAttend");
		info:SetText("You are in a raid.\n" .. "|c00FFFFFF" .. "Do you want to start the timed attendance?|r");
		button1:SetText("Start timed");
		button2:SetText("Close");
		disableText:Show();
		disableCB:Show();
		disableRaidText:Show();
		disableRaidCB:Show();
--		EkRaidAttend_PromptTimer = 15;
		frame:SetHeight(height);
		frame:Show();

	elseif (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_LOTS_OF_ATTENDANCES) then
		header:SetText("EkRaidAttend");

		info:SetText("You have " .. getn(EkRaidAttend_ListsFrame_List) .. " saved attendances.\n" .. "|c00FFFFFF" .. "Do you want to delete them all?|r");
		button1:SetText("Delete saved");
		button2:SetText("Close");

		disableRaidText:SetText("Disable all future attendance taking.");
		disableRaidText:Show();
		disableRaidCB:Show();

		disableText:SetText("Do not show this prompt again.");
		disableText:Show();
		disableCB:Show();

		frame:SetHeight(height);
		frame:Show();

	elseif (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_RELOADUI_ATTEND) then
		header:SetText("EkRaidAttend");
		info:SetText("An attendance was just taken.\n" .. "|c00FFFFFF" .. "Do you want to reload the UI now?|r");
		button1:SetText("Reload UI");
		button2:SetText("Close");
		disableText:Show();
		disableCB:Show();
		disableRaidText:Show();
		disableRaidCB:Show();
--		EkRaidAttend_PromptTimer = 15;
		frame:SetHeight(height);
		frame:Show();

	else
		EkRaidAttend_PromptTimer = 0;

	end
end

function EkRaidAttend_PromptFrame_OnHide()
	-- ----------
	-- Called when prompt frame is hidden.
	-- ----------
	local frame = getglobal("EkRaidAttend_PromptFrame_");

	EkRaidAttend_PromptTimer = nil;
	EkRaidAttend_PromptDelay = EkRaidAttend_DefPromptDelay;
	EkRaidAttend_PromptFrame_Mode = "";

	PlaySound("UChatScrollButton");
end

function EkRaidAttend_PromptFrame_Button1_OnClick()
	-- ----------
	-- User clicked on button 1 of the prompt frame.
	-- ----------
	local frame = getglobal("EkRaidAttend_PromptFrame_");

	EkRaidAttend_PromptFrame_UpdateVars();

	if (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_RELOADUI_UNSAVED) then
		frame:Hide();
		ReloadUI();

	elseif (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_TIMED_REMIND) then
		frame:Hide();
		EkRaidAttend_TimedStart("");

	elseif (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_LOTS_OF_ATTENDANCES) then
		frame:Hide();
		EkRaidAttend_ListsFrame_DeleteAllAttendances();
		EkRaidAttend_ListsFrame_Mode = 0;   -- 0==Lists, 1=Players, 2=Notepad
		if (EkRaidAttend_ListsFrame_:IsShown() or EkRaidAttend_PlayersFrame_:IsShown()) then
			EkRaidAttend_Frame_GotoTab(EkRaidAttend_Frame_TabLists);
			EkRaidAttend_ListsFrame_ListUpdate();
		end

	elseif (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_RELOADUI_ATTEND) then
		frame:Hide();
		ReloadUI();
	end
end

function EkRaidAttend_PromptFrame_Button2_OnClick()
	-- ----------
	-- User clicked on button 2 of the prompt frame.
	-- ----------
	local frame = getglobal("EkRaidAttend_PromptFrame_");

	EkRaidAttend_PromptFrame_UpdateVars();

	frame:Hide();
end

function EkRaidAttend_PromptFrame_DisableCB_OnClick()
	-- ----------
	-- User clicked on the disable prompt checkbox.
	-- ----------
end

function EkRaidAttend_PromptFrame_DisableCB_OnEnter()
	-- ----------
	-- Mouse is over the disable prompt checkbox.
	-- ----------
	if (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_LOTS_OF_ATTENDANCES) then
		GameTooltip_AddNewbieTip("Do not show this prompt again.", 1.0, 1.0, 1.0, "This will disable this prompt so that it will not appear again.", 1);
	else
		GameTooltip_AddNewbieTip("Disable this prompt", 1.0, 1.0, 1.0, "This will disable this prompt so that it will not appear again.  It can be re-enabled by toggling the EkRaidAttend option related to this prompt.", 1);
	end
end

function EkRaidAttend_PromptFrame_DisableRaidCB_OnClick()
	-- ----------
	-- User clicked on the disable prompt while in this raid checkbox.
	-- ----------
end

function EkRaidAttend_PromptFrame_DisableRaidCB_OnEnter()
	-- ----------
	-- Mouse is over the disable prompt while in this raid checkbox.
	-- ----------
	if (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_LOTS_OF_ATTENDANCES) then
		GameTooltip_AddNewbieTip("Disable all future attendance taking.", 1.0, 1.0, 1.0, "This will disable all settings that would cause the attendance to take attendance, or report on the status of saved attendances.", 1);
	else
		GameTooltip_AddNewbieTip("Do not prompt again while...", 1.0, 1.0, 1.0, "This will temporarily disable this prompt while you are in a raid.  If you are not in a raid, then it will disable the prompt until you join a raid.", 1);
	end
end

function EkRaidAttend_PromptFrame_UpdateVars()
	-- ----------
	-- Update variables based on status of the prompt check boxes.
	-- ----------
	local disCB = getglobal("EkRaidAttend_PromptFrame_DisableCB");
	local raidCB = getglobal("EkRaidAttend_PromptFrame_DisableRaidCB");

	local disChecked = disCB:GetChecked();
	local raidChecked = raidCB:GetChecked();

	if (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_RELOADUI_UNSAVED) then
		if (disChecked == 1) then
			EkRaidAttend_UnsavedReminderStatus = 1;  -- Turn off the prompting (2), but leave unsaved reminder enabled (1).
		end
		if (raidChecked == 1) then
			EkRaidAttend_DisabledRaidPrompts[EkRaidAttend_PromptFrame_Mode] = 1;
		end

	elseif (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_TIMED_REMIND) then
		if (disChecked == 1) then
			EkRaidAttend_TimedReminderStatus = 1;  -- Turn off the prompting (2), but leave timed reminder enabled (1).
		end
		if (raidChecked == 1) then
			EkRaidAttend_DisabledRaidPrompts[EkRaidAttend_PromptFrame_Mode] = 1;
		end

		-- Already prompted when we joined raid, so cancel timed reminder prompt.
		EkRaidAttend_ShowPrompts[EkRaidAttend_PROMPT_TIMED_REMIND] = nil;

	elseif (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_LOTS_OF_ATTENDANCES) then
		if (raidChecked == 1) then
			-- Disable some stuff related to attendance taking.
			EkRaidAttend_Status = 0;
			EkRaidAttend_BossKillAttend = 0;
			EkRaidAttend_UnsavedReminderStatus = 0;
			EkRaidAttend_TimedReminderStatus = 0;
			EkRaidAttend_ShowStatusFlag = 0;
		end
		if (disChecked == 1) then
			EkRaidAttend_ShowLotsPrompt = 0;
		end

	elseif (EkRaidAttend_PromptFrame_Mode == EkRaidAttend_PROMPT_RELOADUI_ATTEND) then
		if (disChecked == 1) then
			EkRaidAttend_ReloadUI = 0;  -- Turn off prompting to reload ui when attendance taken
		end
		if (raidChecked == 1) then
			EkRaidAttend_DisabledRaidPrompts[EkRaidAttend_PromptFrame_Mode] = 1;
		end

	end

	EkRaidAttend_UIRefresh();
end


-- ------------------------------------------------------------------
-- EkRaidAttend_DurabilityFrame
-- ------------------------------------------------------------------

function EkRaidAttend_CT_RADurabilityFrameDrag_OnMouseUp()
	-- ----------
	-- Use let go of the mouse button after dragging the durability frame.
	-- ----------
	EkRaidAttend_old_CT_RA_DurabilityFrameDrag_OnMouseUp();

	-- If one of our windows is open, then redisplay it. Due to the drag our window
	-- may not be on screen any more.  This is our chance to put it back on screen.

	if (EkRaidAttend_ResistFrame_:IsShown()) then
		EkRaidAttend_ResistFrame_Show();

	elseif (EkRaidAttend_ItemFrame_:IsShown()) then
		EkRaidAttend_ItemFrame_Show();
	end
end

function EkRaidAttend_CT_RADurability_Update()
	-- ----------
	-- CT_RaidAssist durability frame is being updated.
	-- ----------
	EkRaidAttend_old_CT_RADurability_Update();

	local show;

	-- Determine if we want to show the EkRaidAttend button, based on the type of durability frame.
	if (CT_RA_DurabilityFrame.type == "RARST") then
		show = 1;
	elseif (CT_RA_DurabilityFrame.type == "RADUR") then
		show = 1;
	elseif (CT_RA_DurabilityFrame.type == "RAITEM") then
		show = 1;
	end

	if (show) then
		-- Show the EkRaidAttend_Durability frame.
		if (not EkRaidAttend_DurabilityFrame_:IsShown()) then
			EkRaidAttend_DurabilityFrame_:SetPoint("TOP", "CT_RA_DurabilityFrame", "BOTTOM", 0, 15);
			EkRaidAttend_DurabilityFrame_:SetParent("CT_RA_DurabilityFrame");
			EkRaidAttend_DurabilityFrame_:Show();
		else
			-- Durability frame is already shown.
			-- If there is a related frame open...
			if (EkRaidAttend_DurabilityFrame_.type) then
				-- If the related frame type does not match the durability frame type...
				if (EkRaidAttend_DurabilityFrame_.type ~= CT_RA_DurabilityFrame.type) then
					EkRaidAttend_DurabilityFrame_HideRelatedFrames();
				else
					-- Update frame contents.
					if (CT_RA_DurabilityFrame.type == "RAITEM") then
						-- If item name has changed, then update the item frame contents.
						local itemName = CT_RA_DurabilityFrame.arg;
						if (EkRaidAttend_ItemFrame_.arg ~= itemName) then
							EkRaidAttend_ItemFrame_.arg = itemName;
							EkRaidAttend_ItemFrame_Update();
						end
					end
				end
			end
		end
	else
		-- Hide the EkRaidAttend_Durability frame.
		EkRaidAttend_DurabilityFrame_:Hide();
	end
end

function EkRaidAttend_DurabilityFrame_OnShow()
	-- ----------
	-- The durability frame is being shown.
	-- ----------

	-- Hide related windows.
	EkRaidAttend_DurabilityFrame_HideRelatedFrames();
end

function EkRaidAttend_DurabilityFrame_OnHide()
	-- ----------
	-- The durability frame is being hidden.
	-- ----------

	-- Hide related windows.
	EkRaidAttend_DurabilityFrame_HideRelatedFrames();
end

function EkRaidAttend_DurabilityFrame_HideRelatedFrames()
	-- ----------
	-- Hide related frames.
	-- ----------
	EkRaidAttend_ResistFrame_Hide();
	EkRaidAttend_ItemFrame_Hide();
end

function EkRaidAttend_DurabilityFrame_OnClick()
	-- ----------
	-- User clicked on the EkRaidAttend button on the durability frame.
	-- ----------
	if (CT_RA_DurabilityFrame.type == "RARST") then
		-- Toggle the resist frame.
		if (EkRaidAttend_ResistFrame_:IsShown()) then
			EkRaidAttend_ResistFrame_Hide();
		else
			EkRaidAttend_ResistFrame_Show();
		end

	elseif (CT_RA_DurabilityFrame.type == "RAITEM") then
		-- Toggle the item frame.
		if (EkRaidAttend_ItemFrame_:IsShown()) then
			EkRaidAttend_ItemFrame_Hide();
		else
			EkRaidAttend_ItemFrame_Show();
		end

	elseif (CT_RA_DurabilityFrame.type == "RADUR") then
		-- Toggle the durability frame.
		if (EkRaidAttend_ItemFrame_:IsShown()) then
			EkRaidAttend_ItemFrame_Hide();
		else
			EkRaidAttend_ItemFrame_Show();
		end
	end
end

-- ------------------------------------------------------------------
-- EkRaidAttend_ResistFrame
-- ------------------------------------------------------------------

-- Note: The sequence of these items must match the sequence used
-- in the CT_RADurability_Shown[] arrays (elements 4, 5, 6, 7, 8).
EkRaidAttend_ResistData = {
				{"fire", "Fire resist", 1, 0, 0},
				{"nature", "Nature resist", 0, 1, 0},
				{"frost", "Frost resist", 0, 0, 1},
				{"shadow", "Shadow resist", 1, 0, 1},
				{"arcane", "Arcane resist", 0.7, 0.7, 0.7},
			};

function EkRaidAttend_ResistFrame_Show()
	-- ----------
	-- Show the resist frame.
	-- ----------
	local xui, yui = UIParent:GetCenter();
	local lui = UIParent:GetLeft();
	local rui = UIParent:GetRight();

	local xdur, ydur = CT_RA_DurabilityFrame:GetCenter();
	local ldur = CT_RA_DurabilityFrame:GetLeft();
	local rdur = CT_RA_DurabilityFrame:GetRight();

	local wres = EkRaidAttend_ResistFrame_:GetWidth();

	local oldside = EkRaidAttend_ResistFrame_.oldside;  -- The side we opened it on last time.

	if (oldside == 1) then
		-- Was displayed on left side
		if (ldur - wres < lui) then
			oldside = nil;
		end
	elseif (oldside == 2) then
		-- Was displayed on right side
		if (rdur + wres > rui) then
			oldside = nil;
		end
	end

	if (not oldside) then
		-- Choose a side to display the window
		if (xdur < xui) then
			-- Display on right side of durability window
			op = "BOTTOMLEFT";
			rp = "BOTTOMRIGHT";
			oldside = 2;
		else
			-- Display on left side of durability window
			op = "BOTTOMRIGHT";
			rp = "BOTTOMLEFT";
			oldside = 1;
		end
		EkRaidAttend_ResistFrame_:ClearAllPoints();
		EkRaidAttend_ResistFrame_:SetPoint(op, "EkRaidAttend_DurabilityFrame_", rp, 0, 0);
		EkRaidAttend_ResistFrame_:SetParent("CT_RA_DurabilityFrame");

		EkRaidAttend_ResistFrame_.oldside = oldside;  -- Remember which side we opened it on.
	end

	EkRaidAttend_ResistFrame_:Show();
end

function EkRaidAttend_ResistFrame_Hide()
	-- ----------
	-- Hide the resist frame.
	-- ----------
	EkRaidAttend_ResistFrame_:Hide();
end

function EkRaidAttend_ResistFrame_OnShow()
	-- ----------
	-- The resist frame is being shown.
	-- ----------
	for i=1,getn(EkRaidAttend_ResistData) do
		local resText, resCB, minText, minEB, resName;
		local rec, resDataRec;

		resDataRec = EkRaidAttend_ResistData[i];

		resText = getglobal("EkRaidAttend_ResistFrame_Button" .. i .. "ResistText");
		resCB = getglobal("EkRaidAttend_ResistFrame_Button" .. i .. "ResistCB");
		minText = getglobal("EkRaidAttend_ResistFrame_Button" .. i .. "MinimumText");
		minEB = getglobal("EkRaidAttend_ResistFrame_Button" .. i .. "MinimumEB");
		resName = resDataRec[1];

		resText:SetText(resDataRec[2]);
		resText:SetTextColor(resDataRec[3], resDataRec[4], resDataRec[5]);

		if (not EkRaidAttend_ResistCheckConfig[resName]) then
			rec = {};
			rec["selected"] = 0;
			rec["minimum"] = 0;
			EkRaidAttend_ResistCheckConfig[resName] = rec;
		end
		rec = EkRaidAttend_ResistCheckConfig[resName];

		minText:SetText("Minimum");
		minText:SetTextColor(resDataRec[3], resDataRec[4], resDataRec[5]);
	end

	EkRaidAttend_ResistFrame_Update();

	EkRaidAttend_DurabilityFrame_.type = CT_RA_DurabilityFrame.type;
end

function EkRaidAttend_ResistFrame_OnHide()
	-- ----------
	-- The resist frame is being hidden.
	-- ----------
	EkRaidAttend_DurabilityFrame_.type = nil;
end

function EkRaidAttend_ResistFrame_Update()
	-- ----------
	-- Update information on the screen.
	-- ----------
	EkRaidAttend_ResistFrame_ResistCB_Update();
	EkRaidAttend_ResistFrame_MinimumEB_Update();
end

function EkRaidAttend_ResistFrame_ClearFocus()
	-- ----------
	-- Clear focus on all edit boxes.
	-- ----------
	for i=1,getn(EkRaidAttend_ResistData) do
		local minEB = getglobal("EkRaidAttend_ResistFrame_Button" .. i .. "MinimumEB");
		minEB:ClearFocus();
	end
end

function EkRaidAttend_ResistFrame_ResistCB_OnEnter()
	-- ----------
	-- Mouse is over one of the resistance check boxes.
	-- ----------
	local id = tonumber(this:GetParent():GetID());

	local resDataRec = EkRaidAttend_ResistData[id];
	local resText = resDataRec[2];

	GameTooltip_AddNewbieTip(resText, 1.0, 1.0, 1.0, "Select this item to include this type of resistance when you click the 'Record names' button.", 1);
end

function EkRaidAttend_ResistFrame_ResistCB_OnClick()
	-- ----------
	-- User clicked on one of the resist frame resistance checkboxes.
	-- ----------
	local id = tonumber(this:GetParent():GetID());
	local resDataRec = EkRaidAttend_ResistData[id];
	local resName = resDataRec[1];
	local rec = EkRaidAttend_ResistCheckConfig[resName];

	if (this:GetChecked()) then
		rec["selected"] = 1;
	else
		rec["selected"] = 0;
	end

	EkRaidAttend_ResistFrame_ClearFocus();
	EkRaidAttend_ResistFrame_ResistCB_Update();
end

function EkRaidAttend_ResistFrame_ResistCB_Update()
	-- ----------
	-- Update the resist frame resistance checkboxes.
	-- ----------
	local canRecord;

	for i=1,getn(EkRaidAttend_ResistData) do
		local resDataRec = EkRaidAttend_ResistData[i];
		local resName = resDataRec[1];
		local rec = EkRaidAttend_ResistCheckConfig[resName];
		local resCB = getglobal("EkRaidAttend_ResistFrame_Button" .. i .. "ResistCB");

		resCB:SetChecked(rec["selected"]);

		if (rec["selected"] == 1) then
			canRecord = 1;
		end
	end

	local rb = getglobal("EkRaidAttend_ResistFrame_RecordButton");
	if (canRecord) then
		rb:Enable();
	else
		rb:Disable();
	end
end

function EkRaidAttend_ResistFrame_MinimumEB_OnEnter()
	-- ----------
	-- Mouse is over one of the resistance minimum edit boxes.
	-- ----------
	local id = tonumber(this:GetParent():GetID());

	local resDataRec = EkRaidAttend_ResistData[id];
	local resText = resDataRec[2];

	GameTooltip_AddNewbieTip("Minimum " .. string.lower(resText), 1.0, 1.0, 1.0, "A player's name will only be recorded if their resistance is greater than or equal to this minimum value.", 1);
end

function EkRaidAttend_ResistFrame_MinimumEB_EditStart()
	-- ----------
	-- Start editing the Minimum value.
	-- ----------
	local id = tonumber(this:GetParent():GetID());
	local minEB = getglobal("EkRaidAttend_ResistFrame_Button" .. id .. "MinimumEB");

	if ( minEB.editing ) then
		return;
	end

	minEB:HighlightText();
	minEB.editing = 1;
end

function EkRaidAttend_ResistFrame_MinimumEB_EditStop(cancel)
	-- ----------
	-- User has stopped editing the Minimum value.
	-- ----------
	local id = tonumber(this:GetParent():GetID());
	local minEB = getglobal("EkRaidAttend_ResistFrame_Button" .. id .. "MinimumEB");

	if ( not minEB.editing ) then
		return;
	end

	local value = minEB:GetText();

	minEB:HighlightText(0, 0);
	minEB.editing = nil;

	local resDataRec = EkRaidAttend_ResistData[id];
	local resName = resDataRec[1];
	local rec = EkRaidAttend_ResistCheckConfig[resName];

	if ( not cancel ) then
		-- Save new value.
		rec["minimum"] = tonumber(value);
	else
		-- Restore original value.
		EkRaidAttend_ResistFrame_MinimumEB_Update();
	end
end

function EkRaidAttend_ResistFrame_MinimumEB_Update()
	-- ----------
	-- Update the Minimum editbox.
	-- ----------
	for i=1,getn(EkRaidAttend_ResistData) do
		local resDataRec = EkRaidAttend_ResistData[i];
		local resName = resDataRec[1];
		local rec = EkRaidAttend_ResistCheckConfig[resName];

		local minEB = getglobal("EkRaidAttend_ResistFrame_Button" .. i .. "MinimumEB");
		minEB:SetNumber(rec["minimum"]);
	end
end

function EkRaidAttend_ResistFrame_MinimumEB_OnTab()
	-- ----------
	-- User clicked on the tab button.  Move to the next/previous edit box.
	-- ----------
	this:ClearFocus();

	local id = tonumber(this:GetParent():GetID());

	if ( IsShiftKeyDown() ) then
		id = id - 1;
		if (id < 1) then
			id = getn(EkRaidAttend_ResistData);
		end
	else
		id = id + 1;
		if (id > getn(EkRaidAttend_ResistData)) then
			id = 1;
		end
	end

	local minEB = getglobal("EkRaidAttend_ResistFrame_Button" .. id .. "MinimumEB");
	minEB:SetFocus();
end

function EkRaidAttend_ResistFrame_RecordButton_OnClick()
	-- ----------
	-- User clicked on the record button.  Save the names as attendance list(s).
	-- ----------
	local user_msg, sys_msg, durSub, minimum;

	EkRaidAttend_ResistFrame_ClearFocus();

	-- Resistance data.
	for i=1,getn(EkRaidAttend_ResistData) do
		local resDataRec = EkRaidAttend_ResistData[i];
		local resName = resDataRec[1];
		local rec = EkRaidAttend_ResistCheckConfig[resName];

		if (rec["selected"] == 1) then
			durSub = 3 + i;
			minimum = rec["minimum"];
			user_msg = "";

			-- Eg. "Resist fire 99"
			sys_msg = "Resist " .. resName .. " " .. minimum;
			EkRaidAttend_TakeSpecial(user_msg, sys_msg, durSub, minimum, "Resist check", EkRaidAttend_PlayerStatus_RESIST);
		end
	end

	EkRaidAttend_ResistFrame_Hide();
end

function EkRaidAttend_ResistFrame_CloseButton_OnClick()
	-- ----------
	-- User clicked on the close button.  Close the resist window.
	-- ----------
	EkRaidAttend_ResistFrame_ClearFocus();
	EkRaidAttend_ResistFrame_Hide();
end

-- ------------------------------------------------------------------
-- EkRaidAttend_ItemFrame
-- (Handles item and durability checks)
-- ------------------------------------------------------------------

function EkRaidAttend_ItemFrame_Show()
	-- ----------
	-- Show the item frame.
	-- ----------
	local xui, yui = UIParent:GetCenter();
	local lui = UIParent:GetLeft();
	local rui = UIParent:GetRight();

	local xdur, ydur = CT_RA_DurabilityFrame:GetCenter();
	local ldur = CT_RA_DurabilityFrame:GetLeft();
	local rdur = CT_RA_DurabilityFrame:GetRight();

	local witem = EkRaidAttend_ItemFrame_:GetWidth();

	local oldside = EkRaidAttend_ItemFrame_.oldside;  -- The side we opened it on last time.

	if (oldside == 1) then
		-- Was displayed on left side
		if (ldur - witem < lui) then
			oldside = nil;
		end
	elseif (oldside == 2) then
		-- Was displayed on right side
		if (rdur + witem > rui) then
			oldside = nil;
		end
	end

	if (not oldside) then
		-- Choose a side to display the window
		if (xdur < xui) then
			-- Display on right side of durability window
			op = "BOTTOMLEFT";
			rp = "BOTTOMRIGHT";
			oldside = 2;
		else
			-- Display on left side of durability window
			op = "BOTTOMRIGHT";
			rp = "BOTTOMLEFT";
			oldside = 1;
		end
		EkRaidAttend_ItemFrame_:ClearAllPoints();
		EkRaidAttend_ItemFrame_:SetPoint(op, "EkRaidAttend_DurabilityFrame_", rp, 0, 0);
		EkRaidAttend_ItemFrame_:SetParent("CT_RA_DurabilityFrame");

		EkRaidAttend_ItemFrame_.oldside = oldside;  -- Remember which side we opened it on.
	end

	EkRaidAttend_ItemFrame_:Show();
end

function EkRaidAttend_ItemFrame_Hide()
	-- ----------
	-- Hide the item frame.
	-- ----------
	EkRaidAttend_ItemFrame_:Hide();
end

function EkRaidAttend_ItemFrame_OnShow()
	-- ----------
	-- The item frame is being shown.
	-- ----------
	EkRaidAttend_DurabilityFrame_.type = CT_RA_DurabilityFrame.type;
	EkRaidAttend_ItemFrame_.arg = CT_RA_DurabilityFrame.arg;
	EkRaidAttend_ItemFrame_Update();
end

function EkRaidAttend_ItemFrame_OnHide()
	-- ----------
	-- The item frame is being hidden.
	-- ----------
	EkRaidAttend_DurabilityFrame_.type = nil;
end

function EkRaidAttend_ItemFrame_Update()
	-- ----------
	-- Update information on the screen.
	-- ----------
	local itemName;
	if (EkRaidAttend_DurabilityFrame_.type == "RADUR") then
		itemName = "Durability";
	else
		itemName = EkRaidAttend_ItemFrame_.arg;
	end
	EkRaidAttend_ItemFrame_ItemText:SetText(itemName);

	EkRaidAttend_ItemFrame_MinimumEB_Update();
end

function EkRaidAttend_ItemFrame_ClearFocus()
	-- ----------
	-- Clear focus on all edit boxes.
	-- ----------
	local minEB = getglobal("EkRaidAttend_ItemFrame_MinimumEB");
	minEB:ClearFocus();
end

function EkRaidAttend_ItemFrame_MinimumEB_OnEnter()
	-- ----------
	-- Mouse is over one of the item minimum edit box.
	-- ----------
	if (EkRaidAttend_DurabilityFrame_.type == "RADUR") then
		GameTooltip_AddNewbieTip("Minimum", 1.0, 1.0, 1.0, "A player's name will only be recorded if their equipment durability is greater than or equal to this minimum value.", 1);
	else
		GameTooltip_AddNewbieTip("Minimum", 1.0, 1.0, 1.0, "A player's name will only be recorded if their item quantity is greater than or equal to this minimum value.", 1);
	end
end

function EkRaidAttend_ItemFrame_MinimumEB_EditStart()
	-- ----------
	-- Start editing the Minimum value.
	-- ----------
	local minEB = getglobal("EkRaidAttend_ItemFrame_MinimumEB");

	if ( minEB.editing ) then
		return;
	end

	minEB:HighlightText();
	minEB.editing = 1;
end

function EkRaidAttend_ItemFrame_MinimumEB_EditStop(cancel)
	-- ----------
	-- User has stopped editing the Minimum value.
	-- ----------
	local minEB = getglobal("EkRaidAttend_ItemFrame_MinimumEB");

	if ( not minEB.editing ) then
		return;
	end

	local value = minEB:GetText();

	minEB:HighlightText(0, 0);
	minEB.editing = nil;

	if (EkRaidAttend_DurabilityFrame_.type == "RADUR") then
		if ( not cancel ) then
			-- Save new value.
			EkRaidAttend_DurabilityCheckConfig = tonumber(value);
		end
	else
		local itemName = EkRaidAttend_ItemFrame_.arg;
		local rec = EkRaidAttend_ItemCheckConfig[itemName];

		if ( not cancel ) then
			-- Save new value.
			rec["minimum"] = tonumber(value);
--		else
--			-- Restore original value.
--			EkRaidAttend_ItemFrame_MinimumEB_Update();
		end
	end

	EkRaidAttend_ItemFrame_MinimumEB_Update();
end

function EkRaidAttend_ItemFrame_MinimumEB_Update()
	-- ----------
	-- Update the Minimum editbox.
	-- ----------
	local itemName = EkRaidAttend_ItemFrame_.arg;
	local rec, minVal;

	if (EkRaidAttend_DurabilityFrame_.type == "RADUR") then
		itemName = "Durability";
		minVal = EkRaidAttend_DurabilityCheckConfig;
	else
		if (not EkRaidAttend_ItemCheckConfig[itemName]) then
			rec = {};
			rec["minimum"] = 0;
			EkRaidAttend_ItemCheckConfig[itemName] = rec;
		end

		rec = EkRaidAttend_ItemCheckConfig[itemName];
		minVal = rec["minimum"];
	end

	local minEB = getglobal("EkRaidAttend_ItemFrame_MinimumEB");
	minEB:SetNumber(minVal);

	local rb = getglobal("EkRaidAttend_ItemFrame_RecordButton");
	if (EkRaidAttend_IsEmpty(itemName)) then
		rb:Disable();
	else
		rb:Enable();
	end
end

function EkRaidAttend_ItemFrame_RecordButton_OnClick()
	-- ----------
	-- User clicked on the record button.  Save the names as attendance list(s).
	-- ----------
	local user_msg, sys_msg, durSub, minimum, check, status;

	EkRaidAttend_ItemFrame_ClearFocus();

	if (EkRaidAttend_DurabilityFrame_.type == "RADUR") then
		durSub = 4;
		minimum = EkRaidAttend_DurabilityCheckConfig;

		sys_msg = "Durabilty " .. minimum;

		check = "Durability check";
		status = EkRaidAttend_PlayerStatus_DURABILITY;
	else
		-- Item data.
		local itemName = EkRaidAttend_ItemFrame_.arg;
		local rec = EkRaidAttend_ItemCheckConfig[itemName];

		durSub = 4;
		minimum = rec["minimum"];

		-- Eg. "Item Greater Fire Protection Potion 99"
		sys_msg = "Item " .. itemName .. " " .. minimum;

		check = "Item check";
		status = EkRaidAttend_PlayerStatus_ITEM;
	end

	user_msg = "";
	EkRaidAttend_TakeSpecial(user_msg, sys_msg, durSub, minimum, check, status);

	EkRaidAttend_ItemFrame_Hide();
end

function EkRaidAttend_ItemFrame_CloseButton_OnClick()
	-- ----------
	-- User clicked on the close button.  Close the item window.
	-- ----------
	EkRaidAttend_ItemFrame_ClearFocus();
	EkRaidAttend_ItemFrame_Hide();
end

function EkRaidAttend_EkCheck_CreateTooltipText(index, total, data)
	-- ----------
	-- User moved pointer over a line in the list.
	--
	-- index -- position of the item in the list
	-- total -- number of items in the list
	-- data -- Array of data
	--
	-- 	data[]
	-- 	---------------
	-- 	[1] == EkCheck: Player name
	-- 	[2] == EkCheck: Uppercase english class string (ie. non-localized) (eg. "PRIEST")
	-- 	[3] == EkCheck: 0==Addon not loaded, 1==Addon loaded.
	-- 	[4] == EkCheck: 0==Player has not responded to the check, 1==Player has responded to the check.
	-- 	[5] == EkCheck: Player class (localized)
	-- 	[6] to [10] == EkCheck: Reserved
	--
	-- 	[11] == EkRaidAttend: Version string
	--
	-- Returns:
	--	a) nil -- if no tooltip should be generated.
	--	b) String containing text to appear in the tooltip.
	-- ----------
--	local text;
--	local white = "|c00FFFFFF";
--	return text;

	return nil;
end

function EkRaidAttend_EkCheck_CreateResponse(data)
	-- ----------------
	-- Create addon specific portion of response string.
	--
	-- data -- Array of data provided by EkCheck.
	--
	-- 	data[]
	-- 	--------
	-- 	[1] == Name of the player that initiated the check.
	-- 	[2] == Name of the addon being checked for.
	--
	-- Returns:
	-- 	a) nil or "" == No addon specific response string.
	--	b) Addon specific response string.
	-- ----------------
	local resp;

	-- Version
	resp = "v" .. EkRaidAttend_cVersion;

	-- Return the response string.
	return resp;
end

function EkRaidAttend_EkCheck_ParseResponse(text, data)
	-- ----------------
	-- Parse response text.
	--
	-- text -- The addon specific portion of the response.
	-- data -- Array of data provided by EkCheck.
	--
	-- 	data[]
	-- 	---------------
	-- 	[1] == Player name
	-- 	[2] == Uppercase english class string (ie. non-localized) (eg. "PRIEST")
	-- 	[3] == 0==Addon not loaded, 1==Addon loaded.
	-- 	[4] == 0==Player has not responded to the check, 1==Player has responded to the check.
	-- 	[5] == Player class (localized)
	--
	-- Returns:
	--	a) nil -- Invalid response
	--      b) Array containing addon specific data (to be used for the check window, tooltip, etc).
	-- ----------------
	local msg;
	local version;

	version = "?";

	msg = strlower(text);

	for k, v in string.gfind(msg, "(%a)(%S+)") do
		if (k == "v") then
			version = v;
		end
	end

	return { version };
end

