# HotCandy
HotCandy is a Heal-over-Time tracker initialy designed for Druids, 
but has grown into a full HoT/Buff tracker for all healing classes.

HotCandy was designed to be very simple and easy to use, 
with only a handful of options to customize the style of the bars. 

HotCandy is driven solely by the CombatLog events which provide it with 
all information it needs to display accurate timers for the HoTs you cast on other players (or yourself, of course).

## Supported Spells

- Druids  
  - Rejuvenation (with Tier 2 Bonus)
  - Regrowth 
- Priests
  - Renew  
  - Greater Heal (only with Tier 2 Bonus)

All supported spells can be enabled/disabled in the HotCandy configurarion, as you see fit.

You can access the HotCandy configuration through the Blizzard Interface AddOns Options, or with the /hotcandy slash command.
