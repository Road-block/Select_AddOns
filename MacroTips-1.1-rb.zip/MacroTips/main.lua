--[[--------------------------------------------------

	MacroTips v1.1
	
	Vanilla WoW addon to add custom tooltip text to
	macros, since #showtooltip doesn't exist yet in
	the the 1.12 universe.

	Should work with default bars and Bongos.
	
	Original author https://github.com/fulzamoth

	Inspired by Anaron's MacroTooltip

--------------------------------------------------]]--

local help = {
	"/mtps Spell Name",
	"    in a macro will show the spell tooltip",
	"/mtpe slot",
	"    in a macro will show the tooltip of item in that slot",
	"    slot can be one of ammo, head, neck, shoulder, body, chest, waist, legs, feet, wrist, hands,  finger, finger1, trinket, trinket2, cloak, mainhand, offhand, ranged, wand, tabard",
	"/mtpc any text",
	"    used together with the /mtpa option to add a custom tooltip header and text",
	"/mtpa any other text",
	"    add text to a tooltip line, multiple /mtpa text here can be used in same macro"
}
local print = function(msg)
  if not DEFAULT_CHAT_FRAME:IsVisible() then
    FCF_SelectDockFrame(DEFAULT_CHAT_FRAME)
  end
  DEFAULT_CHAT_FRAME:AddMessage("|cff006633MacroTips: |r"..msg)
end

local haveShownHelp
local orig_ShowMacroFrame = ShowMacroFrame
ShowMacroFrame = function(...)
	if not (haveShownHelp) then
		haveShownHelp = true
		print("\'/macrotips\' for Usage help")
	end
	orig_ShowMacroFrame(unpack(arg))
end

SLASH_MACROTIPS1="/mtps";
SLASH_MACROTIPS2="/mtpe";
SLASH_MACROTIPS3="/mtpc";
SLASH_MACROTIPS4="/mtpa";
SLASH_MACROTIPSHELP1="/macrotips";
SlashCmdList["MACROTIPS"] = function(Flag) 
end
SlashCmdList["MACROTIPSHELP"] = function(cmd)
  for _,line in ipairs(help) do
  	print(line)
  end
end
	
local function trim(s)
  return (string.gsub(s,"^%s*(.-)%s*$", "%1"))
end
local itemSlots = { -- These are the WoW Inventory Slot IDs
  ammo = 0, 
  head = 1, 
  neck = 2, 
  shoulder = 3, 
  body = 4, 
  chest = 5, 
  waist = 6, 
  legs = 7, 
  feet = 8,
  wrist = 9, 
  hands = 10,  
  finger = 11, 
  finger1 = 12, 
  trinket = 13, 
  trinket2 = 14, 
  cloak = 15,
  mainhand = 16, 
  offhand = 17, 
  ranged = 18,
  wand = 18,
  tabard = 19 
}
function ActionButton_SetTooltip()
	if ( GetCVar("UberTooltips") == "1" ) then
		GameTooltip_SetDefaultAnchor(GameTooltip, this);
	else
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT");
	end
	local button 
    if BActionButton then  -- Checks if the button is a Bongos button
        button = BActionButton.GetPagedID(this:GetID())
    else
        button = ActionButton_GetPagedID(this)
    end
	local buttonMacroName = GetActionText(button)
	
	local customTooltip = false
  local macroName,_,macroBody
	if buttonMacroName then
		for macroSlot = 1, 36, 1 do
			macroName,_,macroBody = GetMacroInfo(macroSlot)
			if buttonMacroName == macroName then
				break
			elseif not macroName then	-- we've run through available macros in this tab
				if macroSlot <= 18 then	-- if we're in the General macro tab still...
					macroSlot = 18		-- ...skip to last slot in General so loop starts in Character tab next
				else
					break				-- we're all out of macros to check.
				end
			end
		end

		for macroLine in string.gfind(macroBody, "[^%\n]+") do
			repeat	
				--[[
					/mtps - tooltip from spell
				]]
				if string.find(macroLine, "^/mtps ") then
					local spellName, spellRank, rankedSpellSlot, rankStart, rankEnd, bookSpellName, bookSpellRank, spellHighRank
					rankStart, rankEnd = string.find(macroLine,"%(Rank %d+%)")
					if rankStart then
						spellName = trim(string.sub(macroLine, 7, rankStart - 1))
						spellRank = string.sub(macroLine, rankStart + 1, rankEnd - 1)
					else
						spellName = trim(string.sub(macroLine, 7))
					end
					local spellSlot = 1
					while true do
						bookSpellName, bookSpellRank = GetSpellName(spellSlot, "player")
						if not bookSpellName then	-- We've reached the end of the spellbook
							break
						end
						if spellRank then
							if bookSpellName == spellName and bookSpellRank == spellRank then 
								rankedSpellSlot = spellSlot
								spellHighRank = bookSpellRank
								break
							end
						elseif bookSpellName == spellName then
							rankedSpellSlot = spellSlot		-- Store the spell slot; we'll keep checking for higher rank
							spellHighRank = bookSpellRank
						end
						spellSlot = spellSlot + 1
					end
					GameTooltip:SetSpell(rankedSpellSlot,"player")
          if (spellHighRank) and spellHighRank~="" then
  					GameTooltip:AddLine("(" .. spellHighRank ..")",0.5,0.5,0.5)
          end
					this.updateTooltip = TOOLTIP_UPDATE_TIME;
					customTooltip = true
					break
				end
				--[[
					/mtpe - tooltip from equipped item
				]]
				if string.find(macroLine, "^/mtpe ") then
					local equipSlot = itemSlots[string.sub(macroLine, 7)] or tonumber(string.sub(macroLine, 7))
					if GetInventoryItemLink("player", equipSlot) then	-- check to see if anything is equipped in this slot
						GameTooltip:SetInventoryItem("player", equipSlot )
					else
						GameTooltip:SetText("No item equipped in slot " .. equipSlot,1,1,0.5)
					end		
					this.updateTooltip = TOOLTIP_UPDATE_TIME;
					customTooltip = true
					break
				end
				--[[
					/mtpc - custom tooltip header text
				]]
				if string.find(macroLine, "^/mtpc ") then
					GameTooltip:SetText(string.sub(macroLine, 7),0.9,1,1)
					this.updateTooltip = TOOLTIP_UPDATE_TIME;
					customTooltip = true
					break
				end
				--[[
					/mtpa - additional text for tooltip
				]]
				if string.find(macroLine, "^/mtpa") then
					GameTooltip:AddLine(string.sub(macroLine, 7) .. " " ,0,0.80,0.81)	-- appended space allows for blank lines in tooltip
					this.updateTooltip = TOOLTIP_UPDATE_TIME;
					customTooltip = true
					break
				end
			until true
		end
	end

	if customTooltip then
		GameTooltip:Show()
		this.updateTooltip = nil; 
	elseif ( GameTooltip:SetAction(button) ) then
		this.updateTooltip = TOOLTIP_UPDATE_TIME;
	else
		this.updateTooltip = nil;
	end
end
if BActionButton then 
	BActionButton.UpdateTooltip = ActionButton_SetTooltip 
end 
