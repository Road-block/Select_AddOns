# MacroTips for Vanilla WoW

Create custom tooltips in macros. MacroTips fills in for the missing *#showtooltip* command that World of Warcraft 1.12 doesn't have.

## Usage

MacroTips provides four slash commands to use in macros.

**/mtps &lt;spell name&gt;**
Displays the tooltip for the spell listed. The name must match exactly. 

**/mtpe &lt;equipment slot&gt;**
Displays the tooltip for item currently equipped in the equipment slot. Equipment slot can be one of: *ammo, head, neck, shoulder, body, chest, waist, legs, feet, wrist, hands,  finger, finger1, trinket, trinket2, cloak, mainhand, offhand, ranged, wand, tabard*.

**/mtpc &lt;custom header text&gt;**
Displays a tooltip with the custom header text. This is usually followed by additional text (`mtpa`)

**/mtpa &lt;additional text&gt;**
Adds the additional text to any of the above tooltips. Multiple `mtpa` lines can be used and blank lines are valid.

Note that ***macro names must be unique***. The addon finds macros by name to read the macro body (*GetActionInfo* wasn't available until patch 2.0.1).

