sepgp = AceLibrary("AceAddon-2.0"):new("AceConsole-2.0", "AceDB-2.0", "AceDebug-2.0", "AceEvent-2.0", "AceModuleCore-2.0", "FuBarPlugin-2.0")
sepgp:SetModuleMixins("AceDebug-2.0")

local shooty_basegp = 135
local shooty_debugchat
local out = "|cff9664c8shootyepgp:|r %s"

function sepgp:OnInitialize()
  self.OnMenuRequest = sepgp_buildoptions() 
end

function sepgp:OnEnable()
  for i=1,NUM_CHAT_WINDOWS do
    local tab = getglobal("ChatFrame"..i.."Tab")
    local cf = getglobal("ChatFrame"..i)
    local tabName = tab:GetText()
    if tab ~= nil and (string.lower(tabName) == "debug") then
      shooty_debugchat = cf
      ChatFrame_RemoveAllMessageGroups(shooty_debugchat)
      shooty_debugchat:SetMaxLines(1024)
      break
    end
  end 
  sepgp:RegisterEvent("GUILD_ROSTER_UPDATE",function() 
      if (arg1) then -- someone joined or left
        sepgp_buildoptions() -- rebuild our options
      end 
    end)
end

function sepgp_flash(frame)
  local tabFlash = getglobal(frame:GetName().."TabFlash");
  if ( not frame.isDocked or (frame == SELECTED_DOCK_FRAME) or UIFrameIsFlashing(tabFlash) ) then
    return
  end
  tabFlash:Show();
  UIFrameFlash(tabFlash, 0.25, 0.25, 60, nil, 0.5, 0.5)
end

function sepgp_debug(msg)
  if (shooty_debugchat) then
    shooty_debugchat:AddMessage(string.format(out,msg))
    sepgp_flash(shooty_debugchat)
  else
    sepgp_print(msg)
  end
end

function sepgp_print(msg)
  if not DEFAULT_CHAT_FRAME:IsVisible() then
    FCF_SelectDockFrame(DEFAULT_CHAT_FRAME)
  end
  DEFAULT_CHAT_FRAME:AddMessage(string.format(out,msg))
end

function sepgp_say(msg)
  SendChatMessage(string.format("shootyepgp: %s",msg), sepgp_saychannel)
end

function sepgp_admin_say(msg)
  -- API is broken on Elysium
  -- local g_listen, g_speak, officer_listen, officer_speak, g_promote, g_demote, g_invite, g_remove, set_gmotd, set_publicnote, view_officernote, edit_officernote, set_guildinfo = GuildControlGetRankFlags() 
  -- if (officer_speak) then
  SendChatMessage(string.format("shootyepgp: %s",msg),"OFFICER")
  -- end
end

function sepgp_init_notes(guild_index,note,officernote)
  if not tonumber(note) or (tonumber(note) < 0) then
    GuildRosterSetPublicNote(guild_index,0)
  end
  if not tonumber(officernote) or (tonumber(officernote) < shooty_basegp) then
    GuildRosterSetOfficerNote(guild_index,shooty_basegp)
  end
end

function sepgp_updateep(getname,ep)
  for i = 1, GetNumGuildMembers(1) do
    local name, _, _, _, class, _, note, officernote, _, _ = GetGuildRosterInfo(i)
    if (name==getname) then 
      sepgp_init_notes(i,note,officernote)
      GuildRosterSetPublicNote(i,ep)
    end
  end
end

function sepgp_updategp(getname,gp)
  for i = 1, GetNumGuildMembers(1) do
    local name, _, _, _, class, _, note, officernote, _, _ = GetGuildRosterInfo(i)
    if (name==getname) then 
      sepgp_init_notes(i,note,officernote)
      GuildRosterSetOfficerNote(i,gp) 
    end
  end
end

function sepgp_getep(getname) -- gets ep by name
  for i = 1, GetNumGuildMembers(1) do
    local name, _, _, _, class, _, note, officernote, _, _ = GetGuildRosterInfo(i)
    if tonumber(note)==nil then note=0 end
    if (name==getname) then return tonumber(note); end
  end
  return(0)
end

function sepgp_getgp(getname) -- gets gp by name
  for i = 1, GetNumGuildMembers(1) do
    local name, _, _, _, class, _, note, officernote, _, _ = GetGuildRosterInfo(i)
    if tonumber(officernote)==nil then officernote=shooty_basegp end
    if (name==getname) then return tonumber(officernote); end
  end
  return(shooty_basegp)
end

function sepgp_awardraidep(ep) -- awards ep to raid members in zone
  if GetNumRaidMembers()>0 then
    sepgp_say(string.format("Giving %d ep to all raidmembers",ep))
    for i = 1, GetNumRaidMembers(true) do
      local name, rank, subgroup, level, class, fileName, zone, online, isDead = GetRaidRosterInfo(i)
      sepgp_givenameep(name,ep)
    end
  else UIErrorsFrame:AddMessage("You aren't in a raid dummy",255,0,0)end
end

function sepgp_givenameep(getname,ep) -- awards ep to a single character
  sepgp_debug(string.format("Giving %d ep to %s",ep,getname))
  ep = ep + sepgp_getep(getname)
  sepgp_updateep(getname,ep)
end

function sepgp_givenamegp(getname,gp) -- assigns gp to a single character
  sepgp_debug(string.format("Giving %d gp to %s",gp,getname))
  local oldgp = sepgp_getgp(getname)
  local newgp = gp + oldgp
  sepgp_admin_say(string.format("Awarding %d GP to %s. (Previous: %d, New: %d)",gp,getname,oldgp,newgp))
  sepgp_updategp(getname,newgp)
end

function sepgp_decay() -- decays entire roster's ep and gp
  for i = 1, GetNumGuildMembers(1) do
    local name,_,_,_,class,_,ep,gp,_,_ = GetGuildRosterInfo(i)
    ep = tonumber(ep)
    gp = tonumber(gp)
    if ep == nil then 
  	else 
      ep = math.max(0,sepgp_round(ep*0.9))
  	  GuildRosterSetPublicNote(i,ep)
  	  gp = math.max(shooty_basegp,sepgp_round(gp*0.9))
  	  GuildRosterSetOfficerNote(i,gp)
    end
  end
  sepgp_say("all ep and gp decayed by 10%")
end

function sepgp_gpreset()
   for i = 1, GetNumGuildMembers(1) do
     GuildRosterSetOfficerNote(i, shooty_basegp)
   end
   sepgp_debug(string.format("All GP has been reset to %d.",shooty_basegp))
end

function sepgp_showstandings() -- shows standings window of entire roster
end

function sepgp_round(i)
  return math.floor(i+0.5)
end

local T = AceLibrary("Tablet-2.0")

sepgp.defaultMinimapPosition = 180
sepgp.cannotDetachTooltip = true
sepgp.tooltipHidderWhenEmpty = false
sepgp.hasIcon = "Interface\\Icons\\INV_Misc_Orb_04"

function sepgp:OnTooltipUpdate()
  T:SetHint("Open EPGP Standings")
end

function sepgp:OnClick()
  sepgp_standings:Toggle()
end

function sepgp_buildoptions()
  if sepgp_saychannel == nil then sepgp_saychannel = "GUILD" end
  local numGuildMembers = GetNumGuildMembers(1)
  local options = {
    type = "group",
    desc = "shootyepgp options",
    args = { }
  }
  options.args["ep_raid"] = {
    type = "text",
    name = "+EPs to Raid",
    desc = "Award EPs to all raid members.",
    get = false,
    set = function(v) sepgp_awardraidep(tonumber(v))end,
    usage = "<EP>",
    disabled = function() return not (CanEditOfficerNote() and CanEditPublicNote()) end,
    validate = function(v)
      local n = tonumber(v)
      return n and n >= 0 and n < 10000
    end
  }
  
 options.args["ep"] = {
   type = "group",
   name = "+EPs to Member",
   desc = "Account EPs for member.",
   disabled = function() return not (CanEditOfficerNote() and CanEditPublicNote()) end,
   args = { }
 }
 sepgp_debug(string.format("Parsing %d guild members for EP/GP Info..",numGuildMembers))
 for i = 1, numGuildMembers do
   local member_name,_,_,_,class,_,ep,gp,_,_ = GetGuildRosterInfo(i)
   if (not options.args["ep"].args[class]) then
     options.args["ep"].args[class] = {
       type = "group",
       name = class,
       desc = class .. " members",
       disabled = function() return not (CanEditOfficerNote() and CanEditPublicNote()) end,
       args = { }
     }
   end
   options.args["ep"].args[class].args[member_name] = {
     type = "text",
     name = member_name,
     desc = "Account EPs to " .. member_name .. ".",
     usage = "<EP>",
     get = false,
     set = function(v) sepgp_givenameep(member_name, tonumber(v)) end,
     validate = function(v) return (type(v) == "number" or tonumber(v)) and tonumber(v) < 10000 end
   }
 end
  
 options.args["gp"] = {
   type = "group",
   name = "+GPs to Member",
   desc = "Account GPs for member.",
   disabled = function() return not (CanEditOfficerNote() and CanEditPublicNote()) end,
   args = { }
 }
 for i = 1, numGuildMembers do
   local member_name,_,_,_,class,_,ep,gp,_,_ = GetGuildRosterInfo(i)
   if (not options.args["gp"].args[class]) then
     options.args["gp"].args[class] = {
       type = "group",
       name = class,
       desc = class .. " members",
       disabled = function() return not (CanEditOfficerNote() and CanEditPublicNote()) end,
       args = { }
     }
   end
   options.args["gp"].args[class].args[member_name] = {
     type = "text",
     name = member_name,
     desc = "Account GPs to " .. member_name .. ".",
     usage = "<GP>",
     get = false,
     set = function(v) sepgp_givenamegp(member_name, tonumber(v)) end,
     validate = function(v) return (type(v) == "number" or tonumber(v)) and tonumber(v) < 10000 end
   }
 end
  options.args["report_channel"] = {
    type = "text",
    name = "Reporting channel",
    desc = "Channel used by reporting functions.",
    get = function() return sepgp_saychannel end,
    set = function(v) sepgp_saychannel = v end,
    validate = { "PARTY", "RAID", "GUILD", "OFFICER" },
  }
  options.args["decay"] = {
    type = "execute",
    name = "Decay EPGP",
    desc = "Decays all EPGP by 10%",
    disabled = function() return not (CanEditOfficerNote() and CanEditPublicNote()) end,
    func = function() sepgp_decay() end
  }
  
  -- Reset EPGP data
 options.args["reset"] = {
   type = "execute",
   name = "Reset GP",
   desc = string.format("gives everybody %d basic GP.",shooty_basegp),
   disabled = function() return not (IsGuildLeader()) end,
   func = function() sepgp_gpreset() end
	}
  return options
end
