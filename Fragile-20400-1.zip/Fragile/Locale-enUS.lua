local L = AceLibrary("AceLocale-2.2"):new("Fragile")

L:RegisterTranslations("enUS", function() return {

  ["Fragile"] = true,
	["Options for aggro indication."] = true,
	["Options Window"] = true,
	["Shows the Options Window"] = true,
	["Waterfall-1.0 is required to access the GUI."] = true,
	["Sound alert"] = true,
	["Sound alert on member aggro."] = true,
	["Sound"] = true,
	["Select default sound."] = true,
	["Announce"] = true,
	["Print a combat text announcement on member aggro."] = true,
	["Glow"] = true,
	["Party frame glow on member aggro."] = true,
	["None"] = true,
	["Fragile Options"] = true,
	["None"] = true,
	["Aggro on "] = true,
  
  ["DEFAULT_TEXT"] = "Fragile: FRame AGgro Indicators Light Edition.",
  ["SLASH_CMD"] = {"/fragile", "/frag"},
  
} end)
