-------------------------------------------------------------------------------
-- Locals                                                                    --
-------------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("Fragile")

local sml = AceLibrary:HasInstance("SharedMedia-1.0") and AceLibrary("SharedMedia-1.0") or nil
local banzai = AceLibrary:HasInstance("Banzai-1.1") and AceLibrary("Banzai-1.1")
local Waterfall = AceLibrary:HasInstance("Waterfall-1.0") and AceLibrary("Waterfall-1.0")

local lastAggroAlert = nil
local Fragile_partyid = nil
local debug = false

local sounds = {
	aggro = "Interface\\AddOns\\Fragile\\Sounds\\aggro.wav",
	BellTollAlliance = "Sound\\Doodad\\BellTollAlliance.wav",
	bell = "Sound\\interface\\AuctionWindowClose.wav",
}

-------------------------------------------------------------------------------
-- Addon declaration                                                         --
-------------------------------------------------------------------------------

Fragile = AceLibrary("AceAddon-2.0"):new("AceConsole-2.0", "AceDB-2.0", "AceEvent-2.0", "Sink-1.0")
local Fragile = Fragile

local options = {
	type = "group",
	name = L["Fragile"],
	desc = L["Options for aggro indication."],
	handler = Fragile,
	pass = true,
	get = function(key)
		return Fragile.db.profile[key]
	end,
	set = function(key, value)
		Fragile.db.profile[key] = value
	end,
	func = function(key)
		Fragile:Print("Because of a Dewdrop bug, this option is not available.")
	end,
	args = {
		gui = {
			type = "execute",
			name = L["Options Window"],
			desc = L["Shows the Options Window"],
			func = function()
				if Waterfall then
					Waterfall:Open("Fragile")
				else
					Fragile:Print(L["Waterfall-1.0 is required to access the GUI."])
				end
			end,
		},
		alert = {
			type = "toggle",
			name = L["Sound alert"],
			desc = L["Sound alert on member aggro."],
			order = 1,
		},
		sound = {
			type = "text",
			name = L["Sound"],
			desc = L["Select default sound."],
			order = 2,
		},
		combattext = {
			type = "toggle",
			name = L["Announce"],
			desc = L["Print a combat text announcement on member aggro."],
			order = 3,
		},
		glow = {
			type = "toggle",
			name = L["Glow"],
			desc = L["Party frame glow on member aggro."],
			order = 4,
		},
	},
}

-------------------------------------------------------------------------------
-- Initialization                                                            --
-------------------------------------------------------------------------------

function Fragile:OnInitialize()
	if sml then
		sml:Register("sound", "Fragile: Aggro", sounds.aggro)
		sml:Register("sound", "Fragile: Ship Bell", sounds.BellTollAlliance)
		sml:Register("sound", "Fragile: Auction Close", sounds.bell)

		options.args.sound.validate = sml:List("sound")
	else
		options.args.sound.validate = {
			aggro = "Aggro",
			BellTollAlliance = "BellTollAlliance",
			bell = "Bell",
			none = L["None"],
		}
	end

	self:RegisterDB("FragileDB")
	self:RegisterDefaults("profile", {
		alert = true,
		glow = true,
		combattext = true,
		sound = "aggro",
	})
	self:RegisterChatCommand("/fragile", options, "FRAGILE")

	if Waterfall then
		Waterfall:Register("Fragile",
		"aceOptions", options,
		"title", L["Fragile Options"],
		"colorR",1.0,
		"colorG",0.4,
		"colorB",0.0)
	end
	
	if sml then
		if type(self.db.profile.sound) ~= "string" or not sml:Fetch("sound", self.db.profile.sound, true) then
			self.db.profile.sound = "Fragile: Aggro"
		end
	else
		if self.db.profile.sound ~= L["None"] and not sounds[self.db.profile.sound] then
			self.db.profile.sound = "aggro"
		end
	end
end


function Fragile:OnEnable()
	lastAggroAlert = nil

	playerName = UnitName("player")

	if UnitExists("party1") and GetNumRaidMembers() == 0 then
		self:RegisterEvent("Banzai_UnitGainedAggro")
		self:RegisterEvent("Banzai_UnitLostAggro")
	end

	self:RegisterEvent("PARTY_MEMBERS_CHANGED", "IsGrouped")
	self:RegisterEvent("ADDON_LOADED")
	self:RegisterEvent("Banzai_Disabled")
end

-------------------------------------------------------------------------------
-- Addon methods                                                             --
-------------------------------------------------------------------------------

function Fragile:IsGrouped()
	if not UnitExists("party1") or GetNumRaidMembers() > 0 then
		if self:IsEventRegistered("Banzai_UnitGainedAggro") then
			self:UnregisterEvent("Banzai_UnitGainedAggro")
			self:UnregisterEvent("Banzai_UnitLostAggro")
		end	
	elseif not self:IsEventRegistered("Banzai_UnitGainedAggro") then
		self:RegisterEvent("Banzai_UnitGainedAggro")
		self:RegisterEvent("Banzai_UnitLostAggro")
	end
end

-------------------------------------------------------------------------------
-- Events                                                                    --
-------------------------------------------------------------------------------

function Fragile:ADDON_LOADED()
	
end

function Fragile:Banzai_UnitGainedAggro( unitId )
	if (GetNumPartyMembers() == 0) or (GetNumRaidMembers() > 0) then
		return
	end

	if not lastAggroAlert or (GetTime() - lastAggroAlert) > 5 then
		for i=1, GetNumPartyMembers() do
			partyunit = "party"..i
			if partyunit == unitId then 
				Fragile_partyid = i;
				if self.db.profile.combattext then
					local class, eclass = UnitClass(partyunit);
					local name = UnitName(partyunit);
					local binding = "TARGETPARTYMEMBER"..i;
					local key,_ = GetBindingKey(binding) or " ";
					local classcolor = string.format("|cff%02x%02x%02x",RAID_CLASS_COLORS[eclass].r*255,RAID_CLASS_COLORS[eclass].g*255,RAID_CLASS_COLORS[eclass].b*255);
					local msg = L["Aggro on "]..">>"..classcolor..name.."|r<< ".."("..key..")";
					self:Pour(msg, 1.0, 0.0, 0.0)
				end
				if self.db.profile.alert then
					if sml and type(self.db.profile.sound) == "string" then
---						PlaySound("GAMEHIGHLIGHTFRIENDLYUNIT") --- Driizt soundfix 2.2
						PlaySoundFile(sml:Fetch("sound", self.db.profile.sound))
					else
						if self.db.profile.sound ~= L["None"] and sounds[self.db.profile.sound] then
							local sound = sounds[self.db.profile.sound]
							if sound:find("%\\") then
---								PlaySound("GAMEHIGHLIGHTFRIENDLYUNIT") --- Driizt soundfix 2.2
								PlaySoundFile(sound)
							else
								PlaySound(sound)
							end
						end
					end
				end
				if self.db.profile.glow then
					local flashframe = getglobal("PartyMemberFrame"..i.."Flash");
					flashframe:Show();
				end
			end
		end
		lastAggroAlert = GetTime()
	end
end

function Fragile:Banzai_UnitLostAggro( unitId )
	if GetNumPartyMembers() == 0 or (GetNumRaidMembers() > 0) then
		return
	end

	for i=1, GetNumPartyMembers() do
		partyunit = "party"..i
		if partyunit == unitId then
			Fragile_partyid = i;
			local flashframe = getglobal("PartyMemberFrame"..i.."Flash");
			flashframe:Hide();
		end
	end
end

function Fragile:Banzai_Disabled()
	if self:IsEventRegistered("Banzai_UnitGainedAggro") then
			self:UnregisterEvent("Banzai_UnitGainedAggro")
			self:UnregisterEvent("Banzai_UnitLostAggro")
	end	
end

-------------------------------------------------------------------------------
-- Cleanup                                                                   --
-------------------------------------------------------------------------------

function Fragile:OnDisable()
	for i=1, GetNumPartyMembers() do
		local flashframe = getglobal("PartyMemberFrame"..i.."Flash");
		if flashframe:IsShown() then
			flashframe:Hide();
		end
	end
	self:UnregisterAllEvents()
---	self:UnhookAll()
end