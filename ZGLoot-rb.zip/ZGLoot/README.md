# ZGLoot
Modified addon ZgLoot. Now you can automate looting of scarabs and idols in AQ 20 and AQ 40 too. Also have some nice options, like work with roll messages, and looting items from trash.
