local tablet = TabletLib:GetInstance('1.0')

FuBar_TinyPad = FuBarPlugin:new({
	name          = FuBar_TinyPadLocals.NAME,
	description   = FuBar_TinyPadLocals.DESCRIPTION,
	version       = "1.2",
	releaseDate   = "06-24-2006",
	aceCompatible = 103,
      fuCompatible  = 102,
	author        = "Knigitz",
	email         = "knigitz@gmail.com",
	category      = "other",
	db            = AceDatabase:new("TinyPadFuDB"),
	defaults      = DEFAULT_OPTIONS,
	cmd           = AceChatCmd:new({},{}),
	hasNoText     = TRUE,
	showOnRight   = TRUE,
	loc           = FuBar_TinyPadLocals,
	hasIcon       = "Interface\\AddOns\\FuBar_TinyPadFu\\TinyPad-Icon.tga",
	cannotDetachTooltip = TRUE,
})

function FuBar_TinyPad:OnClick()
  TinyPad.Toggle()
end

function FuBar_TinyPad:UpdateTooltip()
	tablet:SetHint(self.loc.TEXT_HINT)
end

FuBar_TinyPad:RegisterForLoad()
