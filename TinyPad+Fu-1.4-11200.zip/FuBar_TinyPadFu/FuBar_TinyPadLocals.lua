if not ace:LoadTranslation("FuBar_TinyPadLocals") then
		
FuBar_TinyPadLocals = {
	NAME = "FuBar - TinyPadFu",
	DESCRIPTION = "Toggle TinyPad",
	TEXT_HINT = "Click to toggle TinyPad."
}

end