-- Global
NefTimer = 0
BagNum = 3
SlotNum = 15

local nccm_test = false
function NCCM_OnLoad(event)
  this:RegisterEvent("CHAT_MSG_MONSTER_EMOTE")
  this:RegisterEvent("CHAT_MSG_MONSTER_YELL")

  DEFAULT_CHAT_FRAME:AddMessage("Nefarian Class Call Mod for Hunters loaded. Type /nccm for info.")

  SlashCmdList["NCCMHELP"] = NCCM_Help
  SLASH_NCCMHELP1 = "/nccm"

  SlashCmdList["NCCMSCAN"] = NCCM_Scan
  SLASH_NCCMSCAN1 = "/nccmscan"

  SlashCmdList["NCCMBAG"] = NCCM_Bag
  SLASH_NCCMBAG1 = "/nccmbag"  

  SlashCmdList["NCCMSLOT"] = NCCM_Slot
  SLASH_NCCMSLOT1 = "/nccmslot"

  SlashCmdList["NCCMTEST"] = NCCM_Test
  SLASH_NCCMTEST1 = "/nccmtest" 

  this:RegisterEvent("VARIABLES_LOADED")
end

function NCCM_Help(msg)
	if (msg == "") then	
		DEFAULT_CHAT_FRAME:AddMessage("Nefarian Class Call Mod for Hunters")
		DEFAULT_CHAT_FRAME:AddMessage("Type /nccmbag [bag number] to assign bag number")
		DEFAULT_CHAT_FRAME:AddMessage("Type /nccmslot [slot number] to assign slot number")
		DEFAULT_CHAT_FRAME:AddMessage("Currently using bag #"..NCCMConfig["BagNum"].." slot #"..NCCMConfig["SlotNum"]..".")
    DEFAULT_CHAT_FRAME:AddMessage("Type /nccmscan while hovering a slot in bag to get bag and slot info")
    DEFAULT_CHAT_FRAME:AddMessage("Type /nccmtest to test the swap")
	end
end

function NCCM_Scan()
  local slotframe = GetMouseFocus()
  local slot, bag
  slot = (slotframe) and type(slotframe.IsFrameType == "function") and slotframe:IsFrameType("Button") and slotframe:GetID()
  if (slot) then
    bag = slotframe:GetParent():GetID()
  end
  if (slot) and (bag) then
    DEFAULT_CHAT_FRAME:AddMessage("bag:"..bag..", slot:"..slot)
  end
end

function NCCM_Bag(msg)
	if (msg == "") then	
		return
	else
		NCCMConfig["BagNum"] = msg
		DEFAULT_CHAT_FRAME:AddMessage("Nefarian Class Call Mod for Hunters")
		DEFAULT_CHAT_FRAME:AddMessage("Currently using bag #"..NCCMConfig["BagNum"].." slot #"..NCCMConfig["SlotNum"]..".")
	end
end

function NCCM_Slot(msg)
	if (msg == "") then	
		return
	else
		NCCMConfig["SlotNum"] = msg
		DEFAULT_CHAT_FRAME:AddMessage("Nefarian Class Call Mod for Hunters")
		DEFAULT_CHAT_FRAME:AddMessage("Currently using bag #"..NCCMConfig["BagNum"].." slot #"..NCCMConfig["SlotNum"]..".")
	end
end

function NCCM_OnEvent()
  if (event == "VARIABLES_LOADED") then
	if (not NCCMConfig) then
		NCCMConfig = {}
		NCCMConfig["BagNum"] = BagNum
		NCCMConfig["SlotNum"] = SlotNum
	end

  end

  if (event == "CHAT_MSG_MONSTER_EMOTE" or event == "CHAT_MSG_MONSTER_YELL") then
  local classcall = false
	local nefland = false

	-- Phase 2 starts (landing)
	if (string.find(arg1, "BURN! You wretches")) then
      nefland = true
    -- test
    elseif (string.find(arg1, "I can sense")) then
      nefland = true
    -- Shamans
    elseif (string.find(arg1, "Shamans, show me")) then
      classcall = true
    -- Druids
    elseif (string.find(arg1, "Druids and your silly")) then
      classcall = true
    -- Priests
    elseif (string.find(arg1, "Priests! If you're going to keep")) then
      classcall = true
    -- Warriors
    elseif (string.find(arg1, "Warriors, I know you can hit harder")) then
      classcall = true
    -- Rogue
    elseif (string.find(arg1, "Rogues%? Stop hiding")) then
      classcall = true
    -- Warlocks
    elseif (string.find(arg1, "Warlocks, you shouldn't be playing")) then
      classcall = true
    -- Paladins
    elseif (string.find(arg1, "Paladins")) then
      classcall = true
    -- Hunters
    elseif (string.find(arg1, "Hunters and your annoying")) then
      classcall = true
    -- Mages
    elseif (string.find(arg1, "Mages too%?")) then
      classcall = true
    end

    if ((classcall == false) and (nefland == false)) then
      return
    end

	if (classcall == true) then
      DEFAULT_CHAT_FRAME:AddMessage("[NCCM]: Class Called")
      NCCM_Equip()
	elseif (nefland == true) then
	  DEFAULT_CHAT_FRAME:AddMessage("[NCCM]: Nefarian Landed")
	end
    NefTimer = 25
  end
end

function NCCM_Test()
  if not nccmtest then
    nccmtest = true
    NCCM_Unequip()
  else
    nccmtest = false
    NCCM_Equip()
  end
end

function NCCM_Equip()
  DEFAULT_CHAT_FRAME:AddMessage("[NCCM]: Swapping back to DPS ranged weapon")

  PickupContainerItem(NCCMConfig["BagNum"], NCCMConfig["SlotNum"])
  PickupInventoryItem(18)
  if (CursorHasItem()) then
    DEFAULT_CHAT_FRAME:AddMessage("[NCCM]: Swap failed")
    PickupContainerItem(NCCMConfig["BagNum"], NCCMConfig["SlotNum"])
  end
end

function NCCM_Unequip()
  DEFAULT_CHAT_FRAME:AddMessage("[NCCM]: Swapping to backup ranged weapon before class call")

  PickupInventoryItem(18)
  PickupContainerItem(NCCMConfig["BagNum"], NCCMConfig["SlotNum"])
end

function NCCM_OnUpdate(elapsed)
  if (NefTimer > 0) then
    if (NefTimer > elapsed) then
      NefTimer = NefTimer - elapsed
      return
    else
      NefTimer = 0
      NCCM_Unequip()
    end
  end
end
