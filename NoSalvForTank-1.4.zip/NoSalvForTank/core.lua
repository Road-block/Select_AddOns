local GetShapeshiftFormInfo, UnitBuff, UnitClass, GetPlayerBuff, CancelPlayerBuff, GetPlayerBuffTexture, GetInventoryItemLink, GetItemInfo, gsub, format = 
GetShapeshiftFormInfo, UnitBuff, UnitClass, GetPlayerBuff, CancelPlayerBuff, GetPlayerBuffTexture, GetInventoryItemLink, GetItemInfo, string.gsub, string.format
local Tank = {WARRIOR = 2, DRUID = 1, PALADIN = "Spell_Holy_SealOfFury"}
local offhandslot = GetInventorySlotInfo("SecondaryHandSlot")
local _, class = UnitClass("player")
if not Tank[class] then return end
local Unwanted = {
  Spell_Holy_GreaterBlessingofSalvation = "Salvation", 
  Spell_Holy_SealOfSalvation = "Salvation", 
  Spell_Holy_SealOfProtection = "Blessing of Protection",
  -- debug
  --Spell_Holy_Renew = "Renew",
  --Spell_Holy_Excorcism = "Fearward",
  --Spell_Holy_WordFortitude = "Fortitude",
}

local addon = CreateFrame("Frame")
addon.eventManager = function()
  return this[event]~=nil and this[event](this,event,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11)
end
addon:SetScript("OnEvent",addon.eventManager)
addon:RegisterEvent("PLAYER_AURAS_CHANGED")

function addon:IsTanking(class)
  local _,tanking
  if type(Tank[class])=="number" then
    _,_,tanking = GetShapeshiftFormInfo(Tank[class])
    return (tanking) and true or false
  else
    local buffIndex
    for buffId = 0, MAX_PARTY_TOOLTIP_BUFFS-1 do
      buffIndex = GetPlayerBuff(buffId, "HELPFUL|CANCELABLE")
      local buffTexture, hasShield
      if buffIndex ~= -1 then
        buffTexture = gsub((GetPlayerBuffTexture(buffIndex)),"Interface\\Icons\\","")
        if buffTexture == Tank[class] then
          local offhandlink = GetInventoryItemLink("player", offhandslot)
          if (offhandlink) then
            local link_found, _, itemColor, itemString, itemName = string.find(offhandlink, "^(|c%x+)|H(.+)|h(%[.+%])")
            if (link_found) then
              _,_,_,_,_,tanking = GetItemInfo(itemString)
              return (tanking=="Shields") and true or false
            end
          end
        end
      end
    end
  end
end

function addon:PLAYER_AURAS_CHANGED(event,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9)
  local tanking = self:IsTanking(class)
  if (tanking) then
    local buffId = 0
    local buffIndex = GetPlayerBuff(buffId, "HELPFUL|CANCELABLE")
    while (buffIndex ~= -1) do
      local buffTexture = GetPlayerBuffTexture(buffIndex)
      if (buffTexture) then
        local unwanted = Unwanted[gsub(buffTexture,"Interface\\Icons\\","")]
        if (unwanted) then
          CancelPlayerBuff(buffIndex)
          UIErrorsFrame:AddMessage(format("Removed %s!",unwanted),0,1,0,1,2)
          return
        end
      end
      buffId = buffId + 1
      buffIndex = GetPlayerBuff(buffId, "HELPFUL|CANCELABLE")
    end
  end
end

--[[
for debugging
  --Spell_Nature_AncestralGuardian = "Berserker Rage", 
  --Ability_Racial_BloodRage = "Bloodrage", 
  --Ability_Warrior_BattleShout = "Battle Shout", 
]]