DeProfundis_GP = {
	-----------------
	--- Naxxramas ---
	-----------------
Item23226 = "104"; --Ghoul Skin Tunic
Item23663 = "48"; --Girdle of Elemental Fury
Item23044 = "116"; --Harbinger of Doom
Item23665 = "48"; --Leggings of Elemental Fury
Item23221 = "100"; --Misplaced Servo Arm
Item23069 = "18"; --Necro-knight Garb
Item23664 = "48"; --Pauldrons of Elemental Fury
Item23237 = "60"; --Ring of Eternal Flame
Item23238 = "40"; --Stygian Buckler

Item22939 = "72"; --Band of Unanswered Prayers
Item22938 = "96"; --Cryptfiend Silk Cloak
Item22937 = "48"; --Gem of Nerubis
Item22935 = "4"; --Touch of Frost
Item22936 = "72"; --Wristguards of Vengeance
Item22369 = "84"; --T3 Wrist Token
Item22362 = "84"; --T3 Wrist Token
Item22355 = "84"; --T3 Wrist Token

Item22940 = "4"; --Icebane Pauldrons
Item22943 = "60"; --Malice Stone Pendant
Item22941 = "4"; --Polar Shoulderpads
Item22942 = "116"; --The Widow's Embrace
Item22806 = "116"; --Widow's Remorse

Item23220 = "132"; --Crystal Webbed Robe
Item22954 = "116"; --Kiss of the Spider
Item22804 = "116"; --Maexxna's Fang
Item22947 = "24"; --Pendant of Forgotten Names
Item22807 = "152"; --Wraith Blade
Item22371 = "96"; --T3 Gloves Token
Item22364 = "96"; --T3 Gloves Token
Item22357 = "96"; --T3 Gloves Token

Item22961 = "80"; --Band of Reanimation
Item22960 = "96"; --Cloak of Suturing
Item22815 = "88"; --Severance
Item22818 = "92"; --The Plague Bearer
Item22820 = "72"; --Wand of Fates
Item22368 = "100"; --T3 Shoulder Token
Item22361 = "100"; --T3 Shoulder Token
Item22354 = "100"; --T3 Shoulder Token

Item22968 = "4"; --Glacial Mantle
Item22967 = "4"; --Icy Scale Spaulders
Item22803 = "80"; --Midnight Haze
Item22988 = "152"; --The End of Dreams
Item22810 = "44"; --Toxin Injector

Item22813 = "72"; --Claymore of Unholy Might
Item23075 = "80"; --Death's Bargain
Item22994 = "24"; --Digested Hand of Power
Item22981 = "52"; --Gluth's Missing Collar
Item22983 = "112"; --Rime Covered Mantle

Item23001 = "96"; --Eye of Diminution
Item23070 = "136"; --Leggings of Polarity
Item23000 = "136"; --Plated Abomination Ribcage
Item22801 = "140"; --Spire of Twilight
Item22808 = "116"; --The Castigator
Item22367 = "120"; --T3 Helm Token
Item22360 = "120"; --T3 Helm Token
Item22353 = "120"; --T3 Helm Token

Item23031 = "76"; --Band of the Inevitable
Item23030 = "68"; --Cloak of the Scourge
Item23028 = "16"; --Hailstone Band
Item22816 = "136"; --Hatchet of Sundered Bone
Item23029 = "60"; --Noth's Frigid Heart
Item23005 = "68"; --Totem of Flowing Water
Item22370 = "92"; --T3 Belt Token
Item22363 = "92"; --T3 Belt Token
Item22356 = "92"; --T3 Belt Token

Item23019 = "4"; --Icebane Helmet
Item23033 = "4"; --Icy Scale Coif
Item23068 = "124"; --Legplates of Carnage
Item23036 = "72"; --Necklace of Necropsy
Item23035 = "112"; --Preceptor's Hat

Item23038 = "88"; --Band of Unnatural Forces
Item22800 = "160"; --Brimstone Staff
Item23042 = "12"; --Loatheb's Reflection
Item23037 = "24"; --Ring of Spiritual Fervor
Item23039 = "132"; --The Eye of Nerub
Item22366 = "136"; --T3 Pants Token
Item22359 = "136"; --T3 Pants Token
Item22352 = "136"; --T3 Pants Token

Item23017 = "48"; --Veil of Eclipse
Item23219 = "124"; --Girdle of the Mentor
Item23014 = "120"; --Iblis, Blade of the Fallen Seraph
Item23009 = "72"; --Wand of the Whispering Dead
Item23018 = "84"; --Signets of the Fallen Defender
Item23004 = "48"; --Idol of Longevity
Item22372 = "92"; --T3 Boots Token
Item22365 = "92"; --T3 Boots Token
Item22358 = "92"; --T3 Boots Token

Item23073 = "32"; --Boots of Displacement
Item23032 = "4"; --Glacial Headdress
Item23020 = "4"; --Polar Helmet
Item23021 = "96"; --The Soul Harvester's Bindings
Item23023 = "48"; --Sadist's Collar

Item22691 = "200"; --Corrupted Ashbringer
Item22811 = "172"; --Soulstring
Item22809 = "60"; --Maul of the Redeemed Crusader
Item23071 = "144"; --Leggings of Apocalypse
Item23025 = "92"; --Seal of the Damned
Item23027 = "96"; --Warmth of Forgiveness
Item22351 = "148"; --T3 Chest Token
Item22350 = "148"; --T3 Chest Token
Item22349 = "148"; --T3 Chest Token

Item23050 = "160"; --Cloak of the Necropolis
Item23045 = "160"; --Shroud of Dominion 
Item23043 = "150"; --The Face of Death
Item23242 = "180"; --Claw of the Frost Wyrm 
Item23049 = "160"; --Sapphiron's Left Eye 
Item23048 = "160"; --Sapphiron's Right Eye
Item23040 = "160"; --Glyph of Deflection
Item23047 = "160"; --Eye of the Dead
Item23046 = "160"; --The Restrained Essence of Sapphiron
Item23041 = "160"; --Slayer's Crest 
Item23548 = "80"; --Might of the Scourge
Item23545 = "80"; --Power of the Scourge
Item23547 = "80"; --Resilience of the Scourge
Item23549 = "120"; --Fortitude of the Scourge

Item22802 = "200"; --Kingsfall
Item23054 = "200"; --Gressil, Dawn of Ruin
Item23577 = "200"; --The Hungering Cold 
Item23056 = "240"; --Hammer of the Twisting Nether
Item22798 = "300"; --Might of Menethil
Item22799 = "300"; --Soulseeker 
Item22821 = "116"; --Doomfinger 
Item22812 = "300"; --Nerubian Slavemaker
Item22819 = "180"; --Shield of Condemnation 
Item23057 = "140"; --Gem of Trapped Innocents 
Item23053 = "140"; --Stormrage's Talisman of Seething 
Item22520 = "0"; --The Phylactery of Kel'Thuzad 
Item22733 = "400"; --Staff Head of Atiesh

Item22490 = "120"; --Dreamwalker Raiment
Item22491 = "100"; --Dreamwalker Raiment
Item22488 = "148"; --Dreamwalker Raiment
Item22495 = "84"; --Dreamwalker Raiment
Item22493 = "96"; --Dreamwalker Raiment
Item22494 = "92"; --Dreamwalker Raiment
Item22489 = "136"; --Dreamwalker Raiment
Item22492 = "92"; --Dreamwalker Raiment
Item23064 = "1337"; --Dreamwalker Raiment

Item22438 = "120"; --Cryptstalker Armor
Item22439 = "100"; --Cryptstalker Armor
Item22436 = "148"; --Cryptstalker Armor
Item22443 = "84"; --Cryptstalker Armor
Item22441 = "96"; --Cryptstalker Armor
Item22442 = "92"; --Cryptstalker Armor
Item22437 = "136"; --Cryptstalker Armor
Item22440 = "92"; --Cryptstalker Armor
Item23067 = "1337"; --Cryptstalker Armor

Item22498 = "120"; --Frostfire Regalia
Item22499 = "100"; --Frostfire Regalia
Item22496 = "148"; --Frostfire Regalia
Item22503 = "84"; --Frostfire Regalia
Item22501 = "96"; --Frostfire Regalia
Item22502 = "92"; --Frostfire Regalia
Item22497 = "136"; --Frostfire Regalia
Item22500 = "92"; --Frostfire Regalia
Item23062 = "1337"; --Frostfire Regalia

Item22514 = "120"; --Vestments of Faith
Item22515 = "100"; --Vestments of Faith
Item22512 = "148"; --Vestments of Faith
Item22519 = "84"; --Vestments of Faith
Item22517 = "96"; --Vestments of Faith
Item22518 = "92"; --Vestments of Faith
Item22513 = "136"; --Vestments of Faith
Item22516 = "92"; --Vestments of Faith
Item23061 = "1337"; --Vestments of Faith

Item22478 = "120"; --Bonescythe Armor
Item22479 = "100"; --Bonescythe Armor
Item22476 = "148"; --Bonescythe Armor
Item22483 = "84"; --Bonescythe Armor
Item22481 = "96"; --Bonescythe Armor
Item22482 = "92"; --Bonescythe Armor
Item22477 = "136"; --Bonescythe Armor
Item22480 = "92"; --Bonescythe Armor
Item23060 = "1337"; --Bonescythe Armor

Item22466 = "120"; --The Earthshatterer
Item22467 = "100"; --The Earthshatterer
Item22464 = "148"; --The Earthshatterer
Item22471 = "84"; --The Earthshatterer
Item22469 = "96"; --The Earthshatterer
Item22470 = "92"; --The Earthshatterer
Item22465 = "136"; --The Earthshatterer
Item22468 = "92"; --The Earthshatterer
Item23065 = "1337"; --The Earthshatterer

Item22506 = "120"; --Plaguehart Raiment
Item22507 = "100"; --Plaguehart Raiment
Item22504 = "148"; --Plaguehart Raiment
Item22511 = "84"; --Plaguehart Raiment
Item22509 = "96"; --Plaguehart Raiment
Item22510 = "92"; --Plaguehart Raiment
Item22505 = "136"; --Plaguehart Raiment
Item22508 = "92"; --Plaguehart Raiment
Item23063 = "1337"; --Plaguehart Raiment

Item22418 = "120"; --Dreadnaught's Battlegear
Item22419 = "100"; --Dreadnaught's Battlegear
Item22416 = "148"; --Dreadnaught's Battlegear
Item22423 = "84"; --Dreadnaught's Battlegear
Item22421 = "96"; --Dreadnaught's Battlegear
Item22422 = "92"; --Dreadnaught's Battlegear
Item22417 = "136"; --Dreadnaught's Battlegear
Item22420 = "92"; --Dreadnaught's Battlegear
Item23059 = "1337"; --Dreadnaught's Battlegear

	---------------------------
	--- Temple of Ahn'Qiraj ---
	---------------------------
	
Item21837 = "40"; --Anubisath Warhammer
Item21838 = "4"; --Garb of Royal Ascension
Item21888 = "8"; --Gloves of the Immortal
Item21889 = "0"; --Gloves of the Redeemed Prophet
Item21856 = "16"; --Neretzek, The Blood Drinker
Item21836 = "44"; --Ritssyn's Ring of Chaos
Item21891 = "64"; --Shard of the Fallen Star

Item21702 = "4"; --Amulet of Foul Warding
Item21699 = "36"; --Barrage Shoulders
Item21708 = "4"; --Beetle Scaled Wristguards
Item21705 = "12"; --Boots of the Fallen Prophet
Item21706 = "28"; --Boots of the Unwavering Will
Item21814 = "92"; --Breastplate of Annihilation
Item21701 = "88"; --Cloak of the Concentrated Hatred
Item21703 = "24"; --Hammer of Ji'zhi
Item21698 = "40"; --Leggings of Immersion
Item21700 = "24"; --Pendant of the Qiraji Guardian
Item21707 = "48"; --Ring of Swarming Thought
Item21128 = "52"; --Staff of the Qiraji Prophets
Item21232 = "116"; --Imperial Qiraji Armaments
Item21242 = "116"; --Imperial Qiraji Armaments
Item21272 = "116"; --Imperial Qiraji Armaments
Item21244 = "116"; --Imperial Qiraji Armaments
Item21269 = "116"; --Imperial Qiraji Armaments
Item21237 = "84"; --Imperial Qiraji Regalia
Item21273 = "84"; --Imperial Qiraji Regalia
Item21275 = "84"; --Imperial Qiraji Regalia
Item21268 = "84"; --Imperial Qiraji Regalia

Item21695 = "80"; --Angelista's Touch
Item21697 = "4"; --Cape of the Trinity
Item21693 = "60"; --Guise of the Devourer
Item21696 = "4"; --Robes of the Triumvirate
Item21694 = "60"; --Ternary Mantle
Item21692 = "32"; --Triad Girdle

Item21690 = "48"; --Angelista's Charm
Item21688 = "68"; --Boots of the Fallen Hero
Item21689 = "60"; --Gloves of Ebru
Item21691 = "4"; --Ooze-ridden Gauntlets

Item21685 = "4"; --Petrified Scarab
Item21681 = "64"; --Ring of the Devoured
Item21680 = "56"; --Vest of Swift Execution
Item21603 = "56"; --Wand of the Qiraji Nobility

Item21682 = "4"; --Bile-Covered Gauntlets
Item21686 = "40"; --Mantle of Phrenic Power
Item21683 = "0"; --Mantle of the Desert Crusade
Item21684 = "4"; --Mantle of the Desert's Fury
Item21687 = "4"; --Ukko's Ring of Darkness

Item21670 = "44"; --Badge of the Swarmguard
Item21669 = "48"; --Creeping Vine Helm
Item21674 = "64"; --Gauntlets of Steadfast Determ..
Item21672 = "64"; --Gloves of Enforcement
Item21667 = "0"; --Legplates of Blazing Light
Item21676 = "32"; --Leggings of the Festering Swa..
Item21678 = "4"; --Necklace of Purity
Item21648 = "4"; --Recomposed Boots
Item21671 = "48"; --Robes of the Battleguard
Item21666 = "88"; --Sartura's Might
Item21668 = "20"; --Scaled Leggings of Qiraji Fury
Item21673 = "32"; --Silithid Claw
Item21675 = "60"; --Thick Qirajihide Belt

Item21650 = "112"; --Ancient Qiraji Ripper
Item21664 = "80"; --Barbed Choker
Item21635 = "104"; --Barb of the Sand Reaver
Item21627 = "4"; --Cloak of Untold Secrets
Item21647 = "28"; --Fetish of the Sand Reaver
Item21645 = "60"; --Hive Tunneler's Boots
Item22402 = "0"; --Libram of Grace
Item21665 = "72"; --Mantle of Wicked Revenge
Item21639 = "76"; --Pauldrons of the Unrelenting
Item21663 = "136"; --Robes of the Guardian Saint
Item21651 = "52"; --Scaled Sand Reaver Leggings
Item21652 = "4"; --Silithid Carapace Chestguard
Item22396 = "4"; --Totem of Life

Item21623 = "0"; --Gauntlets of the Right. Champ
Item21624 = "48"; --Gauntlets of Kalimdor
Item22399 = "68"; --Idol of Health
Item21677 = "56"; --Ring of the Qiraji Fury
Item21625 = "48"; --Scarab Brooch
Item21622 = "100"; --Sharpened Silithid Femur
Item21626 = "4"; --Slime-coated Leggings

Item20928 = "68"; --Qiraji Bindings of Command
Item20932 = "68"; --Qiraji Bindings of Dominance

Item21621 = "40"; --Cloak of the Golden Hive
Item21619 = "44"; --Gloves of the Messiah
Item21618 = "24"; --Hive Defiler Wristguards
Item21616 = "52"; --Huhuran's Stinger
Item21620 = "80"; --Ring of the Martyr
Item21617 = "64"; --Wasphide Gauntlets

Item21608 = "80"; --Amulet of Vek'nilash
Item21606 = "0"; --Belt of the Fallen Emperor
Item21600 = "88"; --Boots of Epiphany
Item21604 = "80"; --Bracelets of Royal Redemption
Item21605 = "60"; --Gloves of the Hidden Temple
Item21607 = "20"; --Grasp of the Fallen Emperor
Item21679 = "48"; --Kalimdor's Revenge
Item21609 = "52"; --Regenerating Belt of Vek'nilash
Item21601 = "80"; --Ring of Emperor Vek'lor
Item21597 = "88"; --Royal Scepter of Vek'lor
Item21598 = "84"; --Royal Qiraji Belt
Item21599 = "68"; --Vek'lor's Gloves of Devastation
Item21602 = "88"; --Qiraji Execution Bracers

Item20926 = "72"; --Vek'nilash's Circlet
Item20930 = "72"; --Vek'lor's Diadem

Item21611 = "48"; --Burrower Bracers
Item21615 = "88"; --Don Rigoberto's Lost Hat
Item23570 = "80"; --Jom Gabbar
Item23557 = "128"; --Larvae of the Great Worm
Item23558 = "24"; --The Burrower's Shell
Item21610 = "88"; --Wormscale Blocker

Item20927 = "76"; --Ouro's Intact Hide
Item20931 = "76"; --Skin of the Great Sandworm

Item21586 = "124"; --Belt of Never-ending Agony
Item21583 = "116"; --Cloak of Clarity
Item22731 = "116"; --Cloak of the Devoured
Item21134 = "172"; --Dark Edge of Insanity
Item21585 = "132"; --Dark Storm Gauntlets
Item21126 = "152"; --Death's Sting
Item22730 = "124"; --Eyestalk Waist Cord
Item21581 = "116"; --Gauntlets of Annihilation
Item21582 = "124"; --Grasp of the Old God
Item22732 = "116"; --Mark of C'thun
Item21596 = "104"; --Ring of the Godslayer
Item21839 = "180"; --Scepter of the False Prophet
Item21579 = "44"; --Vanquished Tentacle of C'thun

Item21221 = "96"; --Eye of C'thun
Item21712 = "96"; --Eye of C'thun
Item21710 = "96"; --Eye of C'thun
Item21709 = "96"; --Eye of C'thun
Item20929 = "128"; --Carapace of the Old God
Item20933 = "128"; --Husk of the Old God

Item21357 = "128"; --Genesis Raiment
Item21353 = "72"; --Genesis Raiment
Item21356 = "76"; --Genesis Raiment
Item21354 = "68"; --Genesis Raiment
Item21355 = "68"; --Genesis Raiment

Item21370 = "128"; --Striker's Garb
Item21366 = "72"; --Striker's Garb
Item21368 = "76"; --Striker's Garb
Item21367 = "68"; --Striker's Garb
Item21365 = "68"; --Striker's Garb

Item21343 = "128"; --Enigma Vestments
Item21347 = "72"; --Enigma Vestments
Item21346 = "76"; --Enigma Vestments
Item21345 = "68"; --Enigma Vestments
Item21344 = "68"; --Enigma Vestments

Item21351 = "128"; --Garments of the Oracle
Item21348 = "72"; --Garments of the Oracle
Item21352 = "76"; --Garments of the Oracle
Item21350 = "68"; --Garments of the Oracle
Item21349 = "68"; --Garments of the Oracle

Item21364 = "128"; --Deathdealer's Embrace
Item21360 = "72"; --Deathdealer's Embrace
Item21362 = "76"; --Deathdealer's Embrace
Item21361 = "68"; --Deathdealer's Embrace
Item21359 = "68"; --Deathdealer's Embrace

Item21374 = "128"; --Stormcaller's Garb
Item21372 = "72"; --Stormcaller's Garb
Item21375 = "76"; --Stormcaller's Garb
Item21376 = "68"; --Stormcaller's Garb
Item21373 = "68"; --Stormcaller's Garb

Item21334 = "128"; --Doomcaller's Attire
Item21337 = "72"; --Doomcaller's Attire
Item21336 = "76"; --Doomcaller's Attire
Item21335 = "68"; --Doomcaller's Attire
Item21338 = "68"; --Doomcaller's Attire

Item21331 = "128"; --Conqueror's Battlegear
Item21329 = "72"; --Conqueror's Battlegear
Item21332 = "76"; --Conqueror's Battlegear
Item21330 = "68"; --Conqueror's Battlegear
Item21333 = "68"; --Conqueror's Battlegear

	----------------------
	--- Blackwing Lair ---
	----------------------

Item19434 = "40"; --Band of Dark Dominion
Item19437 = "48"; --Boots of Pure Thought
Item19436 = "16"; --Cloak of Draconic Might
Item19362 = "32"; --Doom's Edge
Item19354 = "16"; --Draconic Avenger
Item19358 = "12"; --Draconic Maul
Item19435 = "8"; --Essence Gatherer
Item19439 = "4"; --Interlaced Shadow Jerkin
Item19438 = "48"; --Ringo's Blizzard Boots

Item19336 = "16"; --Arcane Infused Gem
Item19369 = "16"; --Gloves of Rapid Evolution
Item19370 = "72"; --Mantle of the Blackwing Cabal
Item19335 = "20"; --Spineshatter
Item19337 = "16"; --The Black Book
Item19334 = "32"; --The Untamed Blade

Item19346 = "48"; --Dragonfang Blade
Item19372 = "44"; --Helm of Endless Rage
Item19339 = "40"; --Mind Quickening Gem
Item19371 = "28"; --Pendant of the Fallen Dragon
Item19348 = "28"; --Red Dragonscale Protector
Item19340 = "16"; --Rune of Metamorphosis

Item19373 = "40"; --Black Brood Pauldrons
Item19374 = "72"; --Bracers of Arcane Accuracy
Item19350 = "40"; --Heartstriker
Item19341 = "68"; --Lifegiving Gem
Item19351 = "92"; --Maladath, Runed Blade of the..
Item19342 = "16"; --Venomous Totem
Item20383 = "40"; --Head of Broodlord Lashlayer

Item19399 = "12"; --Black Ash Robe
Item19365 = "52"; --Claw of the Black Drake
Item19398 = "32"; --Cloak of Firemaw
Item19353 = "32"; --Drake Talon Cleaver
Item19394 = "52"; --Drake Talon Pauldrons
Item19400 = "44"; --Firemaw's Clutch
Item19402 = "0"; --Legguards of the Fallen Crusader
Item19344 = "20"; --Natural Alignment Crystal
Item19401 = "20"; --Primalist's Linked Legguards
Item19395 = "116"; --Rejuvenating Gem
Item19397 = "52"; --Ring of Blackrock
Item19355 = "48"; --Shadow Wing Focus Staff
Item19396 = "36"; --Taut Dragonhide Belt

Item19345 = "20"; --Aegis of Preservation
Item19403 = "52"; --Band of Forced Concentration
Item19368 = "52"; --Dragonbreath Hand Cannon
Item19406 = "116"; --Drake Fang Talisman
Item19407 = "40"; --Ebony Flame Gloves
Item19405 = "60"; --Malfurion's Blessed Bulwark

Item19432 = "32"; --Circle of Applied Force
Item19367 = "32"; --Dragon's Touch
Item19433 = "12"; --Emberweave Leggings
Item19357 = "32"; --Herald of Woe
Item19430 = "64"; --Shroud of Pure Thought
Item19431 = "116"; --Styleen's Impeding Scarab

Item19388 = "36"; --Angelista's Grasp
Item19361 = "124"; --Ashjre'thul, Crossbow of Smiting
Item19352 = "76"; --Chromatically Tempered Sword
Item19387 = "84"; --Chromatic Boots
Item19347 = "72"; --Claw of Chromaggus
Item19349 = "76"; --Elementium Reinforced Bulwark
Item19386 = "32"; --Elementium Threaded Cloak
Item19385 = "100"; --Empowered Leggings
Item19392 = "0"; --Girdle of the Fallen Crusader
Item19393 = "16"; --Primalist's Linked Waistguard
Item19391 = "40"; --Shimmering Geta
Item19390 = "24"; --Taut Dragonhide Gloves
Item19389 = "44"; --Taut Dragonhide Shoulderpads

Item19376 = "20"; --Archimtiros' Ring of Reckoning
Item19364 = "64"; --Ashkandi, Greatsword of the Bro..
Item19381 = "84"; --Boots of the Shadow Flame
Item19378 = "20"; --Cloak of the Brood Lord
Item19363 = "100"; --Crul'shoruk, Edge of Chaos
Item19360 = "60"; --Lok'amir il Romathis
Item19375 = "96"; --Mish'undare, Circlet of the Mind…
Item19379 = "116"; --Neltharion's Tear
Item19377 = "76"; --Prestor's Talisman of Connivery
Item19382 = "76"; --Pure Elementium Band
Item19356 = "80"; --Staff of the Shadow Flame
Item19380 = "36"; --Therazane's Link

Item19003 = "52"; --Head of Nefarian
Item19383 = "52"; --Head of Nefarian
Item19366 = "52"; --Head of Nefarian
Item19384 = "52"; --Head of Nefarian

Item16900 = "40"; --Stormrage Raiment
Item16902 = "40"; --Stormrage Raiment
Item16897 = "48"; --Stormrage Raiment
Item16904 = "28"; --Stormrage Raiment
Item16899 = "32"; --Stormrage Raiment
Item16903 = "32"; --Stormrage Raiment
Item16901 = "32"; --Stormrage Raiment
Item16898 = "32"; --Stormrage Raiment

Item16939 = "40"; --Dragonstalker Armor
Item16937 = "40"; --Dragonstalker Armor
Item16942 = "48"; --Dragonstalker Armor
Item16935 = "28"; --Dragonstalker Armor
Item16940 = "32"; --Dragonstalker Armor
Item16936 = "32"; --Dragonstalker Armor
Item16938 = "32"; --Dragonstalker Armor
Item16941 = "32"; --Dragonstalker Armor

Item16914 = "40"; --Netherwind Regalia
Item16917 = "40"; --Netherwind Regalia
Item16916 = "48"; --Netherwind Regalia
Item16918 = "28"; --Netherwind Regalia
Item16913 = "32"; --Netherwind Regalia
Item16818 = "32"; --Netherwind Regalia
Item16915 = "32"; --Netherwind Regalia
Item16912 = "32"; --Netherwind Regalia

Item16921 = "40"; --Vestments of Transcendence
Item16924 = "40"; --Vestments of Transcendence
Item16923 = "48"; --Vestments of Transcendence
Item16926 = "28"; --Vestments of Transcendence
Item16920 = "32"; --Vestments of Transcendence
Item16925 = "32"; --Vestments of Transcendence
Item16922 = "32"; --Vestments of Transcendence
Item16919 = "32"; --Vestments of Transcendence

Item16908 = "40"; --Bloodfang Armor
Item16832 = "40"; --Bloodfang Armor
Item16905 = "48"; --Bloodfang Armor
Item16911 = "28"; --Bloodfang Armor
Item16907 = "32"; --Bloodfang Armor
Item16910 = "32"; --Bloodfang Armor
Item16909 = "32"; --Bloodfang Armor
Item16906 = "32"; --Bloodfang Armor

Item16947 = "40"; --The Ten Storms
Item16945 = "40"; --The Ten Storms
Item16950 = "48"; --The Ten Storms
Item16943 = "28"; --The Ten Storms
Item16948 = "32"; --The Ten Storms
Item16944 = "32"; --The Ten Storms
Item16946 = "32"; --The Ten Storms
Item16949 = "32"; --The Ten Storms

Item16929 = "40"; --Nemesis Raiment
Item16932 = "40"; --Nemesis Raiment
Item16931 = "48"; --Nemesis Raiment
Item16934 = "28"; --Nemesis Raiment
Item16928 = "32"; --Nemesis Raiment
Item16933 = "32"; --Nemesis Raiment
Item16930 = "32"; --Nemesis Raiment
Item16927 = "32"; --Nemesis Raiment

Item16963 = "40"; --Battlegear of Wrath
Item16961 = "40"; --Battlegear of Wrath
Item16966 = "48"; --Battlegear of Wrath
Item16959 = "28"; --Battlegear of Wrath
Item16964 = "32"; --Battlegear of Wrath
Item16960 = "32"; --Battlegear of Wrath
Item16962 = "32"; --Battlegear of Wrath
Item16965 = "32"; --Battlegear of Wrath

	-------------------
	--- Molten Core ---
	-------------------

Item17109 = "8"; --Choker of Enlightenment
Item17077 = "4"; --Crimson Shocker
Item18861 = "4"; --Flamewalker Legplates
Item18879 = "40"; --Heavy Dark Iron Ring
Item18870 = "8"; --Helm of the Lifegiver
Item18872 = "8"; --Manastorm Leggings
Item19147 = "8"; --Ring of Spell Power
Item19145 = "60"; --Robe of Volatile Power
Item18875 = "60"; --Salamander Scale Pants
Item18878 = "16"; --Sorcerous Dagger
Item19146 = "8"; --Wristguards of Stability
Item16665 = "0"; --Tome of Tranquilizing Shot

Item18823 = "12"; --Aged Core Leather Gloves
Item18829 = "20"; --Deep Earth Spaulders
Item17073 = "12"; --Earthshaker
Item18203 = "16"; --Eskhandar's Right Claw
Item19142 = "12"; --Fire Runed Grimoire
Item19143 = "14"; --Flameguard Gauntlets
Item18861 = "4"; --Flamewalker Legplates
Item18824 = "0"; --Magma Tempered Boots
Item19136 = "36"; --Mana Igniting Cord
Item17065 = "48"; --Medallion of Steadfast Might
Item18822 = "12"; --Obsidian Edged Blade
Item18821 = "48"; --Quick Strike Ring
Item19144 = "12"; --Sabatons of the Flamewalker
Item17069 = "56"; --Striker's Mark
Item18820 = "48"; --Talisman of Ephemeral Power

Item17105 = "24"; --Aurastone Hammer
Item18832 = "28"; --Brutality Blade
Item17066 = "28"; --Drillborer Disk
Item17071 = "12"; --Gutgore Ripper
Item18564 = "150"; --Bindings of the Windseeker

Item17110 = "8"; --Seal of the Archmagus

Item18563 = "150"; --Bindings of the Windseeker

Item17074 = "4"; --Shadowstrike

Item17103 = "36"; --Azuresong Mageblade
Item17072 = "24"; --Blastershot Launcher
Item18842 = "28"; --Staff of Dominance

Item18703 = "48"; --Ancient Petrified Leaf
Item19140 = "36"; --Cauterizing Band
Item18806 = "4"; --Core Forged Greaves
Item18805 = "44"; --Core Hound Tooth
Item18803 = "12"; --Finkle's Lava Dredger
Item19139 = "4"; --Fireguard Shoulders
Item18811 = "4"; --Fireproof Cloak
Item18808 = "16"; --Gloves of the Hypnotic Flame
Item18809 = "16"; --Sash of Whispered Secrets
Item18646 = "36"; --The Eye of Divinity
Item18810 = "48"; --Wild Growth Spaulders
Item18812 = "36"; --Wristguards of True Flight

Item17063 = "80"; --Band of Accuria
Item19138 = "28"; --Band of Sulfuras
Item17076 = "24"; --Bonereaver's Edge
Item18814 = "60"; --Choker of the Firelord
Item17102 = "20"; --Cloak of the Shrouded Mists
Item18817 = "56"; --Crown of Destruction
Item17107 = "16"; --Dragon's Blood Cape
Item18815 = "12"; --Essence of the Pure Flame
Item17106 = "16"; --Malistar's Defender
Item19137 = "80"; --Onslaught Girdle
Item18816 = "56"; --Perdition's Blade
Item17082 = "12"; --Shard of the Flame
Item17104 = "20"; --Spinal Reaper

Item17204 = "150"; --Eye of Sulfuras

Item16834 = "12"; --Cenarion Raiment
Item16836 = "12"; --Cenarion Raiment
Item16833 = "16"; --Cenarion Raiment
Item16830 = "8"; --Cenarion Raiment
Item16831 = "12"; --Cenarion Raiment
Item16828 = "8"; --Cenarion Raiment
Item16835 = "12"; --Cenarion Raiment
Item16829 = "12"; --Cenarion Raiment

Item16846 = "12"; --Giantstalker Armor
Item16848 = "12"; --Giantstalker Armor
Item16845 = "16"; --Giantstalker Armor
Item16850 = "8"; --Giantstalker Armor
Item16852 = "12"; --Giantstalker Armor
Item16851 = "8"; --Giantstalker Armor
Item16847 = "12"; --Giantstalker Armor
Item16849 = "12"; --Giantstalker Armor

Item16795 = "12"; --Arcanist Regalia
Item16797 = "12"; --Arcanist Regalia
Item16798 = "16"; --Arcanist Regalia
Item16799 = "8"; --Arcanist Regalia
Item16801 = "12"; --Arcanist Regalia
Item16802 = "8"; --Arcanist Regalia
Item16796 = "12"; --Arcanist Regalia
Item16800 = "12"; --Arcanist Regalia

Item16813 = "12"; --Vestments of Prophecy
Item16816 = "12"; --Vestments of Prophecy
Item16815 = "16"; --Vestments of Prophecy
Item16819 = "8"; --Vestments of Prophecy
Item16812 = "12"; --Vestments of Prophecy
Item16817 = "8"; --Vestments of Prophecy
Item16814 = "12"; --Vestments of Prophecy
Item16811 = "12"; --Vestments of Prophecy

Item16821 = "12"; --Nightslayer Armor
Item16823 = "12"; --Nightslayer Armor
Item16820 = "16"; --Nightslayer Armor
Item16825 = "8"; --Nightslayer Armor
Item16826 = "12"; --Nightslayer Armor
Item16827 = "8"; --Nightslayer Armor
Item16822 = "12"; --Nightslayer Armor
Item16824 = "12"; --Nightslayer Armor

Item16842 = "12"; --The Earthfury
Item16844 = "12"; --The Earthfury
Item16841 = "16"; --The Earthfury
Item16840 = "8"; --The Earthfury
Item16839 = "12"; --The Earthfury
Item16838 = "8"; --The Earthfury
Item16843 = "12"; --The Earthfury
Item16837 = "12"; --The Earthfury

Item16808 = "12"; --Felheart Raiment
Item16807 = "12"; --Felheart Raiment
Item16809 = "16"; --Felheart Raiment
Item16804 = "8"; --Felheart Raiment
Item16805 = "12"; --Felheart Raiment
Item16806 = "8"; --Felheart Raiment
Item16810 = "12"; --Felheart Raiment
Item16803 = "12"; --Felheart Raiment

Item16866 = "12"; --Battlegear of Might
Item16868 = "12"; --Battlegear of Might
Item16865 = "16"; --Battlegear of Might
Item16861 = "8"; --Battlegear of Might
Item16863 = "12"; --Battlegear of Might
Item16864 = "8"; --Battlegear of Might
Item16867 = "12"; --Battlegear of Might
Item16862 = "12"; --Battlegear of Might

	---------------------
	--- Single Bosses ---
	---------------------
	
Item17067 = "12"; --Ancient Cornerstone Grimoire
Item17068 = "32"; --Deathbringer
Item18205 = "16"; --Eskhandar's Collar
Item18705 = "0"; --Mature Black Dragon Sinew
Item18813 = "4"; --Ring of Binding
Item17078 = "20"; --Sapphiron Drape
Item17064 = "68"; --Shard of the Scale
Item17075 = "24"; --Vis'kag the Bloodletter

Item18423 = "48"; --Head of Onyxia
Item18403 = "48"; --Head of Onyxia
Item18404 = "48"; --Head of Onyxia
Item18406 = "48"; --Head of Onyxia

Item19130 = "52"; --Cold Snap
Item19132 = "92"; --Crystal Adorned Crown
Item18208 = "12"; --Drape of Benediction
Item18202 = "20"; --Eskhandar's Left Claw
Item17070 = "36"; --Fang of the Mystics
Item18545 = "4"; --Leggings of Arcane Supremacy
Item18704 = "0"; --Mature Black Dragon Sinew
Item18541 = "68"; --Puissant Cape
Item19131 = "80"; --Snowblind Shoes
Item18542 = "12"; --Typhoon
Item18547 = "4"; --Unmelting Ice Girdle

Item20625 = "4"; --Belt of the Dark Bog
Item20626 = "20"; --Black Bark Wristbands
Item20627 = "64"; --Dark Heart Pants
Item20628 = "72"; --Deviate Growth Cap
Item20630 = "0"; --Gauntlets of the Shining Light
Item20629 = "12"; --Malignant Footguards

Item20619 = "4"; --Acid Inscribed Greaves
Item20617 = "28"; --Ancient Corroded Leggings
Item20616 = "16"; --Dragonbone Wristguards
Item20615 = "16"; --Dragonspur Wraps
Item20579 = "4"; --Green Dragonskin Cloak
Item20618 = "40"; --Gloves of Delusional Power
Item20580 = "32"; --Hammer of Bestial Fury
Item20581 = "40"; --Staff of Rampant Growth
Item20582 = "20"; --Trance Stone
Item20644 = "4"; --Nightmare Engulfed Object
Item20600 = "4"; --Nightmare Engulfed Object

Item20621 = "24"; --Boots of the Endless Moor
Item20623 = "32"; --Circlet of Restless Dreams
Item20622 = "20"; --Dragonheart Necklace
Item20599 = "28"; --Polished Ironwood Crossbow
Item20624 = "24"; --Ring of the Unliving

Item20634 = "24"; --Boots of Fright
Item20631 = "40"; --Mendicant's Slippers
Item20632 = "20"; --Mindtear Band
Item20577 = "36"; --Nightmare Blade
Item20633 = "4"; --Unnatural Leather Spaulders

Item20637 = "4"; --Acid Inscribed Pauldrons
Item20578 = "36"; --Emerald Dragonfang
Item20636 = "68"; --Hibernating Crystal
Item20635 = "36"; --Jade Inlaid Vestments
Item20638 = "32"; --Leggings of the Demented Mind
Item20639 = "0"; --Strangely Glyphed Legplates

Item17113 = "24"; --Amberseal Keeper
Item19135 = "12"; --Blacklight Bracer
Item17111 = "16"; --Blazefury Medallion
Item18544 = "20"; --Doomhide Gauntlets
Item17112 = "20"; --Empyrean Demolisher
Item18204 = "12"; --Eskhandar's Pelt
Item19133 = "72"; --Fel Infused Leggings
Item19134 = "16"; --Flayed Doomguard Belt
Item18546 = "24"; --Infernal Headcage
Item18543 = "12"; --Ring of Entropy
Item18665 = "0"; --The Eye of Shadow

	--------------
	--- 20 Man ---
	--------------

Item22637 = "24"; --Primal Hakkari Idol
Item19862 = "24"; --Aegis of the Blood God
Item19852 = "20"; --Ancient Hakkari Manslayer
Item19864 = "24"; --Bloodcaller
Item19855 = "20"; --Bloodsoaked Legplates
Item19857 = "36"; --Cloak of Consumption
Item19859 = "20"; --Fang of the Faceless
Item19853 = "16"; --Gurubashi Dwarf Destroyer
Item20264 = "0"; --Peacekeeper Gauntlets
Item20257 = "16"; --Seafury Gauntlets
Item19876 = "16"; --Soul Corrupter's Necklace
Item19856 = "24"; --The Eye of Hakkar
Item19861 = "28"; --Touch of Chaos
Item19865 = "20"; --Warblade of the Hakkari
Item19854 = "16"; --Zin'rokh, Destroyer of Worlds
Item19802 = "32"; --Heart of Hakkar
Item19950 = "32"; --Heart of Hakkar
Item19949 = "32"; --Heart of Hakkar
Item19948 = "32"; --Heart of Hakkar

Item19918 = "16"; --Jeklik's Crusher
Item19928 = "8"; --Animist's Spaulders
Item20262 = "8"; --Seafury Boots
Item20265 = "8"; --Peacekeeper Boots
Item19915 = "8"; --Zulian Defender
Item19923 = "8"; --Jeklik's Opaline Talisman
Item19920 = "8"; --Primalist's Band
Item19903 = "16"; --Fang of Venoxis
Item19904 = "16"; --Runed Bloodstained Hauberk
Item19907 = "8"; --Zulian Tigerhide Cloak
Item19906 = "8"; --Blooddrenched Footpads
Item19900 = "8"; --Zulian Stone Axe
Item19905 = "8"; --Zanzil's Band

Item20032 = "16"; --Flowing Ritual Robes
Item19927 = "16"; --Mar'li's Touch"

Item19919 = "8"; --Bloodstained Greaves
Item19930 = "8"; --Mar'li's Eye"
Item19871 = "8"; --Talisman of Protection"
Item19925 = "8"; --Band of Jin"
Item19866 = "16"; --Warblade of the Hakkari
Item19874 = "16"; --Halberd of Smiting
Item19867 = "16"; --Bloodlord's Defender
Item20038 = "16"; --Mandokir's Sting
Item19872 = "16"; --Swift Razzashi Raptor
Item19895 = "8"; --Bloodtinged Kilt
Item19870 = "8"; --Hakkari Loa Cloak
Item19877 = "8"; --Animist's Leggings
Item19869 = "8"; --Blooddrenched Grips
Item19878 = "8"; --Bloodsoaked Pauldrons
Item19873 = "8"; --Overlord's Crimson Band
Item19893 = "8"; --Zanzil's Seal
Item19863 = "8"; --Primalist's Seal
Item19961 = "8"; --Gri'lek's Grinder
Item19962 = "8"; --Gri'lek's Carver

Item19967 = "8"; --Thoughtblighter
Item19968 = "8"; --Fiery Retributer

Item19963 = "8"; --Pitchfork of Madness
Item19964 = "8"; --Renataki's Soul Conduit

Item19965 = "8"; --Wushoolay's Poker
Item19993 = "8"; --Hoodoo Hunting Bow

Item19945 = "16"; --Foror's Eyepatch
Item19944 = "16"; --Nat Pagle's Fish Terminator
Item19946 = "8"; --Tigule's Harpoon
Item19947 = "8"; --Nat Pagle's Broken Reel
Item22739 = "8"; --Tome of Polymorph: Turtle
Item19897 = "16"; --Betrayer's Boots

Item19896 = "16"; --Thekal's Grasp"
Item19902 = "16"; --Swift Zulian Tiger"
Item19899 = "8"; --Ritualistic Legguards
Item20260 = "8"; --Seafury Leggings"
Item20266 = "8"; --Peacekeeper Leggings"
Item19901 = "8"; --Zulian Slicer"
Item19898 = "8"; --Seal of Jin"
Item19910 = "16"; --Arlokk's Grasp
Item19909 = "16"; --Will of Arlokk"
Item19913 = "8"; --Bloodsoaked Greaves
Item19912 = "8"; --Overlord's Onyx Band"
Item19922 = "8"; --Arlokk's Hoodoo Stick"
Item19914 = "8"; --Panther Hide Sack"
Item19884 = "16"; --Jin'do's Judgement
Item19890 = "16"; --Jin'do's Hexxer"
Item19891 = "16"; --Jin'do's Bag of Whammies"
Item19885 = "16"; --Jin'do's Evil Eye"
Item19888 = "8"; --Overlord's Embrace
Item19886 = "8"; --The Hexxer's Cover"
Item19929 = "8"; --Bloodtinged Gloves"
Item19889 = "8"; --Blooddrenched Leggings"
Item19892 = "8"; --Animist's Boots"
Item19875 = "8"; --Bloodstained Coif"
Item19887 = "8"; --Bloodstained Legplates"
Item19894 = "8"; --Bloodsoaked Gauntlets"
Item22721 = "16"; --Band of Servitude
Item22722 = "16"; --Seal of the Gurubashi Berserker
Item22711 = "8"; --Cloak of the Hakkari Worshipers
Item22716 = "8"; --Belt of Untapped Power
Item22720 = "8"; --Zulian Headdress
Item22715 = "8"; --Gloves of the Tormented
Item22712 = "8"; --Might of the Tribe
Item22718 = "8"; --Blooddrenched Mask
Item22714 = "8"; --Sacrificial Gauntlets
Item22713 = "8"; --Zulian Scepter of Rites
Item20261 = "8"; --Shadow Panther Hide Belt
Item20259 = "8"; --Shadow Panther Hide Gloves
Item20263 = "8"; --Gurubashi Helm
Item19908 = "8"; --Sceptre of Smiting
Item20258 = "8"; --Zulian Ceremonial Staff
Item19921 = "8"; --Zulian Hacker

Item19723 = "16"; --Primal Hakkari Kossack
Item19722 = "16"; --Primal Hakkari Tabard
Item19724 = "16"; --Primal Hakkari Aegis
Item19721 = "16"; --Primal Hakkari Shawl
Item19719 = "16"; --Primal Hakkari Girdle
Item19720 = "16"; --Primal Hakkari Sash
Item19716 = "16"; --Primal Hakkari Bindings
Item19717 = "16"; --Primal Hakkari Armsplint
Item19718 = "16"; --Primal Hakkari Stanchion


Item19838 = "16"; --Haruspex's Garb
Item19839 = "16"; --Haruspex's Garb
Item19840 = "16"; --Haruspex's Garb

Item19831 = "16"; --Predator's Armor
Item19832 = "16"; --Predator's Armor
Item19833 = "16"; --Predator's Armor

Item20034 = "16"; --Illusionist's Attire
Item19845 = "16"; --Illusionist's Attire
Item19846 = "16"; --Illusionist's Attire

Item19841 = "16"; --Confessor's Raiment
Item19842 = "16"; --Confessor's Raiment
Item19843 = "16"; --Confessor's Raiment

Item19834 = "16"; --Madcap's Outfit
Item19835 = "16"; --Madcap's Outfit
Item19836 = "16"; --Madcap's Outfit

Item19828 = "16"; --Augur's Regalia
Item19829 = "16"; --Augur's Regalia
Item19830 = "16"; --Augur's Regalia

Item20033 = "16"; --Domoniac's Threads
Item19849 = "16"; --Domoniac's Threads
Item19848 = "16"; --Domoniac's Threads

Item19822 = "16"; --Vindicator's Battlegear
Item19823 = "16"; --Vindicator's Battlegear
Item19824 = "16"; --Vindicator's Battlegear







Item21499 = "16"; --Vestments of the Shifting Sands
Item21498 = "16"; --Qiraji Sacrificial Dagger
Item21500 = "8"; --Belt of the Inquisition
Item21501 = "8"; --Toughened Silithid Hide Gloves
Item21502 = "8"; --Sand Reaver Wristguards
Item21503 = "8"; --Belt of the Sand Reaver
Item21810 = "8"; --Treads of the Wandering Nomad
Item21806 = "8"; --Gavel of Qiraji Authority
Item21809 = "8"; --Fury of the Forgotten Swarm
Item21493 = "16"; --Boots of the Vanguard
Item21492 = "16"; --Manslayer of the Qiraji
Item21496 = "8"; --Bracers of Qiraji Command
Item21494 = "8"; --Southwind's Grasp
Item21497 = "8"; --Boots of the Qiraji General
Item21495 = "8"; --Legplates of the Qiraji Command
Item21472 = "16"; --Dustwind Turban
Item21467 = "16"; --Thick Silithid Chestguard
Item21479 = "16"; --Gauntlets of the Immovable
Item21471 = "16"; --Talon of Furious Concentration
Item21468 = "8"; --Mantle of Maz'Nadir
Item21470 = "8"; --Cloak of the Savior
Item21474 = "8"; --Chitinous Shoulderguards
Item21469 = "8"; --Gauntlets of Southwind
Item21455 = "8"; --Southwind Helm
Item21476 = "8"; --Obsidian Scaled Leggings
Item21475 = "8"; --Legplates of the Destroyer
Item21477 = "8"; --Ring of Fury
Item21473 = "8"; --Eye of Moam
Item21487 = "16"; --Slimy Scaled Gauntlets
Item21486 = "16"; --Gloves of the Swarm
Item21485 = "16"; --Buru's Skull Fragment
Item21489 = "8"; --Quicksand Waders
Item21491 = "8"; --Scaled Bracers of the Gorger
Item21490 = "8"; --Slime Kickers
Item21488 = "8"; --Fetish of Chitinous Spikes
Item21479 = "16"; --Gauntlets of the Immovable
Item21466 = "16"; --Stinger of Ayamiss
Item21478 = "16"; --Bow of Taut Sinew
Item21484 = "8"; --Helm of Regrowth
Item21480 = "8"; --Scaled Silithid Gauntlets
Item21482 = "8"; --Boots of the Fiery Sands
Item21481 = "8"; --Boots of the Desert Protector
Item21483 = "8"; --Ring of the Desert Winds
Item20889 = "8"; --Qiraji Regal Drape
Item20885 = "8"; --Qiraji Martial Drape
Item20886 = "16"; --Qiraji Spiked Hilt
Item20890 = "16"; --Qiraji Ornate Hilt
Item20884 = "8"; --Qiraji Magisterial Ring
Item20888 = "8"; --Qiraji Ceremonial Ring


Item21457 = "16"; --Bracers of Brutality
Item21459 = "56"; --Crossbow of Imminent Doom
Item21458 = "16"; --Gauntlets of New Life
Item21462 = "24"; --Gloves of Dark Wisdom
Item21460 = "28"; --Helm of Domination
Item21461 = "56"; --Leggings of the Black Blizzard
Item21453 = "0"; --Mantle of the Horusath
Item21463 = "20"; --Ossirian's Bindings
Item21454 = "20"; --Runic Stone Shoulders
Item21715 = "32"; --Sand Polished Hammer
Item21456 = "28"; --Sandstorm Cloak
Item21464 = "36"; --Shackles of the Unscarred
Item21452 = "48"; --Staff of the Ruins

Item21220 = "24"; --Head of Ossirian the Unscarred
Item21504 = "24"; --Head of Ossirian the Unscarred
Item21507 = "24"; --Head of Ossirian the Unscarred
Item21505 = "24"; --Head of Ossirian the Unscarred
Item21506 = "24"; --Head of Ossirian the Unscarred

Item21407 = "16"; --Symbols of Unending Life
Item21409 = "8"; --Symbols of Unending Life
Item21408 = "8"; --Symbols of Unending Life

Item21401 = "16"; --Trappings of the Unseen Path
Item21403 = "8"; --Trappings of the Unseen Path
Item21402 = "8"; --Trappings of the Unseen Path

Item21413 = "16"; --Trappings of Vaulted Secrets
Item21415 = "8"; --Trappings of Vaulted Secrets
Item21414 = "8"; --Trappings of Vaulted Secrets

Item21410 = "16"; --Finery of Infinite Wisdom
Item21412 = "8"; --Finery of Infinite Wisdom
Item21411 = "8"; --Finery of Infinite Wisdom

Item21404 = "16"; --Emblems of Veiled Shadows
Item21406 = "8"; --Emblems of Veiled Shadows
Item21405 = "8"; --Emblems of Veiled Shadows

Item21398 = "16"; --Gift of the Gathering Storm
Item21400 = "8"; --Gift of the Gathering Storm
Item21399 = "8"; --Gift of the Gathering Storm

Item21416 = "16"; --Implements of Unspoken Names
Item21418 = "8"; --Implements of Unspoken Names
Item21417 = "8"; --Implements of Unspoken Names

Item21392 = "16"; --Battlegear of Unyielding Strength
Item21394 = "8"; --Battlegear of Unyielding Strength
Item21393 = "8"; --Battlegear of Unyielding Strength

	
};
    
Discordia_GP = {

}    