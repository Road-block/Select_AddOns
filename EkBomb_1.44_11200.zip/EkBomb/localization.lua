-- -----
-- Bomb warnings.
--
-- a) The "_Text" variables contain text sent by the server. It must
--    match what the server sends, but it can be a regular expression.
--
-- b) The "_Name" variables contain the name of the bomb (descriptive).
--
-- c) The "_Mob" variables contain the name of the mob (descriptive).
--
-- d) The "_Big" variables contain text shown in large letters in the
--    warning box.  If it is too long it may not fit on the screen
--    depending on what the user's scaling is.
--
-- e) The "_Small" variables contain text shown in small letters in
--    the warning box.
--
-- f) The "_Player" variables contain a regular expression that includes
--    text sent by the server. The regular expression should be capable
--    of capturing the name of the player from the server text.
--
-- g) The "_Test" variables are similar to the "_Player" ones, except
--    that these are intended for use in string.format(). They are used
--    when I test the addon, and should create a text string equal to
--    what the server would send.
-- -----
EkBomb_TEXT_Bomb_Plague_Text = "You are afflicted by Plague";
EkBomb_TEXT_Bomb_Plague_Name = "Plague";
EkBomb_TEXT_Bomb_Plague_Mob = "Anubisath Defender";
EkBomb_TEXT_Bomb_Plague_Big = "RUN!";
EkBomb_TEXT_Bomb_Plague_Small = "You have the Plague!";

EkBomb_TEXT_Bomb_Living_Text = "You are afflicted by Living Bomb";
EkBomb_TEXT_Bomb_Living_Name = "Living bomb";
EkBomb_TEXT_Bomb_Living_Mob = "Baron Geddon";
EkBomb_TEXT_Bomb_Living_Big = "RUN!";
EkBomb_TEXT_Bomb_Living_Small = "You are a Living Bomb!";

EkBomb_TEXT_Bomb_Corrupt_Text = "Priests! If you're going to keep healing like that, we might as well make it a little more interesting!";
EkBomb_TEXT_Bomb_Corrupt_Name = "Corrupted healing";
EkBomb_TEXT_Bomb_Corrupt_Mob = "Nefarian";
EkBomb_TEXT_Bomb_Corrupt_Big = "STOP!";
EkBomb_TEXT_Bomb_Corrupt_Small = "You have Corrupted Healing!";

EkBomb_TEXT_Bomb_Adrenaline_Text = "You are afflicted by Burning Adrenaline";
EkBomb_TEXT_Bomb_Adrenaline_Name = "Burning adrenaline";
EkBomb_TEXT_Bomb_Adrenaline_Mob = "Vaelastrasz";
EkBomb_TEXT_Bomb_Adrenaline_Big = "RUN!";
EkBomb_TEXT_Bomb_Adrenaline_Small = "You have Burning Adrenaline!";

EkBomb_TEXT_Bomb_Mandokir_Player = "([^%s]+)! I'm watching you!$";
EkBomb_TEXT_Bomb_Mandokir_Test = "%s! I'm watching you!";
EkBomb_TEXT_Bomb_Mandokir_Name = "Threatening gaze";
EkBomb_TEXT_Bomb_Mandokir_Mob = "Bloodlord Mandokir";
EkBomb_TEXT_Bomb_Mandokir_Big = "STOP!";
EkBomb_TEXT_Bomb_Mandokir_Small = "You are being watched!";

EkBomb_TEXT_Bomb_Mutating_Text = "You are afflicted by Mutating Injection";
EkBomb_TEXT_Bomb_Mutating_Name = "Mutating injection";
EkBomb_TEXT_Bomb_Mutating_Mob = "Grobbulus";
EkBomb_TEXT_Bomb_Mutating_Big = "RUN!";
EkBomb_TEXT_Bomb_Mutating_Small = "You have a Mutating Injection!";

-- -----
-- Command line commands (use lowercase letters for the commands).
-- -----
EkBomb_TEXT_Command_Help = "help";
EkBomb_TEXT_Command_Reset = "reset";
EkBomb_TEXT_Command_Test = "test";


-- -----
-- Command line help.
-- -----
EkBomb_TEXT_Help_Config = "Open the configuration window.";
EkBomb_TEXT_Help_Help = "Display this command summary.";
EkBomb_TEXT_Help_Reset = "Reset the position of the windows.";
EkBomb_TEXT_Help_Test = "Test the warning window.";


-- -----
-- Warning window
-- -----

-- Close button
EkBomb_TEXT_Warning_Close = "Close";
EkBomb_TEXT_Warning_Close_Tooltip1 = "Close";
EkBomb_TEXT_Warning_Close_Tooltip2 = "Close the bomb warning window.";


-- -----
-- Config window
-- -----

-- Title box
EkBomb_TEXT_Config_Drag_Tooltip = "Left-click to drag\nRight-click to reset";

-- Opacity slider
EkBomb_TEXT_Config_Opacity = "Warning window opacity";

-- Scale slider
EkBomb_TEXT_Config_Scale = "Warning window scale";

-- Colors
EkBomb_TEXT_Config_SmallColor = "Small text";
EkBomb_TEXT_Config_LargeColor = "Large text";
EkBomb_TEXT_Config_BackgroundColor = "Background";

-- Color selection window title.
EkBomb_TEXT_Config_SelectColor = "Select color";

-- Blink checkbox
EkBomb_TEXT_Config_Flash = "Blink the warning";
EkBomb_TEXT_Config_Flash_Tooltip1 = "Blink the warning";
EkBomb_TEXT_Config_Flash_Tooltip2 = "If this is checked, then the warning window will periodically blink by changing brightness.";

-- Background checkbox
EkBomb_TEXT_Config_Background = "Show the background";
EkBomb_TEXT_Config_Background_Tooltip1 = "Show background";
EkBomb_TEXT_Config_Background_Tooltip2 = "If this is checked, then the warning window's background will be visible. Uncheck this to see just the warning text.";

-- Sound checkbox
EkBomb_TEXT_Config_Sound = "Play a sound";
EkBomb_TEXT_Config_Sound_Tooltip1 = "Play a sound";
EkBomb_TEXT_Config_Sound_Tooltip2 = "If this is checked, then a sound will be played when the warning window appears.";

-- Timer checkbox
EkBomb_TEXT_Config_ShowTimer = "Show the timer";
EkBomb_TEXT_Config_ShowTimer_Tooltip1 = "Show timer";
EkBomb_TEXT_Config_ShowTimer_Tooltip2 = "If this is checked, then the close button on the warning window will show the number of seconds remaining until the warning window automatically closes.";

-- Enable checkbox
EkBomb_TEXT_Config_Enable = "Enable warnings";
EkBomb_TEXT_Config_Enable_Tooltip1 = "Enable warnings";
EkBomb_TEXT_Config_Enable_Tooltip2 = "This will enable/disable the warning window without changing the individual warnings.";

-- Individual bomb checkboxes
EkBomb_TEXT_Config_Bomb_Tooltip1 = "Enable this bomb warning";
EkBomb_TEXT_Config_Bomb_Tooltip2 = "Check this box to enable this bomb warning.  Clear this box to disable it.";

-- Test button
EkBomb_TEXT_Config_Test = "Test";
EkBomb_TEXT_Config_Test_Tooltip1 = "Test";
EkBomb_TEXT_Config_Test_Tooltip2 = "Test the next warning.";

-- Close button
EkBomb_TEXT_Config_Close = "Close";
EkBomb_TEXT_Config_Close_Tooltip1 = "Close";
EkBomb_TEXT_Config_Close_Tooltip2 = "Close this window.";

-- Help message
EkBomb_TEXT_Config_Help = "For a list of commands type:";


-- -----
-- Text used in EkCheck window.
-- -----

-- Column headings
EkBomb_TEXT_EkCheck_Enabled = "Enabled";
EkBomb_TEXT_EkCheck_Warnings = "Warnings";
EkBomb_TEXT_EkCheck_Version = "Version";

-- Text shown on a player's line
EkBomb_TEXT_EkCheck_Yes = "Yes";
EkBomb_TEXT_EkCheck_No = "No";

-- Player tooltip
EkBomb_TEXT_EkCheck_Unknown = "Unknown";
EkBomb_TEXT_EkCheck_Enabled_Warnings = "Enabled Warnings";
EkBomb_TEXT_EkCheck_Disabled_Warnings = "Disabled Warnings";

