local textures = {
  ["Default"] = "Interface\\Minimap\\ObjectIcons",
  ["Dragon"] = "Interface\\AddOns\\DragonTracker\\DragonTrack",
  ["DragonBlink"] = "Interface\\AddOns\\DragonTracker\\DragonTrackBlink"
}
local zones = {
  ["Onyxia\'s Lair"] = true
}
local lastUpdate = 0
local blink = false
local enabled = false
local addonFrame = CreateFrame("Frame")
addonFrame:RegisterEvent("ZONE_CHANGED")
addonFrame:RegisterEvent("ZONE_CHANGED_INDOORS")
addonFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
addonFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
local OnUpdate = function()
  if not (enabled) then return end
  local elapsed = arg1
  lastUpdate = lastUpdate + elapsed
  if lastUpdate > 0.5 then
    lastUpdate = 0
    blink = not blink
    if (blink) then
      Minimap:SetBlipTexture(textures.DragonBlink)
    else
      Minimap:SetBlipTexture(textures.Dragon)
    end
  end  
end
addonFrame:SetScript("OnEvent",function()
    return this[event]~=nil and this[event](this,event,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11)
  end)
addonFrame:SetScript("OnUpdate",OnUpdate)
function addonFrame:ZONE_CHANGED_NEW_AREA(event,arg1)
  local zone = GetZoneText()
  local minizone = GetMinimapZoneText()
  local subzone = GetSubZoneText()
  --ChatFrame3:AddMessage(tostring(zone).." "..tostring(minizone).." "..tostring(subzone))
  if (zone and zones[zone]) --[[or (minizone and zones[minizone])]] or (subzone and zones[subzone]) then
    enabled = true
    Minimap:SetBlipTexture(textures.Dragon)
  else
    enabled = false
    Minimap:SetBlipTexture(textures.Default)
  end
end
addonFrame.ZONE_CHANGED, addonFrame.ZONE_CHANGED_INDOORS, addonFrame.PLAYER_ENTERING_WORLD = 
  addonFrame.ZONE_CHANGED_NEW_AREA, addonFrame.ZONE_CHANGED_NEW_AREA, addonFrame.ZONE_CHANGED_NEW_AREA
SlashCmdList["DRAGONTRACKER"] = function(msg)
  enabled = not enabled
  DEFAULT_CHAT_FRAME:AddMessage("DragonTracker: "..(enabled and "ON" or "OFF"))
  if (enabled) then
  else
    Minimap:SetBlipTexture(textures.Default)
  end
end
SLASH_DRAGONTRACKER1 = "/drtr"