local f = CreateFrame("Frame")
f:SetScript("OnEvent",function()
    return f[event] ~= nil and this[event](this,event,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11)
  end)
f:RegisterEvent("PLAYER_ENTERING_WORLD")

function f:PLAYER_ENTERING_WORLD(event)
  UIParent:UnregisterEvent("CONFIRM_SUMMON")
  self:RegisterEvent("CONFIRM_SUMMON")
end

function f:CONFIRM_SUMMON(event)
  if ( UnitOnTaxi("player") ) then
    local summoner = GetSummonConfirmSummoner()
    if (summoner) then
      SendChatMessage("Sorry, flying. Can't accept summon at the moment.", "WHISPER", nil, summoner)
    end
  else
    StaticPopup_Show("CONFIRM_SUMMON")
  end
end
