Open the "index.html" file in a web browser to view the documentation and change history.

