sepgp = AceLibrary("AceAddon-2.0"):new("AceConsole-2.0", "AceDB-2.0", "AceDebug-2.0", "AceEvent-2.0", "AceModuleCore-2.0", "FuBarPlugin-2.0")
sepgp:SetModuleMixins("AceDebug-2.0")
local D = AceLibrary("Dewdrop-2.0")

local shooty_basegp = 135
local shooty_debugchat
local out = "|cff9664c8shootyepgp:|r %s"
local needInit = true

function sepgp:OnInitialize()
  if sepgp_saychannel == nil then sepgp_saychannel = "GUILD" end
end

function sepgp:OnMenuRequest()
  D:FeedAceOptionsTable(self:buildMenu())
end

function sepgp:OnEnable()
  for i=1,NUM_CHAT_WINDOWS do
    local tab = getglobal("ChatFrame"..i.."Tab")
    local cf = getglobal("ChatFrame"..i)
    local tabName = tab:GetText()
    if tab ~= nil and (string.lower(tabName) == "debug") then
      shooty_debugchat = cf
      ChatFrame_RemoveAllMessageGroups(shooty_debugchat)
      shooty_debugchat:SetMaxLines(1024)
      break
    end
  end
  sepgp:RegisterEvent("GUILD_ROSTER_UPDATE",function() 
      if (arg1) then -- member join /leave
        self:SetRefresh(true)
      end
    end)
  sepgp:RegisterEvent("RAID_ROSTER_UPDATE",function()
      self:SetRefresh(true)
    end)
  sepgp:RegisterEvent("PARTY_MEMBERS_CHANGED",function()
      self:SetRefresh(true)
    end)
end

function sepgp:SetRefresh(flag)
  needRefresh = flag
  if (flag) then
    sepgp_standings:Refresh()
  end
end

function sepgp:flashFrame(frame)
  local tabFlash = getglobal(frame:GetName().."TabFlash");
  if ( not frame.isDocked or (frame == SELECTED_DOCK_FRAME) or UIFrameIsFlashing(tabFlash) ) then
    return
  end
  tabFlash:Show();
  UIFrameFlash(tabFlash, 0.25, 0.25, 60, nil, 0.5, 0.5)
end

function sepgp:debugPrint(msg)
  if (shooty_debugchat) then
    shooty_debugchat:AddMessage(string.format(out,msg))
    sepgp:flashFrame(shooty_debugchat)
  else
    sepgp:defaultPrint(msg)
  end
end

function sepgp:defaultPrint(msg)
  if not DEFAULT_CHAT_FRAME:IsVisible() then
    FCF_SelectDockFrame(DEFAULT_CHAT_FRAME)
  end
  DEFAULT_CHAT_FRAME:AddMessage(string.format(out,msg))
end

function sepgp:simpleSay(msg)
  SendChatMessage(string.format("shootyepgp: %s",msg), sepgp_saychannel)
end

function sepgp:adminSay(msg)
  -- API is broken on Elysium
  -- local g_listen, g_speak, officer_listen, officer_speak, g_promote, g_demote, g_invite, g_remove, set_gmotd, set_publicnote, view_officernote, edit_officernote, set_guildinfo = GuildControlGetRankFlags() 
  -- if (officer_speak) then
  SendChatMessage(string.format("shootyepgp: %s",msg),"OFFICER")
  -- end
end

function sepgp:init_notes(guild_index,note,officernote)
  if not tonumber(note) or (tonumber(note) < 0) then
    GuildRosterSetPublicNote(guild_index,0)
  end
  if not tonumber(officernote) or (tonumber(officernote) < shooty_basegp) then
    GuildRosterSetOfficerNote(guild_index,shooty_basegp)
  end
end

function sepgp:update_ep(getname,ep)
  for i = 1, GetNumGuildMembers(1) do
    local name, _, _, _, class, _, note, officernote, _, _ = GetGuildRosterInfo(i)
    if (name==getname) then 
      sepgp:init_notes(i,note,officernote)
      GuildRosterSetPublicNote(i,ep)
    end
  end
end

function sepgp:update_gp(getname,gp)
  for i = 1, GetNumGuildMembers(1) do
    local name, _, _, _, class, _, note, officernote, _, _ = GetGuildRosterInfo(i)
    if (name==getname) then 
      sepgp:init_notes(i,note,officernote)
      GuildRosterSetOfficerNote(i,gp) 
    end
  end
end

function sepgp:get_ep(getname) -- gets ep by name
  for i = 1, GetNumGuildMembers(1) do
    local name, _, _, _, class, _, note, officernote, _, _ = GetGuildRosterInfo(i)
    if tonumber(note)==nil then note=0 end
    if (name==getname) then return tonumber(note); end
  end
  return(0)
end

function sepgp:get_gp(getname) -- gets gp by name
  for i = 1, GetNumGuildMembers(1) do
    local name, _, _, _, class, _, note, officernote, _, _ = GetGuildRosterInfo(i)
    if tonumber(officernote)==nil then officernote=shooty_basegp end
    if (name==getname) then return tonumber(officernote); end
  end
  return(shooty_basegp)
end

function sepgp:award_raid_ep(ep) -- awards ep to raid members in zone
  if GetNumRaidMembers()>0 then
    sepgp:simpleSay(string.format("Giving %d ep to all raidmembers",ep))
    for i = 1, GetNumRaidMembers(true) do
      local name, rank, subgroup, level, class, fileName, zone, online, isDead = GetRaidRosterInfo(i)
      sepgp:givename_ep(name,ep)
    end
  else UIErrorsFrame:AddMessage("You aren't in a raid dummy",255,0,0)end
end

function sepgp:givename_ep(getname,ep) -- awards ep to a single character
  sepgp:debugPrint(string.format("Giving %d ep to %s",ep,getname))
  ep = ep + sepgp:get_ep(getname)
  sepgp:update_ep(getname,ep)
end

function sepgp:givename_gp(getname,gp) -- assigns gp to a single character
  sepgp:debugPrint(string.format("Giving %d gp to %s",gp,getname))
  local oldgp = sepgp:get_gp(getname)
  local newgp = gp + oldgp
  sepgp:adminSay(string.format("Awarding %d GP to %s. (Previous: %d, New: %d)",gp,getname,oldgp,newgp))
  sepgp:update_gp(getname,newgp)
end

function sepgp:decay_epgp() -- decays entire roster's ep and gp
  for i = 1, GetNumGuildMembers(1) do
    local name,_,_,_,class,_,ep,gp,_,_ = GetGuildRosterInfo(i)
    ep = tonumber(ep)
    gp = tonumber(gp)
    if ep == nil then 
  	else 
      ep = math.max(0,sepgp:num_round(ep*0.9))
  	  GuildRosterSetPublicNote(i,ep)
  	  gp = math.max(shooty_basegp,sepgp:num_round(gp*0.9))
  	  GuildRosterSetOfficerNote(i,gp)
    end
  end
  sepgp:simpleSay("all ep and gp decayed by 10%")
end

function sepgp:gp_reset()
   for i = 1, GetNumGuildMembers(1) do
     GuildRosterSetOfficerNote(i, shooty_basegp)
   end
   sepgp:debugPrint(string.format("All GP has been reset to %d.",shooty_basegp))
end

function sepgp:num_round(i)
  return math.floor(i+0.5)
end

local T = AceLibrary("Tablet-2.0")

sepgp.defaultMinimapPosition = 180
sepgp.cannotDetachTooltip = true
sepgp.tooltipHidderWhenEmpty = false
sepgp.hasIcon = "Interface\\Icons\\INV_Misc_Orb_04"

function sepgp:OnTooltipUpdate()
  T:SetHint("Open EPGP Standings")
end

function sepgp:OnClick()
  sepgp_standings:Toggle()
end

function sepgp:buildRosterTable()
  local g, r = { }, { }
  local numGuildMembers = GetNumGuildMembers(1)
  if (sepgp_raidonly) and GetNumRaidMembers() > 0 then
    for i = 1, GetNumRaidMembers(true) do
      local name, rank, subgroup, level, class, fileName, zone, online, isDead = GetRaidRosterInfo(i) 
      r[name] = true
    end
  end
  for i = 1, numGuildMembers do
    local member_name,_,_,_,class,_,ep,gp,_,_ = GetGuildRosterInfo(i)
    if (sepgp_raidonly) and next(r) then
      if r[member_name] then
        table.insert(g,{["name"]=member_name,["class"]=class})
      end
    else
      table.insert(g,{["name"]=member_name,["class"]=class})
    end    
  end
  return g
end

function sepgp:buildClassMemberTable(roster,epgp)
  local desc,usage
  if epgp == "ep" then
    desc = "Account EPs to %s."
    usage = "<EP>"
  elseif epgp == "gp" then
    desc = "Account GPs to %s."
    usage = "<GP>"
  end
  local c = { }
  for i,member in ipairs(roster) do
    local class,name = member.class, member.name
    if c[class] == nil then
      c[class] = { }
      c[class].type = "group"
      c[class].name = class
      c[class].desc = class .. " members"
      c[class].disabled = function() return not (CanEditOfficerNote() and CanEditPublicNote()) end
      c[class].args = { }
    end
    if c[class].args[name] == nil then
      c[class].args[name] = { }
      c[class].args[name].type = "text"
      c[class].args[name].name = name
      c[class].args[name].desc = string.format(desc,name)
      c[class].args[name].usage = usage
      c[class].args[name].get = false
      if epgp == "ep" then
        c[class].args[name].set = function(v) sepgp:givename_ep(name, tonumber(v)) end
      elseif epgp == "gp" then
        c[class].args[name].set = function(v) sepgp:givename_gp(name, tonumber(v)) end
      end
      c[class].args[name].validate = function(v) return (type(v) == "number" or tonumber(v)) and tonumber(v) < 10000 end
    end
  end
  return c
end

local options
do
 options = {
  type = "group",
  desc = "shootyepgp options",
  args = { }
  }
  options.args["raid_only"] = {
    type = "toggle",
    name = "Raid Only",
    desc = "Only show members in raid.",
    get = function() return not not sepgp_raidonly end,
    set = function(v) 
      sepgp_raidonly = not sepgp_raidonly
      sepgp:SetRefresh(true)
      sepgp_standings:Refresh()
    end,
  }
  options.args["ep_raid"] = {
    type = "text",
    name = "+EPs to Raid",
    desc = "Award EPs to all raid members.",
    get = false,
    set = function(v) sepgp:award_raid_ep(tonumber(v))end,
    usage = "<EP>",
    disabled = function() return not (CanEditOfficerNote() and CanEditPublicNote()) end,
    validate = function(v)
      local n = tonumber(v)
      return n and n >= 0 and n < 10000
    end
  }
  options.args["ep"] = {
    type = "group",
    name = "+EPs to Member",
    desc = "Account EPs for member.",
    disabled = function() return not (CanEditOfficerNote() and CanEditPublicNote()) end,
  }
  options.args["gp"] = {
    type = "group",
    name = "+GPs to Member",
    desc = "Account GPs for member.",
    disabled = function() return not (CanEditOfficerNote() and CanEditPublicNote()) end,
  }
  options.args["report_channel"] = {
    type = "text",
    name = "Reporting channel",
    desc = "Channel used by reporting functions.",
    get = function() return sepgp_saychannel end,
    set = function(v) sepgp_saychannel = v end,
    validate = { "PARTY", "RAID", "GUILD", "OFFICER" },
  }
  options.args["decay"] = {
    type = "execute",
    name = "Decay EPGP",
    desc = "Decays all EPGP by 10%",
    disabled = function() return not (CanEditOfficerNote() and CanEditPublicNote()) end,
    func = function() sepgp:decay_epgp() end
  }
  -- Reset EPGP data
  options.args["reset"] = {
   type = "execute",
   name = "Reset GP",
   desc = string.format("gives everybody %d basic GP.",shooty_basegp),
   disabled = function() return not (IsGuildLeader()) end,
   func = function() sepgp:gp_reset() end
  }
end
function sepgp:buildMenu()
  if (needInit) or (needRefresh) then
    local members = sepgp:buildRosterTable()
    self:debugPrint(string.format("Scanning %d members for EP/GP data. (%s)",table.getn(members),(sepgp_raidonly and "Raid" or "Full")))
    options.args["ep"].args = sepgp:buildClassMemberTable(members,"ep")
    options.args["gp"].args = sepgp:buildClassMemberTable(members,"gp")
    if (needInit) then needInit = false end
    if (needRefresh) then needRefresh = false end
  end
  return options
end
